"use client";
import { useEffect, useRef, useState, type CSSProperties } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

const PLATES = [["all", "All inks"], ["oxide", "Oxide"], ["leaf", "Leaf"], ["sun", "Sun"]] as const;
const Arrow = ({ d = "up" }: { d?: "up" | "down" | "right" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
    {d === "up" && <path d="M7 17 17 7M8 7h9v9" />}
    {d === "down" && <path d="M12 4v16m-6-6 6 6 6-6" />}
    {d === "right" && <path d="M4 12h16m-6-6 6 6-6 6" />}
  </svg>
);

export default function Page() {
  const root = useRef<HTMLDivElement>(null);
  const [plate, setPlate] = useState<string>("all");
  const [reg, setReg] = useState(26);

  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    const mm = gsap.matchMedia();
    mm.add("(prefers-reduced-motion: no-preference)", () => {
      gsap.utils.selector(root)("[data-rise]").forEach((el) => {
        gsap.fromTo(el, { y: 32, opacity: 0 }, { y: 0, opacity: 1, duration: 1, ease: "power3.out",
          scrollTrigger: { trigger: el, start: "top 90%", end: "bottom 10%", toggleActions: "play reset play reset" } });
      });
    });
    return () => mm.revert();
  }, []);

  const vars = { "--registration-offset": `${reg * 0.12}px`, "--registration-opacity": String(0.1 + reg * 0.01) } as CSSProperties;

  return (
    <div className="rmz-project" ref={root}>
      <header className="rmz-header">
        <a className="rmz-wordmark" href="#"><span className="rmz-mark">RMZ</span><span className="rmz-wordmark-name">REBEL MIND<br />ZONE</span></a>
        <a className="rmz-header-project" href="#idea"><span>PROJECT 041</span><i className="rmz-header-divider" /><span>BRAND WORLD</span><Arrow /></a>
      </header>

      <section className="rmz-opening">
        <div className="rmz-opening-meta"><p><span>01</span> / SELECTED WORK</p><p>CONCEPT PROJECT <i className="rmz-meta-dot" /> 2025</p></div>
        <div className="rmz-title-row">
          <h1 data-rise><span>THE LAND</span><span className="rmz-title-last">REMEMBERS</span></h1>
          <p className="rmz-opening-note">A harvest is never just a harvest.</p>
        </div>
        <div className="rmz-opening-caption">
          <p><strong>SIDRA</strong> / OLIVE OIL, REIMAGINED</p>
          <a className="rmz-text-button" href="#idea" style={{ display: "inline-flex", alignItems: "center", gap: 8, lineHeight: "38px" }}>ENTER THE STORY <Arrow d="down" /></a>
        </div>
        <figure className="rmz-hero-art">
          <img className="rmz-hero-photo" src="/hero.jpg" alt="Sidra bottle against terracotta with olive branches" />
          <div className="rmz-hero-stamp"><span>THE FIRST PRESS<br />IS A PLACE</span><span><br />32°13′E</span></div>
          <span className="rmz-hero-index">A / 04</span>
          <span className="rmz-hero-side-note">CULTIVATED MEMORY — SIDRA / EASTERN MEDITERRANEAN</span>
        </figure>
        <div className="rmz-under-image-line"><span>IDENTITY / CAMPAIGN / IMAGE-MAKING</span><span>SCROLL TO UNFOLD <Arrow d="down" /></span></div>
      </section>

      <section className="rmz-story" id="idea">
        <div className="rmz-story-index"><span>01 — THE IDEA</span><i className="rmz-index-rule" /></div>
        <div className="rmz-story-grid">
          <div className="rmz-story-heading" data-rise>
            <p className="rmz-kicker">A BRAND BETWEEN ROOTS AND ROUTES</p>
            <h2>ROOTED<br />IN <em>MORE.</em></h2>
          </div>
          <div className="rmz-story-copy" data-rise>
            <p className="rmz-story-lead">The olive tree keeps its own calendar. SIDRA begins there — in the long memory of a branch, and the hands that return to it.</p>
            <p style={{ marginTop: 14 }}>We built a contemporary olive oil identity around the rituals that travel with us. Not a postcard of the past, but a living mark of place: bold, generous, and made to be passed around the table.</p>
            <div className="rmz-project-facts">
              <div><span>THE ASK</span><strong>Give heritage a new voice</strong></div>
              <div><span>THE WORK</span><strong>Identity, packaging, campaign</strong></div>
              <div><span>THE WORLD</span><strong>Eastern Mediterranean</strong></div>
            </div>
          </div>
        </div>
        <div className="rmz-story-image-row">
          <figure className="rmz-harvest-photo" data-rise>
            <img src="/pour.jpg" alt="Olive oil poured over olives" />
            <figcaption><span>THE RITUAL, IN CLOSE-UP</span><span>01 / 03</span></figcaption>
          </figure>
          <blockquote className="rmz-pull-quote" data-rise>NOT PRODUCT<br />FROM THE LAND.<br /><em>A STORY CARRIED<br />BY IT.</em></blockquote>
        </div>
      </section>

      <section className="rmz-proof">
        <div className="rmz-proof-heading">
          <div data-rise><p className="rmz-kicker">02 — THE WORKING PROOF</p><h2>EVERY INK<br />HAS A <em>REASON.</em></h2></div>
          <p className="rmz-proof-intro">A little misregistration makes the image feel handmade. Pull the plates apart and see what holds the picture together.</p>
        </div>
        <div className="rmz-proof-controls">
          <div className="rmz-plate-switch">
            {PLATES.map(([k, l]) => (
              <button key={k} className={`rmz-plate-button${plate === k ? " is-active" : ""}`} onClick={() => setPlate(k)}>{l.toUpperCase()}</button>
            ))}
          </div>
          <label className="rmz-registration-control">
            <span>REGISTRATION</span>
            <input type="range" min={0} max={30} value={reg} onChange={(e) => setReg(+e.target.value)} aria-label="Registration" />
            <output>{reg}</output>
          </label>
        </div>
        <div className="rmz-proof-art" data-plate={plate} style={vars}>
          <img className="rmz-proof-base" src="/hero.jpg" alt="Sidra bottle, four-colour screenprint study" />
          <img className="rmz-proof-separation rmz-separation-oxide" src="/hero.jpg" alt="" />
          <img className="rmz-proof-separation rmz-separation-leaf" src="/hero.jpg" alt="" />
          <img className="rmz-proof-separation rmz-separation-sun" src="/hero.jpg" alt="" />
          <div className="rmz-proof-caption"><span>SIDRA / EDITION 01</span><span>FOUR INKS, ONE STORY</span></div>
        </div>
        <div className="rmz-proof-footnote"><span>SCREENPRINT STUDY / 04 COLOUR PASSES</span><span>DRAG THE REGISTER <Arrow d="right" /></span></div>
      </section>

      <section className="rmz-object">
        <div className="rmz-object-copy" data-rise>
          <div className="rmz-story-index"><span>03 — THE OBJECT</span><i className="rmz-index-rule" /></div>
          <p className="rmz-kicker">MADE TO BE KEPT CLOSE</p>
          <h2>A GOOD<br />THING<br /><em>TRAVELS.</em></h2>
          <p className="rmz-object-description">A simple vessel, treated like a keepsake. Olive-paper wrap, a wild branch, and a mark that leaves room for the land to speak.</p>
          <div className="rmz-object-signoff"><span>SIDRA / BOTTLE STUDY</span><span>750 ML — FIRST HARVEST</span></div>
        </div>
        <figure className="rmz-object-image" data-rise>
          <img src="/bottle.jpg" alt="Olive-paper wrapped Sidra bottle on a block" />
          <figcaption><span>FORM FOLLOWS THE FIELD</span><span>02 / 03</span></figcaption>
        </figure>
        <span className="rmz-object-wordmark">SIDRA</span>
      </section>

      <section className="rmz-closing">
        <p className="rmz-kicker">RMZ — REALITY, UNDER RECONSTRUCTION</p>
        <h2 data-rise>MAKE ROOM<br />FOR <em>MORE.</em></h2>
        <div className="rmz-closing-bottom">
          <p>SIDRA / AN RMZ CONCEPT PROJECT<br />IDENTITY · CAMPAIGN · IMAGE-MAKING</p>
          <a className="rmz-back-top" href="#">BACK TO THE SURFACE <Arrow /></a>
        </div>
      </section>
      <footer className="rmz-footer"><span>RMZ — REBEL MIND ZONE</span><span>CAIRO / RAMALLAH / EVERYWHERE</span><span>© 2025</span></footer>
    </div>
  );
}
