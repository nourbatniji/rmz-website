import type { Metadata } from "next";
import "@fontsource-variable/figtree";
import "@fontsource/playfair-display/600-italic.css";
import "./globals.css";

export const metadata: Metadata = {
  title: "The Land Remembers — SIDRA · RMZ",
  description: "SIDRA — olive oil, reimagined. An RMZ concept project.",
};
const boot = `(function(){var d=document.documentElement;if(!matchMedia('(prefers-reduced-motion: reduce)').matches)d.classList.add('js-motion')})()`;
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head><script dangerouslySetInnerHTML={{ __html: boot }} /></head>
      <body>{children}</body>
    </html>
  );
}
