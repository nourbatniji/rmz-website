# SIDRA — The Land Remembers (red accent)
npm install && npm run dev  (standalone prototype; not integrated with production)
Accent: --red in app/globals.css. Photos are cropped/stitched from screenshots.
