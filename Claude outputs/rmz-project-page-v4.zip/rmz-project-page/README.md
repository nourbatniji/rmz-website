# RMZ — Project Details Page prototype ("Out of Register", hybrid)

Standalone prototype. Nothing here touches the production RMZ site.
Stack: Next.js (App Router, static export) · React · GSAP + ScrollTrigger · plain CSS. No CMS, DB or backend.

```
pnpm install      # or npm install
pnpm dev          # http://localhost:3000  → redirects to /work/zahr/
pnpm build        # static export to /out
```
Routes: `/work/zahr/` (full demo) and `/work/maqam/` (short second project, proves reuse + the next-project handoff).

## Structure
```
lib/projects.ts            content model (maps to the planned Project schema) + 2 demo projects
lib/motion.ts              GSAP setup, rmzOut / rmzInOut eases, useMotion() (reduced-motion + mobile aware, auto-revert)
components/ProjectPage.tsx assembles chapters in the order given by project.gallery
components/Header.tsx      chapter counter, progress bar, full-screen chapter index
components/art/*           generated SVG artwork (bloom/arch plates, cans, wraps, posters, billboards, stills)
components/sections/*      Hero, Intro, Concept, ChapterTitle, Chapters1-3, End (Outcome + NextProject)
styles/*.css               per-area CSS; each CSS file describes the RESTING state, JS animates away from it
```
Integration notes: drop `components/sections`, `components/art` replacement (real images), `lib/motion.ts` and `styles/` into
`/work/[slug]`; replace `lib/projects.ts` with the DB read. `gallery: string[]` decides which chapters a project shows.

## Signature interactions
| # | Name | Where | What happens | Mobile |
|---|------|-------|--------------|--------|
| 1 | Registration Lock | Hero, Next-project | 4 ink plates + title ghosts drift into register as a small displaced frame expands to full-bleed | frame/plates re-fit to portrait, shorter pin |
| 2 | Plate Stack | Concept | exploded isometric stack; each plate drops in with its caption, then the stack straightens into the final print | pinned, caption under stage |
| 3 | Scale Drop | Identity | wordmark starts at 8× (you're inside the letters), zooms out to reveal mark, seal and lockups | scrubs while scrolling past, no pin |
| 4 | Weight Field | Typography | per-letter variable-font weight follows the pointer; idle sweep keeps it alive on touch | sweep only, drag to play |
| 5 | Colour Tide | Colour | each colour floods the screen from a different origin (circle clip), usage bar tracks the active colour | stacked panels flood in as they scroll |
| 6 | Unwrap | Packaging | one flat label = one revolution; scroll turns the can through 3 flavours, dieline shows the visible window | pinned, smaller can |
| 7 | Fold-Out Billboard | Campaign | 4-panel nested accordion unfolds in 3D to a full billboard | folds vertically with a portrait billboard |
| 8 | Detail Reveal | Photography | pins zoom the image in place to a detail and open the note beside it (no modal) | same, tap |
| 9 | Feed Drift | Social | 3 columns drift at different speeds; skew follows scroll velocity | 2 columns |
| 10 | Scroll the Site | Digital | browser mock scrolls through hero → flavours → locator, tilts flat as you arrive; 6 s brand loop with play/pause + timecode | same |
| 11 | Invasion | Next project | next project's plates wipe in diagonally over the closing wordmark, lock, title becomes dominant; click expands a colour curtain that the next page's hero peels away | pinned, scaled titles |

Only 1–3 and the Next-project handoff use the print metaphor. Chapters alternate between pinned moments and quiet/typographic ones.

## Motion rules implemented
Scrub 0.25 (no heavy lag), no scroll hijacking (native scroll only), pin lengths ≈ 0.9–3 viewports, `prefers-reduced-motion` → no JS motion at all
(resting states are the finished states), every effect lives in `gsap.matchMedia` and is reverted on unmount/breakpoint change.

## Not done / needs real-world verification
- Artwork is generated SVG stand-ins (incl. "photography"), not real photos. Swap `components/art/*` for `<img>`/`next/image` per project.
- Not compared against the live homepage visuals (none were provided); tokens, type roles and easings follow `rmz-development-plan.md`.
- Verified only in headless Chromium (desktop, 390 px mobile emulation, 820 px tablet, reduced-motion). Not tested on real iOS/Android, Safari, Firefox,
  or a trackpad/mouse wheel. Frame-rate was not profiled. 3D folds and mix-blend plates are the first things to check on mid-range phones.
- Demo copy and metrics are fictional.

---

## V2 — Project Stories (`/v2/[slug]/`)

V1 (`/work/[slug]/`) is untouched. `/` is a chooser for all four pages.

**Content model** — `lib/stories.ts`. A story is metadata + an ordered `blocks[]` array
(`feature | pair | detail | sequence | video`) + optional `details[]`. The page renders whatever
blocks exist; there is no packaging/type/colour/social chapter. Assets are `{ art, v, ratio, caption }`
(procedural stand-ins today; add `src` for real photography/video).

- `zahr` — brand + packaging + campaign (7 blocks + a Details section)
- `dusk` — photography/campaign/film, no packaging or identity system, no Details section (optional section proves itself)

**Structure** — `components/v2/`: `Hero2`, `Overview`, `Showcase` (block renderers, one reveal, one
parallax, one block-to-block recede, tone shift black↔cream), `Reel` (video feature; plays `src` if given),
`Details` (optional), `NextStory` (one transition), `Lightbox`, `Header2`, `StoryPage`.
Footer reuses `sections/Footer.tsx` (a placeholder — swap in the real homepage footer).

**Motion** — no pins, no scroll traps. Hero entrance + eases away under the overview; frames wipe in with the
image settling; parallax on dominant images (desktop); leaving blocks recede; next cover lifts to full screen
and the new hero settles beneath it. Reduced motion: final states shown, transitions off.

**Not verified** — real devices/Safari/Firefox; real photography/video (art is generated SVG); the homepage footer.

### V2 — restyled to match the real RMZ site
V2 now uses the rmz-website design language: same tokens (ink/cream/yellow/orange/red), Figtree + Playfair italic accents, `t-meta`/`t-display`/`t-body` roles, square corners with 1px cream frames, yellow rectangular CTAs, the SiteHeader (gradient → solid bar, yellow-dot logo), the real Footer (copied verbatim, with its fit/entrance hooks), the cream "Next project" panel and the yellow play disc on the film block. Breakpoint is 1024px as in the repo. Art is still procedural SVG stand-ins.

## V3 — project details page, in the homepage language (`/v3/zahr/`, `/v3/dusk/`)
Prototype of the page opened from "Selected work" (the real one is `/work/[slug]`). Nothing in the real site was edited.
1. Hero: name arrives letter by letter (statement-rotator skew + blur); cover is a cream card with caption strip that tilts with the pointer and tips back on scroll.
2. Statement: the homepage rotator, one line about the project with a changing red italic word.
3. Brief: challenge / approach / services, masked reveals.
4. Wall: the featured-work wall. Pinned, scroll-driven perspective cards; the centred card turns over to say what it is. Rows, buttons and ← → also navigate. Reduced-motion gets a static list.
5. Film: starts as a framed window and opens to full screen on scroll.
6. Credits: the red "minds" fins (verbatim homepage CSS), scroll-linked reveal, accordion on mobile.
7. Next project + the real footer.
Art is still procedural SVG stand-ins; credit names are placeholders.

## V4 — case-study page (`/v4/zahr/`, `/v4/dusk/`)
A page built for reading one project, not borrowed from the homepage. Nothing in the real site was edited.
- Full-bleed opening with the facts a client looks for first; chapter rail + reading progress; cursor bubble (View / Play / Open).
- 01 Brief: the paragraph lights up word by word as you scroll.
- 02 Idea: sticky picture that changes with the beat you are reading.
- 03 Work: each block has its own rhythm (image grows into place, pairs drift at different speeds, a sequence slides sideways, film scales up) + lightbox.
- 04 Outcome: counting facts, deliverables list with a hover preview of each piece.
- 05 Credits, then next project with the cover-expand transition, and the real footer.
