'use client'
import { useEffect, useRef, useState, type CSSProperties } from 'react'
import type { Story } from '@/lib/stories'

const v = (o: Record<string, string>) => o as CSSProperties
/** The homepage statement rotator, written for a project: the idea in one line, one italic word that keeps changing. */
export default function Statement3({ s }: { s: Story }) {
  const { lines, words, post } = s.stm!
  const root = useRef<HTMLElement>(null)
  const [run, setRun] = useState(false)
  const [reduce, setReduce] = useState(false)
  const [cur, setCur] = useState(0)
  const [out, setOut] = useState<number | null>(null)

  useEffect(() => {
    const r = matchMedia('(prefers-reduced-motion: reduce)').matches
    setReduce(r)
    const io = new IntersectionObserver(([e]) => setRun(e.isIntersecting), { threshold: 0.4 })
    io.observe(root.current!)
    return () => io.disconnect()
  }, [])
  useEffect(() => {
    if (!run || reduce) return
    const id = setInterval(() => {
      setCur((c) => { setOut(c); return (c + 1) % words.length })
      setTimeout(() => setOut(null), 700)
    }, 2700)
    return () => clearInterval(id)
  }, [run, reduce, words.length])

  let w = 0
  const flow = (txt: string) => txt.split(' ').map((t) => (
    <span className="stm-w" key={w} style={v({ '--d': `${80 + w++ * 70}ms` })}>{t}&nbsp;</span>
  ))
  const slot = (
    <span className="stm-slot stm-w2">
      {words.map((word, k) => (
        <span key={word} className={`stm-w stm-lw${cur === k && run ? ' in' : ''}${out === k ? ' out' : ''}`} aria-hidden={cur !== k}>
          {word.split('').map((c, j) => <span className="stm-lt" key={j} style={v({ '--d': `${160 + j * 45}ms`, '--x': `${j * 22}ms` })}>{c}</span>)}
        </span>
      ))}
    </span>
  )
  return (
    <section className={`stm-root stm3${run ? ' stm-on' : ''}${reduce ? ' stm-st' : ''}`} ref={root} aria-label={`${lines.join(' ')} ${words[0]} ${post ?? ''}`}>
      <div className="stm-stage">
        <div className={`stm-txt stm-wrap${run || reduce ? ' in' : ''}${reduce ? ' static' : ''}${run ? ' intro' : ''}`} aria-hidden="true">
          {lines.map((ln, i) => (
            <span className="stm-ln" key={i}><span className="stm-lni">{flow(ln)}{i === lines.length - 1 && slot}</span></span>
          ))}
          {post && <span className="stm-ln"><span className="stm-lni">{flow(post)}</span></span>}
        </div>
        <div className="stm-foot t-meta">
          <span className="stm-count stm-lab">{String(cur + 1).padStart(2, '0')} / {String(words.length).padStart(2, '0')}</span>
          <span className="stm3-meta stm-lab">
            <span><b>Client</b>{s.client}</span><span><b>Year</b>{s.year}</span><span><b>Location</b>{s.location}</span>
          </span>
        </div>
      </div>
    </section>
  )
}
