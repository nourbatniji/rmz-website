'use client'
import { useEffect, useRef, useState, type CSSProperties } from 'react'
import type { Story } from '@/lib/stories'
import { ScrollTrigger, useMotion } from '@/lib/motion'
import { Art } from '../v2/Art'

const two = (n: number) => String(n).padStart(2, '0')
/** The homepage "minds" fins, for the people and disciplines behind a project: red columns that rise in on scroll,
 *  one opens into a cream plate on hover (desktop) or tap (accordion on mobile). */
export default function Credits3({ s }: { s: Story }) {
  const items = s.credits!
  const n = items.length
  const ref = useRef<HTMLElement>(null)
  const list = useRef<HTMLUListElement>(null)
  const [open, setOpen] = useState(0)
  const [slots, setSlots] = useState<number[] | null>(null)
  useEffect(() => { const a = Array.from({ length: n }, (_, i) => i); for (let i = n - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]] } setSlots(a) }, [n])

  useMotion(ref, ({ el }) => {
    if (!matchMedia('(min-width: 1024px)').matches) return
    el.dataset.reveal = 'on'
    const l = list.current!
    const st = ScrollTrigger.create({ trigger: l, start: 'top 92%', end: 'top 18%', scrub: true, onUpdate: (self) => l.style.setProperty('--rp', String(self.progress)) })
    l.style.setProperty('--rp', '0')
    return () => { st.kill(); delete el.dataset.reveal; l.style.removeProperty('--rp') }
  })

  const shut = 'var(--shut)', gap = 'var(--gap)'
  const left = (i: number) => (i <= open ? `calc(${i} * (${shut} + ${gap}))` : `calc(${i - 1} * (${shut} + ${gap}) + var(--open) + ${gap})`)
  const desk = () => matchMedia('(min-width: 1024px)').matches
  return (
    <section className="minds-root c3" ref={ref} aria-label="Credits">
      <div className="c3-head">
        <p className="t-meta">06 — Credits</p>
        <h2 className="t-display c3-h">Who made <span className="t-italic">it.</span></h2>
        <p className="t-meta c3-n">{two(n)} disciplines · names to be confirmed</p>
      </div>
      <div className="minds-stage">
        <ul className="minds-list" ref={list} style={{ ['--n' as string]: n } as CSSProperties}>
          {items.map((c, i) => (
            <li key={c.role} className={`mind${open === i ? ' mind-open' : ''}`}
              style={{ ['--i' as string]: i, ['--o' as string]: slots ? slots[i] : i, ['--l' as string]: left(i), ['--w' as string]: open === i ? 'var(--open)' : 'var(--shut)' } as CSSProperties}
              onMouseEnter={() => { if (desk() && matchMedia('(hover: hover)').matches) setOpen(i) }}>
              <button type="button" className="mind-cover" aria-expanded={open === i} onClick={() => setOpen((o) => (desk() ? i : o === i ? -1 : i))} onFocus={() => { if (desk()) setOpen(i) }}>
                <span className="mind-num t-meta">{two(i + 1)}</span>
                <span className="mind-title">{c.role}</span>
                <span className="mind-icon" aria-hidden="true" />
              </button>
              <div className="mind-plate"><div className="mind-plate-in">
                <div className="mind-img"><Art a={c.art} s={s} /></div>
                <div className="mind-body">
                  <p className="mind-kicker t-meta">{two(i + 1)} — Name pending</p>
                  <h3 className="mind-h">{c.role}</h3>
                  <p className="mind-d">{c.note}</p>
                </div>
              </div></div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
