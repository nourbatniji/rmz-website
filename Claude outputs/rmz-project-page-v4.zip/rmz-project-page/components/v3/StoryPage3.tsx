'use client'
import { useEffect, useMemo, useState } from 'react'
import { stories } from '@/lib/stories'
import { ScrollTrigger } from '@/lib/motion'
import Header2 from '../v2/Header2'
import NextStory from '../v2/NextStory'
import Lightbox from '../v2/Lightbox'
import { Footer } from '../v2/real/Footer'
import { footerContent } from '@/lib/site'
import Hero3 from './Hero3'
import Statement3 from './Statement3'
import Brief3 from './Brief3'
import Wall3, { platesOf } from './Wall3'
import Film3 from './Film3'
import Credits3 from './Credits3'
import '../../styles/v2.css'
import '../../styles/v3.css'

export default function StoryPage3({ slug }: { slug: string }) {
  const s = stories[slug]
  const [at, setAt] = useState<number | null>(null)
  const plates = useMemo(() => platesOf(s), [s])
  useEffect(() => {
    window.scrollTo(0, 0)
    document.fonts?.ready.then(() => ScrollTrigger.refresh())
    const t = setTimeout(() => ScrollTrigger.refresh(), 700)
    return () => clearTimeout(t)
  }, [slug])
  return (
    <main className="v2 v3" key={slug}>
      <Header2 />
      <Hero3 s={s} />
      <Statement3 s={s} />
      <Brief3 s={s} />
      <Wall3 s={s} plates={plates} open={setAt} />
      <Film3 s={s} />
      <Credits3 s={s} />
      <NextStory s={s} next={stories[s.next]} base="v3" />
      <Footer content={footerContent} />
      <Lightbox s={s} list={plates.map((p) => p.asset)} at={at} set={setAt} />
    </main>
  )
}
