'use client'
import { useRef } from 'react'
import Link from 'next/link'
import type { Story } from '@/lib/stories'
import { gsap, useMotion } from '@/lib/motion'
import { Art } from '../v2/Art'

/** Hero in the homepage language: the name arrives letter by letter (the statement's skew + blur), the cover is a cream card
 *  with a caption strip that turns in 3D, follows the pointer a little and tips away as you scroll. */
export default function Hero3({ s }: { s: Story }) {
  const ref = useRef<HTMLElement>(null)
  useMotion(ref, ({ el, mobile }) => {
    const xfer = document.querySelector<HTMLElement>('.v2-xfer')
    const tl = gsap.timeline({ defaults: { ease: 'rmzOut' } })
    if (xfer) tl.to(xfer, { clipPath: 'inset(0 0 100% 0)', duration: 1.1, ease: 'rmzInOut', delay: 0.1, onComplete: () => xfer.remove() }, 0)
    const d = xfer ? 0.55 : 0.05
    tl.from('.h3-card', { y: 80, opacity: 0, duration: 1.3 }, d)
    tl.from('.h3-face', { clipPath: 'inset(0 0 100% 0)', rotationY: -28, rotationX: 8, transformPerspective: 1400, transformOrigin: '50% 50%', duration: 1.7 }, d)
    tl.from('.h3-im', { scale: 1.3, duration: 2 }, d)
    tl.from('.h3-l', { yPercent: 125, rotate: 9, skewX: -12, opacity: 0, filter: 'blur(8px)', transformOrigin: '0 100%', duration: 1.1, stagger: 0.07, ease: 'back.out(1.3)' }, d + 0.25)
    tl.from('.h3-top > *, .h3-foot > *', { opacity: 0, y: 14, duration: 1, stagger: 0.07 }, d + 0.7)

    // scroll: the card tips back and drifts, the name slides the other way, the chrome fades — no pin
    const st = { trigger: el, start: 'top top', end: 'bottom top', scrub: 0.4 }
    gsap.to('.h3-scr', { rotationY: mobile ? 0 : -14, rotationX: mobile ? 0 : 7, yPercent: -8, scale: 0.94, transformPerspective: 1400, ease: 'none', scrollTrigger: st })
    gsap.to('.h3-title', { xPercent: mobile ? 0 : -5, yPercent: mobile ? 0 : 8, ease: 'none', scrollTrigger: st })
    gsap.to('.h3-foot, .h3-top', { opacity: 0, ease: 'none', scrollTrigger: { trigger: el, start: '35% top', end: '85% top', scrub: true } })

    // pointer: a gentle 3D follow (fine pointers only)
    if (matchMedia('(hover: hover) and (min-width: 1024px)').matches) {
      const ry = gsap.quickTo('.h3-pt', 'rotationY', { duration: 0.8, ease: 'power3.out' })
      const rx = gsap.quickTo('.h3-pt', 'rotationX', { duration: 0.8, ease: 'power3.out' })
      gsap.set('.h3-pt', { transformPerspective: 1400 })
      const mv = (e: MouseEvent) => { ry(((e.clientX / innerWidth) - 0.5) * 12); rx(((e.clientY / innerHeight) - 0.5) * -8) }
      el.addEventListener('mousemove', mv)
      return () => el.removeEventListener('mousemove', mv)
    }
  })
  const letters = s.name.split('')
  return (
    <section className="h3" ref={ref}>
      <div className="h3-top">
        <Link href="/" className="t-meta wk-back">← All work</Link>
        <span className="t-meta h3-lab">{s.number} · {s.category} · {s.year}</span>
      </div>
      <div className="h3-card">
        <div className="h3-scr"><div className="h3-pt"><div className="h3-face">
          <div className="h3-img"><div className="h3-im"><Art a={s.cover} s={s} /></div></div>
          <div className="h3-strip"><b>{s.name}</b><u>{s.number}</u></div>
        </div></div></div>
      </div>
      <h1 className="h3-title" aria-label={s.name}>{letters.map((c, i) => <span className="h3-l" key={i} aria-hidden="true">{c}</span>)}</h1>
      <div className="h3-foot">
        <p className="h3-st t-body">{s.statement}</p>
        <p className="h3-cue t-meta"><i />Scroll</p>
        <p className="h3-full t-meta">{s.fullName}</p>
      </div>
    </section>
  )
}
