'use client'
import { useRef } from 'react'
import type { Block, Story } from '@/lib/stories'
import { gsap, useMotion } from '@/lib/motion'
import Reel from '../v2/Reel'

/** The corridor arrival: the film starts as a framed window and opens to the full screen as you scroll. */
export default function Film3({ s }: { s: Story }) {
  const ref = useRef<HTMLElement>(null)
  const b = s.blocks.find((x) => x.t === 'video') as Extract<Block, { t: 'video' }> | undefined
  useMotion(ref, ({ el, mobile }) => {
    const track = el.querySelector('.f3-track')!
    const from = mobile ? 'inset(36% 6% 24% 6%)' : 'inset(42% 22% 10% 22%)'
    gsap.fromTo('.f3-frame', { clipPath: from }, { clipPath: 'inset(0% 0% 0% 0%)', ease: 'none', scrollTrigger: { trigger: track, start: 'top top', end: '70% bottom', scrub: 0.4 } })
    gsap.fromTo('.f3-in', { scale: 1.28 }, { scale: 1, ease: 'none', scrollTrigger: { trigger: track, start: 'top top', end: '70% bottom', scrub: 0.4 } })
    gsap.to('.f3-title', { yPercent: -30, opacity: 0, ease: 'none', scrollTrigger: { trigger: track, start: '8% top', end: '44% top', scrub: true } })
    gsap.fromTo('.f3-cap', { opacity: 0, y: 24 }, { opacity: 1, y: 0, ease: 'none', scrollTrigger: { trigger: track, start: '40% top', end: '62% top', scrub: true } })
    gsap.from('.f3-title .ln > span', { yPercent: 110, duration: 1.3, stagger: 0.09, ease: 'rmzOut', scrollTrigger: { trigger: el, start: 'top 65%', once: true } })
  })
  if (!b) return null
  const i = s.blocks.indexOf(b) + 1
  return (
    <section className="f3" ref={ref} aria-label={b.label}>
      <div className="f3-track">
        <div className="f3-stage">
          <h2 className="f3-title t-display"><span className="ln"><span>The work,</span></span><span className="ln"><span>in <i className="t-italic">motion.</i></span></span></h2>
          <div className="f3-frame"><div className="f3-in"><Reel b={b} s={s} /></div>
            <div className="f3-cap"><p className="t-meta wk-y">{String(i).padStart(2, '0')} — {b.title}</p><p className="f3-lbl t-display">{b.label}</p></div>
          </div>
        </div>
      </div>
    </section>
  )
}
