'use client'
import { useCallback, useRef, useState, type CSSProperties } from 'react'
import type { Asset, Story } from '@/lib/stories'
import { ScrollTrigger, useMotion } from '@/lib/motion'
import { Art } from '../v2/Art'

export type Plate = { title: string; text: string; asset: Asset; cap: string; tag: string }
const tagOf = (a: Asset, film = false) => (film ? 'Film' : a.art === 'still' || a.art === 'scene' ? 'Photo' : a.art === 'poster' || a.art === 'billboard' || a.art === 'cans' ? 'Print' : 'Digital')

/** One plate per block: the picture that carries it, its name and one line of why. */
export function platesOf(s: Story): Plate[] {
  return s.blocks.map((b) => {
    const film = b.t === 'video'
    const asset = b.t === 'feature' ? b.asset : b.t === 'pair' ? b.a : b.t === 'detail' ? b.main : b.t === 'sequence' ? b.items[0] : b.frames[0]
    return { title: b.title ?? 'Selected work', text: b.text ?? '', asset, cap: film ? b.label : asset.caption ?? '', tag: tagOf(asset, film) }
  })
}
const two = (n: number) => String(n).padStart(2, '0')

/** The homepage "featured work" wall for a project: a perspective row of cream cards moved by scroll;
 *  the card that settles in the centre turns over to say what it is. Click a row, press ← →, or just scroll. */
export default function Wall3({ s, plates, open }: { s: Story; plates: Plate[]; open: (i: number) => void }) {
  const root = useRef<HTMLElement>(null)
  const n = plates.length
  const [act, setAct] = useState(0)
  const [flip, setFlip] = useState<number | null>(null)
  const jump = useRef<(i: number) => void>(() => {})

  useMotion(root, ({ el, mobile }) => {
    const track = el.querySelector<HTMLElement>('.w3-track')!
    const stage = el.querySelector<HTMLElement>('.w3-stage')!
    const cards = Array.from(el.querySelectorAll<HTMLElement>('.w3-card'))
    const bar = el.querySelector<HTMLElement>('.w3-bar i')!
    const hh = () => parseFloat(getComputedStyle(el).getPropertyValue('--header-h')) || 84
    let target = 0, cur = 0, moved = performance.now(), flipped = -1, shown = -1, raf = 0
    const st = ScrollTrigger.create({ trigger: track, start: () => `top top+=${hh()}`, end: 'bottom bottom', onUpdate: (self) => { target = self.progress * (n - 1); moved = performance.now() } })
    const tick = () => {
      cur += (target - cur) * 0.13
      if (Math.abs(target - cur) < 0.0006) cur = target
      const w = cards[0].offsetWidth
      const dx = w * (mobile ? 1.0 : 1.22), dz = mobile ? 110 : 230, ry = mobile ? 28 : 34
      cards.forEach((c, i) => {
        const d = i - cur, ad = Math.abs(d), cl = Math.max(-1.7, Math.min(1.7, d))
        c.style.transform = `translate3d(${d * dx}px,0,${-Math.min(ad, 2.4) * dz}px) rotateY(${-cl * ry}deg)`
        c.style.opacity = String(Math.max(0, Math.min(1, 3.4 - ad)))
        c.style.filter = `brightness(${(1 - Math.min(1, ad) * 0.5).toFixed(3)})`
        c.style.zIndex = String(100 - Math.round(ad * 10))
        c.style.pointerEvents = ad < 0.5 ? 'auto' : 'none'
      })
      bar.style.width = `${(cur / Math.max(1, n - 1)) * 100}%`
      const idx = Math.max(0, Math.min(n - 1, Math.round(cur)))
      if (idx !== shown) { shown = idx; setAct(idx) }
      const settled = Math.abs(target - cur) < 0.01 && performance.now() - moved > 520
      const want = settled ? idx : -1
      if (want !== flipped) { flipped = want; setFlip(want < 0 ? null : want) }
      raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    jump.current = (i) => {
      const k = Math.max(0, Math.min(n - 1, i))
      const step = (track.offsetHeight - stage.offsetHeight) / Math.max(1, n - 1)
      scrollTo({ top: track.getBoundingClientRect().top + scrollY - hh() + k * step + 1, behavior: 'smooth' })
    }
    return () => { cancelAnimationFrame(raf); st.kill() }
  })

  const go = useCallback((i: number) => jump.current(i), [])
  const p = plates[act]
  return (
    <section className="w3" ref={root} style={{ ['--n' as string]: n } as CSSProperties} aria-label="Selected work">
      <div className="w3-flip">
        <div className="w3-track">
          <div className="w3-stage" tabIndex={0} onKeyDown={(e) => { if (e.key === 'ArrowRight') { e.preventDefault(); go(act + 1) } if (e.key === 'ArrowLeft') { e.preventDefault(); go(act - 1) } }}>
            <div className="w3-top t-meta">
              <span>05 — Selected work</span>
              <span className="w3-bar" aria-hidden="true"><i /></span>
              <span className="w3-step">{two(act + 1)} / {two(n)}</span>
            </div>
            <div className="w3-wall"><ul className="w3-cards">
              {plates.map((pl, i) => (
                <li className={`w3-card${flip === i ? ' on' : ''}`} key={i} style={{ zIndex: 100 - i }}>
                  <div className="w3-turn" onClick={() => setFlip((f) => (f === i ? null : i))}>
                    <div className="w3-face w3-front">
                      <div className="w3-img"><Art a={pl.asset} s={s} /><span className="w3-pend t-meta">{pl.tag}</span></div>
                      <div className="w3-strip"><b>{pl.title}</b><u>{two(i + 1)}</u></div>
                    </div>
                    <div className="w3-face w3-back">
                      <div className="w3-inner">
                        <div className="w3-btop t-meta"><span>{two(i + 1)} — {pl.tag}</span><span>{s.name}</span></div>
                        <h3 className="w3-bh">{pl.title}</h3>
                        <p className="w3-bp">{pl.text}</p>
                        <div className="w3-bfoot"><span>{pl.cap}</span><button type="button" className="w3-bbtn" onClick={(e) => { e.stopPropagation(); open(i) }}>View ↗</button></div>
                      </div>
                    </div>
                  </div>
                </li>
              ))}
            </ul></div>
            <div className="w3-ui">
              <div className="w3-left">
                <p className="w3-readout t-meta" aria-live="polite">{two(act + 1)} — {p.title}{p.cap ? ` · ${p.cap}` : ''}</p>
                <div className="w3-ctl">
                  <button type="button" className="w3-pfb t-meta" disabled={act === 0} onClick={() => go(act - 1)}>← Previous</button>
                  <button type="button" className="w3-pfb t-meta" onClick={() => setFlip((f) => (f === act ? null : act))}>Turn card</button>
                  <button type="button" className="w3-pfb t-meta" disabled={act === n - 1} onClick={() => go(act + 1)}>Next →</button>
                </div>
                <p className="w3-note t-meta">Scroll to move the wall. Hold still to turn the card.</p>
              </div>
              <ol className="w3-list">
                {plates.map((pl, i) => (
                  <li key={i}><button type="button" className={`w3-pfr${i === act ? ' on' : ''}`} onClick={() => go(i)}><span>{two(i + 1)}</span><span>{pl.title}</span><span>{pl.tag}</span></button></li>
                ))}
              </ol>
            </div>
          </div>
        </div>
      </div>
      {/* reduced motion / no JS: every plate readable at once */}
      <div className="w3-static">
        <p className="t-meta wk-y">05 — Selected work</p>
        <ul>
          {plates.map((pl, i) => (
            <li key={i}><button type="button" className="w3-simg" style={{ aspectRatio: '4/3' }} onClick={() => open(i)}><Art a={pl.asset} s={s} /></button>
              <div><p className="t-meta wk-y">{two(i + 1)} — {pl.tag}</p><h3 className="t-display">{pl.title}</h3><p className="t-body">{pl.text}</p></div></li>
          ))}
        </ul>
      </div>
    </section>
  )
}
