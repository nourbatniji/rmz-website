'use client'
import { useRef } from 'react'
import type { Story } from '@/lib/stories'
import { gsap, useMotion } from '@/lib/motion'

export default function Brief3({ s }: { s: Story }) {
  const ref = useRef<HTMLElement>(null)
  useMotion(ref, ({ q, el }) => {
    q('.ov-row').forEach((r) => {
      const st = { trigger: r, start: 'top 88%', once: true }
      gsap.from(r, { clipPath: 'inset(0 0 100% 0)', y: 24, duration: 1.2, ease: 'rmzOut', scrollTrigger: st })
      gsap.from(r.querySelector('.br3-rule'), { scaleX: 0, transformOrigin: '0 50%', duration: 1.4, ease: 'rmzOut', scrollTrigger: st })
    })
    gsap.from(q('.br3-svc > span'), { opacity: 0, y: 12, stagger: 0.05, duration: 0.8, ease: 'rmzOut', scrollTrigger: { trigger: el, start: 'top 80%', once: true } })
  })
  return (
    <section className="br3" ref={ref}>
      <div className="ov-row-w wk-g12">
        <div className="ov-row"><i className="br3-rule" /><p className="t-meta wk-nm wk-y">02 — The challenge</p><p className="t-body ov-p">{s.overview.challenge}</p></div>
        <div className="ov-row"><i className="br3-rule" /><p className="t-meta wk-nm wk-y">03 — Our approach</p><p className="t-body ov-p">{s.overview.approach}</p></div>
        <div className="ov-row"><i className="br3-rule" /><p className="t-meta wk-nm wk-y">04 — Services</p><p className="br3-svc">{s.services.map((x) => <span className="t-meta" key={x}>{x}</span>)}</p></div>
      </div>
    </section>
  )
}
