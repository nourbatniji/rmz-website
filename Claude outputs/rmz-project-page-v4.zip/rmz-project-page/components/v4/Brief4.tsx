'use client'
import { useRef } from 'react'
import type { Story } from '@/lib/stories'
import { gsap, useMotion } from '@/lib/motion'

/** The brief reads itself: each word lights up as you scroll through the paragraph. */
export default function Brief4({ s }: { s: Story }) {
  const ref = useRef<HTMLElement>(null)
  const text = s.overview.lead.join('')
  useMotion(ref, ({ q, el }) => {
    const w = q('.b4-w')
    gsap.fromTo(w, { opacity: 0.16 }, { opacity: 1, stagger: 0.5, ease: 'none', scrollTrigger: { trigger: '.b4-text', start: 'top 78%', end: 'bottom 55%', scrub: true } })
    gsap.from(q('.b4-more > *'), { opacity: 0, y: 24, stagger: 0.1, duration: 1, ease: 'rmzOut', scrollTrigger: { trigger: '.b4-more', start: 'top 88%', once: true } })
    gsap.from('.b4-rule', { scaleX: 0, transformOrigin: '0 50%', duration: 1.4, ease: 'rmzOut', scrollTrigger: { trigger: el, start: 'top 80%', once: true } })
  })
  return (
    <section className="b4" ref={ref} id="ch-brief" data-chap="brief">
      <i className="b4-rule" />
      <div className="b4-g">
        <p className="t-meta wk-nm wk-y b4-lab">01 — The brief</p>
        <p className="b4-text">{text.split(' ').map((w, i) => <span className="b4-w" key={i}>{w} </span>)}</p>
      </div>
      <div className="b4-more">
        <div><p className="t-meta wk-nm wk-y">The challenge</p><p className="t-body">{s.overview.challenge}</p></div>
        <div><p className="t-meta wk-nm wk-y">What we made</p><p className="t-body">{s.overview.approach}</p></div>
      </div>
    </section>
  )
}
