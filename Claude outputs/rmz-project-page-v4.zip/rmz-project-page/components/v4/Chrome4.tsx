'use client'
import { useEffect, useState } from 'react'
import { gsap, ScrollTrigger } from '@/lib/motion'

const CH = [['brief', 'Brief'], ['idea', 'Idea'], ['work', 'Work'], ['outcome', 'Outcome'], ['credits', 'Credits']] as const
/** Page chrome for a long read: a progress line, a chapter rail, and a cursor that says what a click will do. */
export default function Chrome4() {
  const [on, setOn] = useState<string>('top')
  useEffect(() => {
    const secs = Array.from(document.querySelectorAll<HTMLElement>('[data-chap]'))
    const io = new IntersectionObserver((es) => es.forEach((e) => e.isIntersecting && setOn(e.target.getAttribute('data-chap')!)), { rootMargin: '-45% 0px -50% 0px' })
    secs.forEach((s) => io.observe(s))
    const bar = document.querySelector<HTMLElement>('.pg4 i')!
    const st = ScrollTrigger.create({ start: 0, end: 'max', onUpdate: (self) => { bar.style.transform = `scaleX(${self.progress})` } })
    let off = () => {}
    if (matchMedia('(hover: hover) and (min-width: 1024px)').matches && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
      const c = document.querySelector<HTMLElement>('.cur4')!
      const x = gsap.quickTo(c, 'x', { duration: 0.35, ease: 'power3' }), y = gsap.quickTo(c, 'y', { duration: 0.35, ease: 'power3' })
      const mv = (e: MouseEvent) => {
        x(e.clientX); y(e.clientY)
        const t = (e.target as HTMLElement).closest('.fr, .rl-stage, .nx2-frame, .k4-feat')
        const lab = t ? (t.matches('.rl-stage') ? 'Play' : t.matches('.nx2-frame') ? 'Open' : 'View') : ''
        c.classList.toggle('on', !!t && !(e.target as HTMLElement).closest('button.rl-btn, .rl-seek, .rl-big'))
        if (lab) c.firstElementChild!.textContent = lab
      }
      addEventListener('mousemove', mv); off = () => removeEventListener('mousemove', mv)
    }
    return () => { io.disconnect(); st.kill(); off() }
  }, [])
  const jump = (id: string) => document.getElementById(`ch-${id}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  return (
    <>
      <div className="pg4" aria-hidden="true"><i /></div>
      <nav className={`rail4${on === 'top' ? '' : ' show'}`} aria-label="Chapters">
        {CH.map(([id, l], i) => (<button type="button" key={id} className={on === id ? 'on' : ''} onClick={() => jump(id)}><em>{l}</em><span>{String(i + 1).padStart(2, '0')}</span></button>))}
      </nav>
      <div className="cur4" aria-hidden="true"><span>View</span></div>
    </>
  )
}
