'use client'
import { useRef } from 'react'
import type { Story } from '@/lib/stories'
import { gsap, useMotion } from '@/lib/motion'
import { Art } from '../v2/Art'
import { platesOf } from '../v3/Wall3'

const two = (n: number) => String(n).padStart(2, '0')
/** What was delivered: facts that count up, and a list whose rows show the piece under your cursor. */
export default function Outcome4({ s }: { s: Story }) {
  const ref = useRef<HTMLElement>(null)
  const items = platesOf(s)
  useMotion(ref, ({ q, el }) => {
    q('.o4-n').forEach((n) => {
      const to = parseInt(n.dataset.to!, 10), o = { v: 0 }
      gsap.to(o, { v: to, duration: 1.6, ease: 'power3.out', snap: { v: 1 }, onUpdate: () => { n.textContent = String(o.v) }, scrollTrigger: { trigger: n, start: 'top 88%', once: true } })
    })
    gsap.from(q('.o4-row'), { opacity: 0, y: 20, stagger: 0.06, duration: 0.9, ease: 'rmzOut', scrollTrigger: { trigger: '.o4-list', start: 'top 85%', once: true } })
    if (matchMedia('(hover: hover) and (min-width: 1024px)').matches) {
      const pv = el.querySelector<HTMLElement>('.o4-pv')!
      const x = gsap.quickTo(pv, 'x', { duration: 0.6, ease: 'power3' }), y = gsap.quickTo(pv, 'y', { duration: 0.6, ease: 'power3' })
      const list = el.querySelector('.o4-list')!
      const mv = (e: Event) => { const m = e as MouseEvent; x(m.clientX + 28); y(m.clientY - 150) }
      const rows = q('.o4-row')
      const enter = (i: number) => () => { pv.classList.add('on'); q('.o4-pi').forEach((p, k) => p.classList.toggle('on', k === i)) }
      const leave = () => pv.classList.remove('on')
      const offs = rows.map((r, i) => { const a = enter(i); r.addEventListener('mouseenter', a); return () => r.removeEventListener('mouseenter', a) })
      list.addEventListener('mousemove', mv); list.addEventListener('mouseleave', leave)
      return () => { offs.forEach((f) => f()); list.removeEventListener('mousemove', mv); list.removeEventListener('mouseleave', leave) }
    }
  })
  return (
    <section className="o4" ref={ref} id="ch-outcome" data-chap="outcome">
      <p className="t-meta wk-nm wk-y">04 — The outcome</p>
      <div className="o4-stats">
        {s.stats!.map((st) => (<div key={st.label}><p className="o4-big t-display"><span className="o4-n" data-to={st.n}>0</span></p><p className="t-meta wk-nm">{st.label}</p></div>))}
      </div>
      <p className="t-meta wk-nm o4-h">Delivered</p>
      <ol className="o4-list">
        {items.map((it, i) => (
          <li className="o4-row" key={i}><span className="t-meta">{two(i + 1)}</span><span className="o4-t">{it.title}</span><span className="t-meta o4-tag">{it.tag}</span></li>
        ))}
      </ol>
      <div className="o4-pv" aria-hidden="true">{items.map((it, i) => <div className="o4-pi" key={i}><Art a={it.asset} s={s} /></div>)}</div>
    </section>
  )
}
