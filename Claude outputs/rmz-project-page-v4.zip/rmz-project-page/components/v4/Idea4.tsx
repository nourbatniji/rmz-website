'use client'
import { useRef, useState } from 'react'
import type { Story } from '@/lib/stories'
import { ScrollTrigger, gsap, useMotion } from '@/lib/motion'
import { Art } from '../v2/Art'

/** The idea told in three beats. On desktop the picture stays put and changes with the beat you're reading. */
export default function Idea4({ s }: { s: Story }) {
  const idea = s.idea!
  const ref = useRef<HTMLElement>(null)
  const [on, setOn] = useState(0)
  useMotion(ref, ({ q, el }) => {
    q('.i4-key').forEach((k, i) => ScrollTrigger.create({ trigger: k, start: 'top 58%', end: 'bottom 58%', onToggle: (self) => self.isActive && setOn(i) }))
    gsap.from('.i4-line .ln > span', { yPercent: 110, duration: 1.3, stagger: 0.08, ease: 'rmzOut', scrollTrigger: { trigger: '.i4-line', start: 'top 80%', once: true } })
    q('.i4-key h3, .i4-key p').forEach((n) => gsap.from(n, { opacity: 0, y: 28, duration: 1, ease: 'rmzOut', scrollTrigger: { trigger: n, start: 'top 90%', once: true } }))
  })
  const [pre, post] = idea.line.split(idea.accent)
  return (
    <section className="i4" ref={ref} id="ch-idea" data-chap="idea">
      <p className="t-meta wk-nm wk-y">02 — The idea</p>
      <h2 className="i4-line t-display"><span className="ln"><span>{pre}<i className="t-italic">{idea.accent}</i>{post}</span></span></h2>
      <div className="i4-g">
        <div className="i4-side"><div className="i4-stack">
          {idea.keys.map((k, i) => <div className={`i4-img${on === i ? ' on' : ''}`} key={i}><Art a={k.art} s={s} /></div>)}
          <div className="i4-idx t-meta"><span>{String(on + 1).padStart(2, '0')}</span> / {String(idea.keys.length).padStart(2, '0')}</div>
        </div></div>
        <ol className="i4-keys">
          {idea.keys.map((k, i) => (
            <li className={`i4-key${on === i ? ' on' : ''}`} key={i}>
              <div className="i4-kimg"><Art a={k.art} s={s} /></div>
              <p className="t-meta wk-nm i4-n">{String(i + 1).padStart(2, '0')}</p>
              <h3 className="t-display">{k.t}</h3>
              <p className="t-body">{k.d}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  )
}
