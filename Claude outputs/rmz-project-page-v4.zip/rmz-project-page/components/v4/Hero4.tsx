'use client'
import { useRef } from 'react'
import Link from 'next/link'
import type { Story } from '@/lib/stories'
import { gsap, useMotion } from '@/lib/motion'
import { Art } from '../v2/Art'

/** Full-bleed opening: the picture, the name, and the facts a client looks for first. */
export default function Hero4({ s }: { s: Story }) {
  const ref = useRef<HTMLElement>(null)
  useMotion(ref, ({ el, mobile }) => {
    const xfer = document.querySelector<HTMLElement>('.v2-xfer')
    const tl = gsap.timeline({ defaults: { ease: 'rmzOut' } })
    if (xfer) tl.to(xfer, { clipPath: 'inset(0 0 100% 0)', duration: 1.1, ease: 'rmzInOut', delay: 0.1, onComplete: () => xfer.remove() }, 0)
    const d = xfer ? 0.55 : 0
    tl.from('.h4-img', { clipPath: 'inset(0 0 100% 0)', duration: 1.5 }, d)
    tl.from('.h4-im', { scale: 1.25, duration: 2.2 }, d)
    tl.from('.h4-l', { yPercent: 118, duration: 1.2, stagger: 0.06 }, d + 0.35)
    tl.from('.h4-top > *, .h4-meta > *', { opacity: 0, y: 14, duration: 1, stagger: 0.07 }, d + 0.8)
    const st = { trigger: el, start: 'top top', end: 'bottom top', scrub: 0.3 }
    gsap.to('.h4-im', { yPercent: mobile ? 6 : 12, scale: 1.06, ease: 'none', scrollTrigger: st })
    gsap.to('.h4-title', { yPercent: mobile ? 0 : -18, ease: 'none', scrollTrigger: st })
    gsap.to('.h4-dim', { opacity: 0.55, ease: 'none', scrollTrigger: st })
  })
  return (
    <section className="h4" ref={ref} data-chap="top">
      <div className="h4-img"><div className="h4-im"><Art a={s.hero ?? s.cover} s={s} /></div><div className="h4-shade" /><div className="h4-dim" /></div>
      <div className="h4-top">
        <Link href="/" className="t-meta wk-back">← All work</Link>
        <span className="t-meta h4-lab">{s.number} · {s.category}</span>
      </div>
      <h1 className="h4-title" aria-label={s.name}><span className="h4-ln">{s.name.split('').map((c, i) => <span className="h4-l" key={i} aria-hidden="true">{c}</span>)}</span></h1>
      <div className="h4-meta">
        <div><p className="t-meta">Client</p><p>{s.client}</p></div>
        <div><p className="t-meta">Services</p><p>{s.services.slice(0, 4).join(' · ')}</p></div>
        <div><p className="t-meta">Year</p><p>{s.year}</p></div>
        <div><p className="t-meta">Location</p><p>{s.location}</p></div>
      </div>
    </section>
  )
}
