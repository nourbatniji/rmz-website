'use client'
import { useRef } from 'react'
import type { Block, Story } from '@/lib/stories'
import { gsap, useMotion } from '@/lib/motion'
import { Frame } from '../v2/Frame'
import Reel from '../v2/Reel'
import { assetsOf } from '../v2/Showcase'

const two = (n: number) => String(n).padStart(2, '0')

function K({ b, i, total, base, s }: { b: Block; i: number; total: number; base: number; s: Story }) {
  return (
    <div className={`k4 kb-${b.t}`}>
      <div className="k4-head">
        <span className="t-meta wk-y">{two(i + 1)} — {b.title}</span>
        {b.text && <p className="t-body k4-text">{b.text}</p>}
        <span className="t-meta k4-c">{two(i + 1)} / {two(total)}</span>
      </div>
      {b.t === 'feature' && <div className="k4-feat"><Frame a={b.asset} s={s} i={base} /></div>}
      {b.t === 'pair' && (
        <div className={`k4-pair${b.flip ? ' flip' : ''}`}>
          <div className="k4-a" data-speed="-0.07"><Frame a={b.a} s={s} i={base} /></div>
          <div className="k4-b" data-speed="0.12"><Frame a={b.b} s={s} i={base + 1} /></div>
        </div>
      )}
      {b.t === 'detail' && (
        <div className="k4-det">
          <div className="k4-dm"><Frame a={b.main} s={s} i={base} /></div>
          <div className="k4-ds">
            {b.note && <p className="det-note">{b.note}</p>}
            {b.side.map((a, k) => <Frame key={k} a={a} s={s} i={base + 1 + k} />)}
          </div>
        </div>
      )}
      {b.t === 'sequence' && (
        <div className="k4-seq"><div className="k4-track">{b.items.map((a, k) => <div className="k4-si" key={k} style={{ marginTop: k % 2 ? 'clamp(24px,5vw,80px)' : 0 }}><Frame a={a} s={s} i={base + k} /></div>)}</div></div>
      )}
      {b.t === 'video' && <div className="k4-film"><Reel b={b} s={s} /></div>}
    </div>
  )
}

/** The work: every block keeps its own scroll rhythm — images grow into place, pairs drift at different speeds,
 *  a sequence slides sideways as you pass it. */
export default function Work4({ s }: { s: Story }) {
  const ref = useRef<HTMLElement>(null)
  let base = 0
  const bases = s.blocks.map((b) => { const x = base; base += assetsOf(b).length; return x })
  useMotion(ref, ({ q, mobile }) => {
    q('.k4-feat .fr').forEach((fr) => gsap.fromTo(fr, { clipPath: mobile ? 'inset(0 4% 0 4%)' : 'inset(6% 14% 6% 14%)' }, { clipPath: 'inset(0% 0% 0% 0%)', ease: 'none', scrollTrigger: { trigger: fr, start: 'top 92%', end: 'top 35%', scrub: 0.4 } }))
    q('.k4-feat .fr .im').forEach((r) => gsap.fromTo(r, { scale: 1.2 }, { scale: 1, ease: 'none', scrollTrigger: { trigger: r, start: 'top 95%', end: 'bottom 40%', scrub: 0.4 } }))
    if (!mobile) q('[data-speed]').forEach((el) => gsap.to(el, { yPercent: parseFloat(el.dataset.speed!) * 100, ease: 'none', scrollTrigger: { trigger: el.parentElement, start: 'top bottom', end: 'bottom top', scrub: 0.6 } }))
    q('.k4-seq').forEach((sq) => {
      const tr = sq.querySelector<HTMLElement>('.k4-track')!
      gsap.fromTo(tr, { x: () => innerWidth * 0.06 }, { x: () => -(tr.scrollWidth - innerWidth * (mobile ? 0.92 : 0.94)), ease: 'none', scrollTrigger: { trigger: sq, start: 'top 85%', end: 'bottom 25%', scrub: 0.5, invalidateOnRefresh: true } })
    })
    q('.k4-film').forEach((f) => gsap.fromTo(f, { scale: 0.9 }, { scale: 1, ease: 'none', scrollTrigger: { trigger: f, start: 'top 95%', end: 'top 40%', scrub: 0.4 } }))
    q('.k4-head').forEach((h) => gsap.from(h.children, { opacity: 0, y: 18, stagger: 0.08, duration: 1, ease: 'rmzOut', scrollTrigger: { trigger: h, start: 'top 90%', once: true } }))
  })
  return (
    <section className="w4" ref={ref} id="ch-work" data-chap="work">
      <p className="t-meta wk-nm wk-y w4-lab">03 — The work</p>
      {s.blocks.map((b, i) => <K key={i} b={b} i={i} total={s.blocks.length} base={bases[i]} s={s} />)}
    </section>
  )
}
