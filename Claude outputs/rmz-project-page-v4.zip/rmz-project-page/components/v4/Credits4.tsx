'use client'
import { useRef } from 'react'
import type { Story } from '@/lib/stories'
import { gsap, useMotion } from '@/lib/motion'

export default function Credits4({ s }: { s: Story }) {
  const ref = useRef<HTMLElement>(null)
  useMotion(ref, ({ q }) => {
    q('.c4-row').forEach((r) => gsap.from(r, { opacity: 0, y: 18, duration: 0.9, ease: 'rmzOut', scrollTrigger: { trigger: r, start: 'top 92%', once: true } }))
  })
  return (
    <section className="c4" ref={ref} id="ch-credits" data-chap="credits">
      <p className="t-meta wk-nm wk-y">05 — Credits</p>
      <ul className="c4-list">
        {s.credits!.map((c) => (
          <li className="c4-row" key={c.role}><span className="t-display c4-r">{c.role}</span><span className="t-body c4-d">{c.note}</span><span className="t-meta c4-nm">Name pending</span></li>
        ))}
      </ul>
    </section>
  )
}
