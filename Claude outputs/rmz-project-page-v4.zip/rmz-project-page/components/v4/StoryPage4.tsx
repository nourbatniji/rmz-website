'use client'
import { useEffect, useMemo, useState } from 'react'
import { stories } from '@/lib/stories'
import { ScrollTrigger } from '@/lib/motion'
import Header2 from '../v2/Header2'
import NextStory from '../v2/NextStory'
import Lightbox from '../v2/Lightbox'
import { LB } from '../v2/Frame'
import { assetsOf } from '../v2/Showcase'
import { Footer } from '../v2/real/Footer'
import { footerContent } from '@/lib/site'
import Hero4 from './Hero4'
import Brief4 from './Brief4'
import Idea4 from './Idea4'
import Work4 from './Work4'
import Outcome4 from './Outcome4'
import Credits4 from './Credits4'
import Chrome4 from './Chrome4'
import '../../styles/v2.css'
import '../../styles/v4.css'

export default function StoryPage4({ slug }: { slug: string }) {
  const s = stories[slug]
  const [at, setAt] = useState<number | null>(null)
  const list = useMemo(() => s.blocks.flatMap(assetsOf), [s])
  useEffect(() => {
    window.scrollTo(0, 0)
    document.fonts?.ready.then(() => ScrollTrigger.refresh())
    const t = setTimeout(() => ScrollTrigger.refresh(), 800)
    return () => clearTimeout(t)
  }, [slug])
  return (
    <LB.Provider value={{ open: setAt }}>
      <main className="v2 v4" key={slug}>
        <Header2 />
        <Chrome4 />
        <Hero4 s={s} />
        <Brief4 s={s} />
        <Idea4 s={s} />
        <Work4 s={s} />
        <Outcome4 s={s} />
        <Credits4 s={s} />
        <NextStory s={s} next={stories[s.next]} base="v4" />
        <Footer content={footerContent} />
        <Lightbox s={s} list={list} at={at} set={setAt} />
      </main>
    </LB.Provider>
  )
}
