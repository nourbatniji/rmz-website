'use client'
import { useRef } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import type { Story } from '@/lib/stories'
import { gsap, useMotion } from '@/lib/motion'
import { Art } from './Art'

export default function NextStory({ s, next, base = 'v2' }: { s: Story; next: Story; base?: string }) {
  const ref = useRef<HTMLElement>(null)
  const cover = useRef<HTMLDivElement>(null)
  const router = useRouter()

  // one transition: the next cover lifts out of the page and fills the screen, then the new page settles beneath it
  const go = () => {
    const to = `/${base}/${next.slug}/`
    const fr = cover.current
    if (!fr || matchMedia('(prefers-reduced-motion: reduce)').matches) { router.push(to); return }
    const r = fr.getBoundingClientRect()
    const ov = document.createElement('div')
    ov.className = 'v2-xfer'
    Object.assign(ov.style, { position: 'fixed', left: `${r.left}px`, top: `${r.top}px`, width: `${r.width}px`, height: `${r.height}px`, zIndex: '95', overflow: 'hidden', background: '#F3E8CC' })
    const cl = fr.cloneNode(true) as HTMLElement
    Object.assign(cl.style, { width: '100%', height: '100%', transform: 'none' })
    ov.appendChild(cl); document.body.appendChild(ov)
    gsap.to(ov, { left: 0, top: 0, width: window.innerWidth, height: window.innerHeight, duration: 1, ease: 'rmzInOut', onComplete: () => router.push(to) })
    gsap.to(cl.querySelector('.nx2-im'), { scale: 1.08, duration: 1, ease: 'rmzInOut' })
  }

  useMotion(ref, ({ q, el }) => {
    gsap.from('.nx2-title .ln > span', { yPercent: 108, duration: 1.3, stagger: 0.08, ease: 'rmzOut', scrollTrigger: { trigger: el, start: 'top 65%', once: true } })
    gsap.from('.nx2-frame', { clipPath: 'inset(0 0 100% 0)', duration: 1.4, ease: 'rmzOut', scrollTrigger: { trigger: el, start: 'top 70%', once: true } })
    gsap.from(q('.nx2-chips > *, .nx2-cat, .nx2-go'), { opacity: 0, y: 14, duration: 1, stagger: 0.07, ease: 'rmzOut', scrollTrigger: { trigger: el, start: 'top 75%', once: true } })
    gsap.fromTo('.nx2-im', { yPercent: -5, scale: 1.1 }, { yPercent: 5, scale: 1.1, ease: 'none', scrollTrigger: { trigger: el, start: 'top bottom', end: 'bottom top', scrub: 0.4 } })
      })

  return (
    <section className="nx2" ref={ref} aria-label="Next project">
      <div className="nx2-chips wk-rule">
        <Link href={`/${base}/${next.slug}/`} className="wk-chip">← Previous · {next.name}</Link>
        <Link href="/" className="wk-chip">Back to all work</Link>
        <a className="wk-cta" href="#contact">Start a project</a>
      </div>
      <div className="nx2-panel wk-g12" aria-label={`Next project ${next.number} ${next.name}`}>
        <div className="nx2-copy">
          <p className="t-meta wk-nm" style={{ color: 'var(--color-red)' }}>Next project · {next.number}</p>
          <h2 className="t-display nx2-title"><span className="ln"><span>{next.name}</span></span></h2>
          <p className="t-meta wk-nm nx2-cat">{next.category} · {next.year} →</p>
          <button type="button" className="wk-cta nx2-go" onClick={go}>Explore {next.name.charAt(0) + next.name.slice(1).toLowerCase()}</button>
        </div>
        <div className="nx2-cover" ref={cover}>
          <button type="button" className="nx2-frame" onClick={go} aria-label={`Open ${next.name}`}>
            <span className="nx2-im"><Art a={next.cover} s={next} /></span>
          </button>
        </div>
      </div>
    </section>
  )
}
