import { notFound } from 'next/navigation'
import { stories, storySlugs } from '@/lib/stories'
import StoryPage4 from '@/components/v4/StoryPage4'

export function generateStaticParams() { return storySlugs.map((slug) => ({ slug })) }
export const metadata = { title: 'RMZ — Project page (V4)' }
export default async function Page({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  if (!stories[slug]) notFound()
  return <StoryPage4 slug={slug} />
}
