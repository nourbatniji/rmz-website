import { notFound } from 'next/navigation'
import { stories, storySlugs } from '@/lib/stories'
import StoryPage3 from '@/components/v3/StoryPage3'

export function generateStaticParams() { return storySlugs.map((slug) => ({ slug })) }
export const metadata = { title: 'RMZ — Project page (V3)' }
export default async function Page({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  if (!stories[slug]) notFound()
  return <StoryPage3 slug={slug} />
}
