import Link from 'next/link'

const rows = [
  ['V3 — Project page in the homepage language', [['ZAHR — brand & packaging', '/v3/zahr/'], ['DUSK — photography & campaign', '/v3/dusk/']]],
  ['V2 — Project Stories', [['ZAHR — brand & packaging', '/v2/zahr/'], ['DUSK — photography & campaign', '/v2/dusk/']]],
  ['V1 — Out of Register (kept for comparison)', [['ZAHR', '/work/zahr/'], ['MAQAM', '/work/maqam/']]],
] as const
export default function Home() {
  return (
    <main style={{ minHeight: '100svh', padding: '12vh var(--gut)', display: 'grid', alignContent: 'center', gap: 48 }}>
      <h1 style={{ fontWeight: 900, fontSize: 'clamp(40px,8vw,120px)', letterSpacing: '-.05em', lineHeight: .9 }}>RMZ prototypes</h1>
      {rows.map(([h, items]) => (
        <section key={h}>
          <p className="kicker" style={{ color: 'var(--yellow)', marginBottom: 14 }}>{h}</p>
          {items.map(([t, href]) => <Link key={href} href={href} style={{ display: 'block', fontWeight: 800, fontSize: 'clamp(22px,3vw,44px)', letterSpacing: '-.03em', padding: '10px 0', borderBottom: '1px solid #F3E8CC26' }}>{t} →</Link>)}
        </section>
      ))}
    </main>
  )
}
