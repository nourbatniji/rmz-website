import type { FooterContent } from "@/content/closing-types";

/** Copied from rmz-website (src/content/dev/closing.ts + homepage nav) so V2 shares the live site's footer and header content. */
export const footerContent: FooterContent = {
    label: "Contact",
    place: "Cairo, Egypt",
    timeZone: "Africa/Cairo",
    headlineLines: ["Let's start", "something"],
    headlineEmphasis: "rebel.",
    cta: { top: "Say", bottom: "hello", href: "mailto:management@rmz.solutions" },
    email: "management@rmz.solutions",
    studio: {
      heading: "Studio",
      body: "Rebel Mind Zone is a creative identity house in Cairo, Egypt. Brands, campaigns, content and digital, for people who refuse to blend in.",
    },
    explore: {
      heading: "Explore",
      links: [
        { label: "Work", href: "/#work" },
        { label: "Selected", href: "/#selected" },
        { label: "Capabilities", href: "/#services" },
        { label: "Studio", href: "/#minds" },
        { label: "Collaborations", href: "/#collaborations" },
      ],
    },
    services: { heading: "What we do", items: ["Brand identity", "Campaigns", "Content production", "Digital and web", "Growth"] },
    elsewhere: {
      heading: "Elsewhere",
      links: [
        { label: "Instagram", href: "https://www.instagram.com/" },
        { label: "Behance", href: "https://www.behance.net/" },
        { label: "LinkedIn", href: "https://www.linkedin.com/" },
        { label: "TikTok", href: "https://www.tiktok.com/" },
      ],
    },
    copyright: "© 2026 Rebel Mind Zone · All rights reserved",
    placeholderNote: "Social links are placeholders, swap in real profiles",
    toTop: "Back to top ↑",
  };

export const siteNav = [
  { label: "Work", href: "/" },
  { label: "Capabilities", href: "/" },
  { label: "Studio", href: "/" },
  { label: "Contact", href: "#contact" },
];
