export type Pal = { a: string; b: string; c: string; d: string; ink: string }
export type Swatch = { key: keyof Omit<Pal, 'ink'>; name: string; role: string; share: number; ink: string }

export type Project = {
  slug: string
  number: string
  name: string
  fullName: string
  motif: 'bloom' | 'arch'
  display: string // CSS font stack for the project's own display face
  client: string
  industry: string
  category: string
  year: string
  location: string
  services: string[]
  pal: Pal
  swatches: Swatch[]
  tagline: string
  seal: string
  titleSize: number // vw, hero wordmark
  statement: [string, string, string] // before, accent, after
  headline: string[]
  challenge: string
  solution: string
  concept: string
  steps: { title: string; text: string }[]
  gallery: string[] // ordered chapter keys
  outcomes: { value: string; label: string }[]
  credits: { role: string; who: string }[]
  next: string
}

const fraunces = "'Fraunces Variable', Georgia, serif"
const bricolage = "'Bricolage Grotesque Variable', system-ui, sans-serif"

export const projects: Record<string, Project> = {
  zahr: {
    slug: 'zahr',
    number: '01',
    name: 'ZAHR',
    fullName: 'Zahr — Sparkling Hibiscus',
    motif: 'bloom',
    display: fraunces,
    client: 'Zahr Beverages',
    industry: 'Food & Beverage',
    category: 'Brand identity · Packaging · Campaign',
    year: '2026',
    location: 'Cairo, Egypt',
    services: ['Naming', 'Brand identity', 'Packaging', 'Campaign', 'Photography', 'Social', 'Web experience', 'Motion'],
    pal: { a: '#D4163C', b: '#F7E9D2', c: '#1E5B43', d: '#FFB224', ink: '#14090B' },
    swatches: [
      { key: 'a', name: 'Hibiscus', role: 'The shout. Cans, posters, anything that needs to be seen first.', share: 40, ink: '#F7E9D2' },
      { key: 'd', name: 'Nectar', role: 'The spark. Details, flavour cues and the moment of surprise.', share: 15, ink: '#14090B' },
      { key: 'c', name: 'Calyx', role: 'The calm. Leaf green keeps the loudness honest and natural.', share: 20, ink: '#F7E9D2' },
      { key: 'b', name: 'Petal', role: 'The paper. Space to breathe, type to read, a quiet ground.', share: 25, ink: '#14090B' },
    ],
    titleSize: 29.5,
    tagline: 'Sparkling hibiscus — Cairo',
    seal: 'SPARKLING HIBISCUS • CAIRO • EST. 2026 • SERVED LOUD •',
    statement: ['Hibiscus soda has whispered from the bottom shelf for a decade. We built Zahr to be heard, and let its whole world ', 'snap into place', ' one loud colour at a time.'],
    headline: ['Hibiscus', 'that refuses', 'to whisper.'],
    challenge: 'Cairo’s hibiscus tradition is centuries deep, yet every bottle on the shelf looks like medicine or nostalgia. Zahr had to win a cold-case in under two seconds, and a feed in less than one.',
    solution: 'A brand built out of register. Four inks, each with a job, drift apart until the moment of purchase, then lock together. One idea carried by the can, the poster, the pour and the feed.',
    concept: 'Out of Register: the beautiful error that makes colour feel hand-pulled, alive and impossible to ignore.',
    steps: [
      { title: 'Bloom', text: 'A five-petal hibiscus in Hibiscus red. One shape, drawn bold enough to read from across a street.' },
      { title: 'Calyx', text: 'Green leaves slot between the petals. Natural, calm, and the contrast that makes the red feel hotter.' },
      { title: 'Spark', text: 'Nectar amber arrives at the core. Tiny, bright, the detail your eye lands on last and remembers first.' },
      { title: 'Veins', text: 'Fine petal-cream linework: the quiet layer that gives the loud one structure, and the type its home.' },
      { title: 'Lock', text: 'Four plates, one pass. The system snaps into register, and wherever it slips, it slips on purpose.' },
    ],
    gallery: ['identity', 'type', 'color', 'still', 'pack', 'campaign', 'photo', 'social', 'digital'],
    outcomes: [
      { value: '3.2×', label: 'shelf pick-up against the previous design in pilot cooler tests' },
      { value: '11M', label: 'campaign impressions in the first three weeks' },
      { value: '62%', label: 'unprompted brand recall after launch month' },
    ],
    credits: [
      { role: 'Creative direction', who: 'RMZ Studio' },
      { role: 'Brand & packaging', who: 'RMZ Design' },
      { role: 'Photography & film', who: 'RMZ Production' },
      { role: 'Motion', who: 'RMZ Production' },
      { role: 'Web experience', who: 'RMZ Digital' },
    ],
    next: 'maqam',
  },
  maqam: {
    slug: 'maqam',
    number: '02',
    name: 'MAQAM',
    fullName: 'Maqam — Architecture Studio',
    motif: 'arch',
    display: bricolage,
    client: 'Maqam Studio',
    industry: 'Architecture & Interiors',
    category: 'Brand identity · Spatial graphics · Web',
    year: '2025',
    location: 'Amman · Cairo',
    services: ['Identity', 'Signage', 'Editorial', 'Web experience'],
    pal: { a: '#2A47F0', b: '#EDE6D6', c: '#E4572E', d: '#C8B28A', ink: '#0E1226' },
    swatches: [
      { key: 'a', name: 'Cobalt', role: 'Structure.', share: 38, ink: '#EDE6D6' },
      { key: 'c', name: 'Terracotta', role: 'Warmth.', share: 18, ink: '#0E1226' },
      { key: 'd', name: 'Sand', role: 'Ground.', share: 14, ink: '#0E1226' },
      { key: 'b', name: 'Limewash', role: 'Light.', share: 30, ink: '#0E1226' },
    ],
    titleSize: 21.5,
    tagline: 'Architecture studio — Amman · Cairo',
    seal: 'MAQAM • ARCHITECTURE • AMMAN • CAIRO • EST. 2018 •',
    statement: ['A studio that builds rooms for people to ', 'gather', ' in, and an identity that does the same.'],
    headline: ['Rooms', 'made of', 'arches.'],
    challenge: 'An architecture studio with two cities and one sensibility needed a mark that could be carved, painted and printed.',
    solution: 'An arch, repeated until it becomes a language.',
    concept: 'Threshold.',
    steps: [
      { title: 'Arch', text: 'One solid cobalt arch. The simplest structural gesture, drawn with a compass.' },
      { title: 'Echo', text: 'A smaller terracotta arch beside it: a doorway next to a doorway.' },
      { title: 'Light', text: 'A sand sun inside the arch. The reason anyone walks through.' },
      { title: 'Survey', text: 'Limewash drawing lines: ground, contours, tick marks. The plan beneath the poem.' },
      { title: 'Lock', text: 'Four plates, one threshold. The identity settles like a building does.' },
    ],
    gallery: ['identity', 'color'],
    outcomes: [],
    credits: [],
    next: 'zahr',
  },
}

export const slugs = Object.keys(projects)
export const chapterLabels: Record<string, string> = {
  identity: 'Identity', type: 'Typography', color: 'Colour', still: 'Atmosphere', pack: 'Packaging',
  campaign: 'Campaign', photo: 'Photography', social: 'Social', digital: 'Digital & motion',
}
