import type { Pal } from './projects'

/* ------------------------------------------------------------------
   Project Stories — content model.
   A story is metadata + an ORDERED list of blocks. The page renders
   whatever blocks exist; nothing about packaging, type or colour is
   hardcoded. Assets point at artwork (procedural stand-ins here;
   swap `art` for { src } when real photography/video exists).
------------------------------------------------------------------- */
export type StillKind = 'sun' | 'pour' | 'macro' | 'flat' | 'dusk'
export type SceneKind = 'dunes' | 'arch' | 'glasses' | 'pool' | 'horizon' | 'palm' | 'poster'
export type PosterKind = 'bloomtype' | 'can' | 'type' | 'night' | 'stripes' | 'quote' | 'promo' | 'stat'

export type Asset = {
  art: 'still' | 'scene' | 'poster' | 'billboard' | 'cans' | 'web' | 'phone'
  v?: string // kind within the art family
  ratio: string // CSS aspect-ratio, e.g. '4/5'
  caption?: string
  inner?: Asset // web / phone frames wrap another asset
  site?: { url: string; title: string; nav: string[] }
  src?: string // real image, when available
}

export type Block =
  | { t: 'feature'; asset: Asset; bleed?: boolean; tone?: Tone; title?: string }
  | { t: 'pair'; a: Asset; b: Asset; flip?: boolean; tone?: Tone; title?: string }
  | { t: 'detail'; main: Asset; side: Asset[]; note?: string; tone?: Tone; title?: string }
  | { t: 'sequence'; items: Asset[]; tone?: Tone; title?: string }
  | { t: 'video'; frames: Asset[]; label: string; duration: number; src?: string; tone?: Tone; title?: string }
type Tone = 'light' | 'dark'

export type Details = {
  kicker: string
  title: string
  text: string
  specs: [string, string][]
  assets: Asset[]
}

export type Story = {
  slug: string
  number: string
  name: string // big hero word
  fullName: string
  category: string
  year: string
  client: string
  location: string
  services: string[]
  pal: Pal // artwork palette only; the page chrome stays RMZ black/cream/yellow
  motif: 'bloom' | 'arch'
  statement: string // one-sentence hero statement
  cover: Asset
  overview: { lead: [string, string, string]; challenge: string; approach: string }
  blocks: Block[]
  details?: Details[]
  next: string
}

export const stories: Record<string, Story> = {
  zahr: {
    slug: 'zahr', number: '01', name: 'ZAHR', fullName: 'Zahr — Sparkling Hibiscus',
    category: 'Brand identity · Packaging · Campaign', year: '2026', client: 'Zahr Beverages', location: 'Cairo, Egypt',
    services: ['Naming', 'Brand identity', 'Packaging', 'Campaign', 'Photography', 'Social', 'Web', 'Motion'],
    pal: { a: '#D4163C', b: '#F7E9D2', c: '#1E5B43', d: '#FFB224', ink: '#14090B' }, motif: 'bloom',
    statement: 'A century-old Cairo drink, rebuilt to be heard from across the street.',
    cover: { art: 'still', v: 'macro', ratio: '5/6', caption: 'Zahr — launch key visual' },
    overview: {
      lead: ['Hibiscus soda has whispered from the bottom shelf for a decade. We built Zahr to ', 'be heard', ', then carried it from the can to the street, the feed and the screen.'],
      challenge: 'Every hibiscus bottle in Cairo looks like medicine or nostalgia. Zahr had to win a cold-case in under two seconds, and stay recognisable once it left the shelf.',
      approach: 'One bold bloom, four inks and a loud voice. We designed the brand to travel: a single idea that works on aluminium, on a billboard, in a story and in motion.',
    },
    blocks: [
      { t: 'feature', bleed: true, tone: 'light', title: 'Out of home', asset: { art: 'billboard', v: 'wide', ratio: '12/5', caption: 'Launch billboard — Cairo ring road' } },
      { t: 'pair', tone: 'light', title: 'Light with heat', a: { art: 'still', v: 'sun', ratio: '4/5', caption: 'Golden hour, rooftop shoot' }, b: { art: 'still', v: 'flat', ratio: '1/1', caption: 'Flat-lay, studio' } },
      { t: 'detail', tone: 'dark', title: 'The can', main: { art: 'still', v: 'pour', ratio: '4/5', caption: 'The pour — hero product frame' },
        side: [{ art: 'cans', v: 'trio', ratio: '1/1', caption: 'Three flavours, one family' }, { art: 'poster', v: 'can', ratio: '4/5', caption: 'In-store poster' }],
        note: 'Shot over two days on location. Every product frame is lit to feel warm and cold at once.' },
      { t: 'sequence', tone: 'dark', title: 'Campaign posters', items: [
        { art: 'poster', v: 'bloomtype', ratio: '5/7', caption: 'Bloom' }, { art: 'poster', v: 'type', ratio: '5/7', caption: 'Type' },
        { art: 'poster', v: 'night', ratio: '5/7', caption: 'Night' }, { art: 'poster', v: 'stripes', ratio: '5/7', caption: 'Stripes' }] },
      { t: 'video', tone: 'dark', title: 'Brand film', label: 'Bloom — 30″ brand film', duration: 9, frames: [
        { art: 'still', v: 'sun', ratio: '16/9' }, { art: 'still', v: 'pour', ratio: '16/9' }, { art: 'still', v: 'macro', ratio: '16/9' }, { art: 'still', v: 'dusk', ratio: '16/9' }] },
      { t: 'pair', tone: 'light', flip: true, title: 'Web & social', a: { art: 'web', ratio: '16/10', caption: 'Launch site — zahr.co', inner: { art: 'still', v: 'dusk', ratio: '16/10' }, site: { url: 'zahr.co', title: 'Drink the bloom loud.', nav: ['Flavours', 'Find us', 'Story'] } },
        b: { art: 'phone', ratio: '9/18', caption: 'Story series', inner: { art: 'still', v: 'macro', ratio: '9/16' } } },
      { t: 'feature', tone: 'dark', title: 'Closing frame', asset: { art: 'still', v: 'dusk', ratio: '3/2', caption: 'Cairo skyline, last light' } },
    ],
    details: [{
      kicker: 'Selected detail — Identity & packaging', title: 'Four inks, one can.',
      text: 'The identity is a single flower drawn in four spot colours. On the can it prints as one pass; in motion it drifts apart and locks back together. The same system runs from a 330 ml can to a six-metre billboard.',
      specs: [['Format', '330 ml aluminium'], ['Palette', 'Four spot inks'], ['Flavours', 'Original · Ginger · Mint'], ['Typeface', 'Fraunces, custom cut']],
      assets: [{ art: 'cans', v: 'trio', ratio: '4/5', caption: 'The range' }, { art: 'poster', v: 'quote', ratio: '4/5', caption: 'Shelf-talker' }],
    }],
    next: 'dusk',
  },

  dusk: {
    slug: 'dusk', number: '02', name: 'DUSK', fullName: 'Dusk Hour — Summer campaign for Hala Eyewear',
    category: 'Photography · Production · Campaign', year: '2026', client: 'Hala Eyewear', location: 'Siwa & Dahab, Egypt',
    services: ['Creative direction', 'Photography', 'Film production', 'Art direction', 'Social', 'Out of home'],
    pal: { a: '#E4572E', b: '#F3E3C8', c: '#1F6F78', d: '#FFC561', ink: '#1A0F0C' }, motif: 'arch',
    statement: 'A summer campaign shot in the last hour of light, from the desert to the sea.',
    cover: { art: 'scene', v: 'dunes', ratio: '5/6', caption: 'Dusk Hour — key visual' },
    overview: {
      lead: ['Hala wanted a summer campaign that ', 'felt like a place', ', not a catalogue: warm, unhurried and unmistakably theirs.'],
      challenge: 'Sunglasses are sold on the same shots every season. Hala needed imagery with a point of view that would work as a film, a poster and a feed, and survive being cropped.',
      approach: 'We chased one hour of light across two locations and built every frame around it. Twelve days of production, one palette taken from the sky, and a shoot designed to be cut a dozen ways.',
    },
    blocks: [
      { t: 'feature', bleed: true, tone: 'light', title: 'Key visual', asset: { art: 'scene', v: 'horizon', ratio: '12/5', caption: 'Dahab, 18:42' } },
      { t: 'pair', tone: 'light', title: 'Siwa', a: { art: 'scene', v: 'arch', ratio: '4/5', caption: 'Doorway, Siwa old town' }, b: { art: 'scene', v: 'glasses', ratio: '1/1', caption: 'Product, on location' } },
      { t: 'sequence', tone: 'dark', title: 'Lookbook', items: [
        { art: 'scene', v: 'palm', ratio: '4/5', caption: 'Palm shadow' }, { art: 'scene', v: 'pool', ratio: '4/5', caption: 'Poolside' },
        { art: 'scene', v: 'dunes', ratio: '4/5', caption: 'Dunes' }, { art: 'scene', v: 'arch', ratio: '4/5', caption: 'Threshold' }] },
      { t: 'video', tone: 'dark', title: 'Campaign film', label: 'Dusk Hour — 45″ campaign film', duration: 8, frames: [
        { art: 'scene', v: 'dunes', ratio: '16/9' }, { art: 'scene', v: 'arch', ratio: '16/9' }, { art: 'scene', v: 'pool', ratio: '16/9' }, { art: 'scene', v: 'horizon', ratio: '16/9' }] },
      { t: 'detail', tone: 'dark', title: 'Behind the frames', main: { art: 'scene', v: 'pool', ratio: '4/5', caption: 'Pool day, two hours before sunset' },
        side: [{ art: 'scene', v: 'glasses', ratio: '1/1', caption: 'Hero product frame' }, { art: 'scene', v: 'palm', ratio: '4/5', caption: 'Shadow study' }],
        note: 'Twelve shoot days, a crew of nine, two locations. Everything was shot in the hour before sunset.' },
      { t: 'pair', tone: 'light', flip: true, title: 'Out of home & social', a: { art: 'scene', v: 'poster', ratio: '4/5', caption: 'Campaign poster' },
        b: { art: 'phone', ratio: '9/18', caption: 'Story format', inner: { art: 'scene', v: 'horizon', ratio: '9/16' } } },
      { t: 'feature', tone: 'dark', title: 'Closing frame', asset: { art: 'scene', v: 'dunes', ratio: '16/9', caption: 'Siwa, last light' } },
    ],
    next: 'zahr',
  },
}
export const storySlugs = Object.keys(stories)
