'use client'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { CustomEase } from 'gsap/CustomEase'
import { useLayoutEffect, type RefObject } from 'react'

let ready = false
export function registerGsap() {
  if (ready || typeof window === 'undefined') return
  gsap.registerPlugin(ScrollTrigger, CustomEase)
  // Same curves as the homepage motion tokens.
  CustomEase.create('rmzOut', '.2,.8,.2,1')
  CustomEase.create('rmzInOut', '.65,0,.35,1')
  ScrollTrigger.config({ ignoreMobileResize: true })
  ready = true
}
registerGsap()
export { gsap, ScrollTrigger }

export type MotionCtx = { q: <T extends HTMLElement = HTMLElement>(s: string) => T[]; el: HTMLElement; mobile: boolean }

/**
 * Scoped GSAP setup. Runs only when the user has no reduced-motion preference,
 * re-runs when the mobile breakpoint flips, and fully reverts on unmount.
 * CSS always describes the *resting* state; JS only animates away from it.
 */
export function useMotion(ref: RefObject<HTMLElement | null>, fn: (c: MotionCtx) => void | (() => void)) {
  useLayoutEffect(() => {
    const el = ref.current
    if (!el) return
    const mm = gsap.matchMedia()
    mm.add({ motion: '(prefers-reduced-motion: no-preference)', mobile: '(max-width: 760px)' }, (ctx) => {
      const { motion, mobile } = ctx.conditions as { motion: boolean; mobile: boolean }
      if (!motion) return
      return fn({ q: <T extends HTMLElement = HTMLElement>(s: string) => gsap.utils.toArray<T>(s, el), el, mobile })
    }, el)
    return () => mm.revert()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])
}

/** Pinned on desktop, free-scrolling scrub on mobile. */
export function scrubCfg(trigger: Element, opts: { dist?: number; pin?: Element | string | false | null; mobile?: boolean; pinMobile?: boolean; mStart?: string; mEnd?: string }): ScrollTrigger.Vars {
  const { dist = 120, pin = null, mobile = false, pinMobile = false, mStart = 'top 80%', mEnd = 'bottom 30%' } = opts
  if (!mobile || pinMobile) return { trigger, start: 'top top', end: `+=${mobile ? Math.round(dist * 0.85) : dist}%`, pin: pin === false ? false : pin ?? true, scrub: 0.25, anticipatePin: 1 }
  return { trigger, start: mStart, end: mEnd, scrub: 0.25 }
}
