'use client'
import { useRef } from 'react'
import type { Project, Swatch } from '@/lib/projects'
import { Plate, type PlateKey } from '../art/bloom'
import { gsap, useMotion, scrubCfg } from '@/lib/motion'
import '../../styles/concept.css'

const ORDER: PlateKey[] = ['c', 'a', 'd', 'b'] // bottom → top of the stack
const STEP_PLATE: PlateKey[] = ['a', 'c', 'd', 'b']

export default function Concept({ p }: { p: Project }) {
  const ref = useRef<HTMLElement>(null)
  const nm = (k: PlateKey) => (p.swatches.find((s: Swatch) => s.key === k)?.name ?? '')

  useMotion(ref, ({ q, el, mobile }) => {
    const planes = q('.cs-plane'), lis = q('.cs-steps li'), stack = el.querySelector('.cs-stack')!
    const idx = (k: PlateKey) => ORDER.indexOf(k)
    const GAP = mobile ? 90 : 150
    gsap.set(stack, { rotateX: 58, rotateZ: -38, y: mobile ? -10 : 0 })
    gsap.set(planes, { z: (i) => i * GAP - 100, opacity: 0 })
    lis.forEach((li, i) => gsap.set(li, { opacity: mobile ? (i === 0 ? 1 : 0) : i === 0 ? 1 : 0.28 }))

    const tl = gsap.timeline({ defaults: { ease: 'none' }, scrollTrigger: scrubCfg(el, { dist: 300, pin: '.cs-pin', mobile, pinMobile: true }) })
    STEP_PLATE.forEach((k, s) => {
      const pl = planes[idx(k)], t = s
      tl.fromTo(pl, { opacity: 0, z: idx(k) * GAP + 260 }, { opacity: 1, z: idx(k) * GAP - 100, duration: 0.7 }, t)
      if (s > 0) {
        // previous plates dim; previous caption steps back
        STEP_PLATE.slice(0, s).forEach((pk) => tl.to(planes[idx(pk)], { opacity: 0.32, duration: 0.5 }, t))
        tl.to(lis[s - 1], { opacity: mobile ? 0 : 0.28, duration: 0.3 }, t)
        tl.to(lis[s], { opacity: 1, duration: 0.3 }, t + 0.2)
      }
    })
    // lock: the stack straightens, plates collapse into one print
    const L = 4
    tl.to(lis[3], { opacity: mobile ? 0 : 0.28, duration: 0.3 }, L)
    tl.to(lis[4], { opacity: 1, duration: 0.3 }, L + 0.1)
    tl.to(planes, { opacity: 1, duration: 0.6 }, L)
    tl.to(stack, { rotateX: 0, rotateZ: 0, y: 0, duration: 1.2 }, L)
    tl.to(planes, { z: 0, duration: 1.2 }, L)
    tl.to(q('.cs-plane'), { borderColor: 'rgba(243,232,204,0)', duration: 0.4 }, L + 0.9)
    tl.to(q('.cs-tag'), { opacity: 0, duration: 0.3 }, L)
    tl.to({}, { duration: 0.4 })
  })

  return (
    <section ref={ref} className="concept" data-chapter="Concept">
      <div className="cs-pin">
        <div className="cs-left">
          <span className="kicker" style={{ color: 'var(--yellow)' }}>02 — The creative concept</span>
          <h2>Out of <i className="accent">register</i></h2>
          <ol className="cs-steps">
            {p.steps.map((s, i) => (
              <li key={s.title}><span className="n">0{i + 1}</span><h3>{s.title}</h3><p>{s.text}</p></li>
            ))}
          </ol>
        </div>
        <div className="cs-stage" aria-label={`The identity built from four ink plates: ${p.steps.map((s) => s.title).join(', ')}`}>
          <div className="cs-persp">
            <div className="cs-stack">
              {ORDER.map((k, i) => (
                <div className="cs-plane" key={k}>
                  <Plate k={k} m={p.motif} pal={p.pal} />
                  <span className="cs-tag">Plate 0{i + 1} · {nm(k)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="cs-count" aria-hidden="true">4 plates · 1 pass</div>
      </div>
    </section>
  )
}
