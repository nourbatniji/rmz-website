'use client'
import { useRef } from 'react'
import type { Project } from '@/lib/projects'
import { Motif, uid, F } from '../art/bloom'
import { Still, type StillKind } from '../art/stills'
import { gsap, useMotion, scrubCfg } from '@/lib/motion'
import '../../styles/chapters1.css'

const mark = (p: Project, on: 'a' | 'b' | 'd' | 'ink' = 'a') => {
  const c = p.pal
  const cols = on === 'a' ? { petal: c.b, leaf: c.c, core: c.d, vein: c.a } : on === 'b' ? { petal: c.a, leaf: c.c, core: c.d, vein: c.b } : { petal: c.a, leaf: c.c, core: c.d, vein: c.ink }
  return (
    <svg viewBox="-460 -460 920 920" aria-hidden="true"><Motif m={p.motif} colors={cols} /></svg>
  )
}

/* ============ IDENTITY — "Scale Drop" ============ */
export function Identity({ p }: { p: Project }) {
  const ref = useRef<HTMLElement>(null)
  const id = uid()
  useMotion(ref, ({ el, mobile }) => {
    const around = el.querySelectorAll('.id-mark, .id-badge, .id-tag, .id-cap, .id-card, .id-grid')
    gsap.set(around, { opacity: 0 })
    gsap.set('.id-word', { scale: mobile ? 6.5 : 8.5, transformOrigin: '63% 40%' })
    const tl = gsap.timeline({ defaults: { ease: 'none' }, scrollTrigger: scrubCfg(el, { dist: 140, pin: '.id-pin', mobile, mStart: 'top 70%', mEnd: 'top -10%' }) })
    tl.to('.id-word', { scale: 1, ease: 'power2.inOut', duration: 1 }, 0)
    tl.to('.id-grid', { opacity: 1, duration: 0.4 }, 0.55)
    tl.fromTo('.id-mark', { opacity: 0, rotation: -40, scale: 0.6 }, { opacity: 1, rotation: 0, scale: 1, duration: 0.4 }, 0.62)
    tl.fromTo('.id-badge', { opacity: 0, scale: 0.6 }, { opacity: 1, scale: 1, duration: 0.4 }, 0.68)
    tl.fromTo('.id-tag', { opacity: 0, y: 14 }, { opacity: 1, y: 0, duration: 0.3 }, 0.74)
    tl.fromTo('.id-card', { opacity: 0, y: 40 }, { opacity: 1, y: 0, duration: 0.3, stagger: 0.07 }, 0.78)
    tl.fromTo('.id-cap', { opacity: 0 }, { opacity: 1, duration: 0.25 }, 0.92)
    tl.to({}, { duration: 0.15 })
  })
  return (
    <section ref={ref} data-chapter="Identity">
      <div className="id-pin">
        <div className="id-grid" aria-hidden="true" />
        <h2 className="id-word" aria-label={`${p.name} wordmark`}><span aria-hidden="true">{p.name}</span></h2>
        <div className="id-mark">{mark(p, 'a')}</div>
        <div className="id-badge" aria-hidden="true">
          <svg viewBox="0 0 200 200">
            <defs><path id={`${id}c`} d="M100 100 m-80 0 a80 80 0 1 1 160 0 a80 80 0 1 1 -160 0" /></defs>
            <text fontFamily="'Figtree Variable'" fontWeight="700" fontSize="12.6" letterSpacing="3.4" fill="#F7E9D2"><textPath href={`#${id}c`}>{p.seal}</textPath></text>
            <g transform="translate(100 100) scale(.13)"><Motif m={p.motif} colors={{ petal: p.pal.b, leaf: p.pal.c, core: p.pal.d, vein: p.pal.a }} /></g>
          </svg>
        </div>
        <div className="id-tag kicker">{p.tagline}</div>
        <p className="id-cap kicker">Wordmark, mark and seal. One system, three scales.</p>
        <div className="id-lock">
          <div className="id-card"><span className="kicker">Horizontal lockup</span><div className="id-lk">{mark(p, 'a')}<span>{p.name}</span></div></div>
          <div className="id-card inv"><span className="kicker">Stacked · light</span><div className="id-lk st">{mark(p, 'b')}<span>{p.name}</span></div></div>
          <div className="id-card dk"><span className="kicker">Mark only · cap seal</span><div className="id-lk">{mark(p, 'ink')}</div></div>
        </div>
      </div>
    </section>
  )
}

/* ============ TYPOGRAPHY — "Weight Field" ============ */
const LINES = ['Loud', 'enough', 'to bloom.']
export function TypeChapter({ p }: { p: Project }) {
  const ref = useRef<HTMLElement>(null)
  useMotion(ref, ({ el, mobile }) => {
    const field = el.querySelector<HTMLElement>('.ty-field')!
    const chars = Array.from(field.querySelectorAll<HTMLElement>('.ch'))
    let boxes: { x: number; y: number }[] = []
    const measure = () => { boxes = chars.map((c) => { const r = c.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 } }) }
    measure()
    const cur = chars.map(() => 620)
    const pointer = { x: -9999, y: -9999, on: false, t: 0 }
    const move = (e: PointerEvent) => { pointer.x = e.clientX; pointer.y = e.clientY; pointer.on = true; pointer.t = performance.now() }
    const leave = () => { pointer.on = false }
    field.addEventListener('pointermove', move); field.addEventListener('pointerleave', leave); field.addEventListener('pointerdown', move)
    const sc = () => measure(); window.addEventListener('scroll', sc, { passive: true }); window.addEventListener('resize', sc)
    const sigma = mobile ? 120 : 210
    const tick = () => {
      const t = performance.now() / 1000
      const sweepX = (((t * 0.16) % 1.4) - 0.2) * window.innerWidth
      chars.forEach((c, i) => {
        const b = boxes[i]
        let w = 520 + 130 * Math.sin(t * 1.1 + i * 0.6) // idle breathing
        const ds = Math.abs(b.x - sweepX)
        w = Math.max(w, 120 + 560 * Math.exp(-(ds * ds) / (2 * 150 * 150))) // slow sweep so touch / idle still moves
        if (pointer.on) { const d = Math.hypot(b.x - pointer.x, (b.y - pointer.y) * 0.6); w = Math.max(w * 0.7, 100 + 800 * Math.exp(-(d * d) / (2 * sigma * sigma))) }
        cur[i] += (w - cur[i]) * 0.14
        c.style.fontVariationSettings = `'wght' ${Math.round(cur[i])}, 'opsz' ${Math.round(144 - (cur[i] - 100) / 8)}`
      })
    }
    gsap.ticker.add(tick)
    gsap.from(el.querySelectorAll('.ty-cell'), { opacity: 0, y: 40, duration: 0.9, stagger: 0.1, ease: 'rmzOut', scrollTrigger: { trigger: '.ty-spec', start: 'top 88%' } })
    return () => { gsap.ticker.remove(tick); field.removeEventListener('pointermove', move); field.removeEventListener('pointerleave', leave); field.removeEventListener('pointerdown', move); window.removeEventListener('scroll', sc); window.removeEventListener('resize', sc) }
  })
  return (
    <section ref={ref} className="ty" data-chapter="Typography">
      <div className="ty-top kicker"><span>Typography — Fraunces &amp; Figtree</span><span className="ty-hint"><span className="hint-d">Move across the type</span></span></div>
      <div className="ty-field" aria-label={LINES.join(' ')} role="img">
        {LINES.map((l) => <span className="row" key={l} aria-hidden="true">{l.split('').map((c, i) => <span className="ch" key={i}>{c === ' ' ? '\u00A0' : c}</span>)}</span>)}
      </div>
      <div className="ty-spec">
        <div className="ty-cell"><div className="ty-aa f">Aa</div><span className="kicker">Fraunces — voice, 100–900</span><p className="ty-glyph">ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789 &amp;!?</p></div>
        <div className="ty-cell"><div className="ty-aa g">Aa</div><span className="kicker">Figtree — information</span><p className="ty-glyph">abcdefghijklmnopqrstuvwxyz 0123456789 ·–/%</p></div>
        <div className="ty-cell l">
          <div className="ty-ladder">
            <div style={{ fontSize: 'clamp(40px,5vw,76px)', fontWeight: 900 }}>Headline <small>Fraunces 900 · −4%</small></div>
            <div style={{ fontSize: 'clamp(24px,2.6vw,38px)', fontWeight: 300 }}>Subhead in light <small>Fraunces 300</small></div>
            <div style={{ fontSize: 17, fontFamily: 'Figtree Variable', fontWeight: 400 }}>Body copy stays quiet so the voice can shout. <small>Figtree 400</small></div>
          </div>
        </div>
      </div>
    </section>
  )
}

/* ============ COLOUR — "Tide" ============ */
export function ColorChapter({ p }: { p: Project }) {
  const ref = useRef<HTMLElement>(null)
  const sw = p.swatches
  useMotion(ref, ({ el, q, mobile }) => {
    const panels = q('.co-panel')
    const origins = ['78% 64%', '16% 28%', '64% 86%']
    if (mobile) {
      // stacked on mobile: each colour floods in as it scrolls up
      panels.forEach((pn, i) => {
        if (i === 0) return
        gsap.fromTo(pn, { clipPath: `circle(0% at ${origins[(i - 1) % 3]})` }, { clipPath: `circle(150% at ${origins[(i - 1) % 3]})`, ease: 'none', scrollTrigger: { trigger: pn, start: 'top 88%', end: 'top 30%', scrub: 0.25 } })
      })
      return
    }
    el.classList.add('stage')
    const segs = q('.co-bar i')
    const tl = gsap.timeline({ defaults: { ease: 'none' }, scrollTrigger: scrubCfg(el, { dist: 280, pin: '.co-pin' }) })
    gsap.set(segs, { opacity: 0.3 }); gsap.set(segs[0], { opacity: 1 })
    panels.forEach((pn, i) => {
      if (i === 0) return
      tl.fromTo(pn, { clipPath: `circle(0% at ${origins[i - 1]})` }, { clipPath: `circle(150% at ${origins[i - 1]})`, duration: 1, ease: 'power2.inOut' }, i - 1 + 0.2)
      tl.fromTo(pn.querySelectorAll('.co-hex, .co-name, .co-foot'), { yPercent: 14, opacity: 0 }, { yPercent: 0, opacity: 1, duration: 0.6, stagger: 0.06 }, i - 1 + 0.55)
      tl.to(segs[i - 1], { opacity: 0.3, duration: 0.3 }, i - 1 + 0.4).to(segs[i], { opacity: 1, duration: 0.3 }, i - 1 + 0.5)
    })
    tl.to({}, { duration: 0.3 })
    return () => el.classList.remove('stage')
  })
  return (
    <section ref={ref} className="co" data-chapter="Colour">
      <div className="co-pin">
        {sw.map((s, i) => (
          <div key={s.key} className="co-panel" style={{ background: p.pal[s.key], color: s.ink, zIndex: i + 1 }}>
            <div className="co-meta"><span className="kicker">Colour system — 0{i + 1} / 0{sw.length}</span><span className="co-name">{s.name}</span></div>
            <div className="co-hex">{p.pal[s.key].slice(1)}</div>
            <div className="co-foot"><p className="co-role">{s.role}</p><div className="co-share">{s.share}<small>% of use</small></div></div>
          </div>
        ))}
        <div className="co-bar" aria-hidden="true">{sw.map((s) => <i key={s.key} style={{ flex: s.share, background: p.pal[s.key] }} />)}</div>
      </div>
    </section>
  )
}

/* ============ INTERLUDE — quiet full-bleed still ============ */
export function Interlude({ p, kind, text, caption }: { p: Project; kind: StillKind; text: [string, string]; caption: string }) {
  const ref = useRef<HTMLElement>(null)
  useMotion(ref, ({ el }) => {
    gsap.fromTo(el.querySelector('.il-art'), { yPercent: -7, scale: 1.12 }, { yPercent: 7, scale: 1, ease: 'none', scrollTrigger: { trigger: el, start: 'top bottom', end: 'bottom top', scrub: true } })
    gsap.from(el.querySelectorAll('.il-t .ln > span'), { yPercent: 110, duration: 1.2, ease: 'rmzOut', stagger: 0.12, scrollTrigger: { trigger: el, start: 'top 45%', toggleActions: 'play none none reverse' } })
  })
  return (
    <section ref={ref} className="il" data-chapter="Atmosphere">
      <div className="il-art grain"><Still kind={kind} pal={p.pal} /></div>
      <div className="il-ov" />
      <p className="il-t"><span className="ln"><span>{text[0]}</span></span><span className="ln"><span><b>{text[1]}</b></span></span></p>
      <p className="il-cap kicker">{caption}</p>
    </section>
  )
}
void F
