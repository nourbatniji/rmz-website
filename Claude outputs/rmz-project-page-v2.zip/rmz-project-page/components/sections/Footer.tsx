'use client'
import { useRef } from 'react'
import { gsap, useMotion } from '@/lib/motion'
import '../../styles/footer.css'

const COL = ['#D52518', '#FFCA26', '#F86015', '#9ACC42']
const LINKS = [
  ['Work', ['All projects', 'Brand identity', 'Packaging', 'Campaigns', 'Digital & motion']],
  ['Studio', ['About RMZ', 'Services', 'Journal', 'Careers']],
  ['Elsewhere', ['Instagram', 'Behance', 'LinkedIn', 'Vimeo']],
] as const
const WORDS = ['Loud', 'Warm', 'Rebel', 'Mind', 'Zone']

function scroller(from: HTMLElement): HTMLElement | null {
  for (let n = from.parentElement; n; n = n.parentElement) {
    const o = getComputedStyle(n).overflowY
    if ((o === 'auto' || o === 'scroll') && n.scrollHeight > n.clientHeight) return n
  }
  return null
}

export default function Footer() {
  const ref = useRef<HTMLElement>(null)

  useMotion(ref, ({ q, el, mobile }) => {
    const offs = [[-1, -0.6], [1, -0.9], [-0.7, 0.9], [0.9, 0.6]]
    q('.ft-pl').forEach((p, i) => {
      gsap.fromTo(p, { x: offs[i][0] * (mobile ? 22 : 96), y: offs[i][1] * (mobile ? 10 : 44), rotation: offs[i][0] * 1.6 },
        { x: 0, y: 0, rotation: 0, ease: 'none', scrollTrigger: { trigger: el, start: 'top 55%', end: 'bottom bottom', scrub: 0.25 } })
    })
    gsap.fromTo(q('.ft-lock'), { opacity: 0 }, { opacity: 1, ease: 'none', scrollTrigger: { trigger: el, start: 'top 15%', end: 'bottom bottom', scrub: 0.25 } })
    gsap.from(q('.ft-ask .ln > span'), { yPercent: 110, duration: 1, stagger: 0.12, ease: 'rmzOut', scrollTrigger: { trigger: el, start: 'top 75%' } })
    gsap.from(q('.ft-col'), { y: 30, opacity: 0, duration: 0.9, stagger: 0.1, ease: 'rmzOut', scrollTrigger: { trigger: q('.ft-cols')[0], start: 'top 90%' } })

    // magnetic CTA + ink flood in the next RMZ colour
    const b = q<HTMLAnchorElement>('.ft-cta')[0], fill = q('.ft-fill')[0], lab = q('.ft-cta-in')[0]
    let ci = 0
    const bx = gsap.quickTo(b, 'x', { duration: 0.5, ease: 'rmzOut' }), by = gsap.quickTo(b, 'y', { duration: 0.5, ease: 'rmzOut' })
    const lx = gsap.quickTo(lab, 'x', { duration: 0.5, ease: 'rmzOut' }), ly = gsap.quickTo(lab, 'y', { duration: 0.5, ease: 'rmzOut' })
    const move = (e: PointerEvent) => {
      const r = b.getBoundingClientRect(), dx = e.clientX - (r.left + r.width / 2), dy = e.clientY - (r.top + r.height / 2)
      bx(dx * 0.22); by(dy * 0.3); lx(dx * 0.1); ly(dy * 0.14)
    }
    const enter = (e: PointerEvent) => {
      const r = b.getBoundingClientRect()
      fill.style.background = COL[ci++ % 4]
      gsap.fromTo(fill, { clipPath: `circle(0% at ${e.clientX - r.left}px ${e.clientY - r.top}px)` }, { clipPath: `circle(150% at ${e.clientX - r.left}px ${e.clientY - r.top}px)`, duration: 0.7, ease: 'rmzOut' })
    }
    const leave = (e: PointerEvent) => {
      const r = b.getBoundingClientRect()
      bx(0); by(0); lx(0); ly(0)
      gsap.to(fill, { clipPath: `circle(0% at ${e.clientX - r.left}px ${e.clientY - r.top}px)`, duration: 0.5, ease: 'rmzInOut' })
    }
    b.addEventListener('pointermove', move); b.addEventListener('pointerenter', enter); b.addEventListener('pointerleave', leave)
    return () => { b.removeEventListener('pointermove', move); b.removeEventListener('pointerenter', enter); b.removeEventListener('pointerleave', leave) }
  })

  const top = () => {
    const el = ref.current!, s = scroller(el)
    const o = { y: s ? s.scrollTop : window.scrollY }
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches
    if (reduce) { s ? (s.scrollTop = 0) : window.scrollTo(0, 0); return }
    // plates fly apart as the page lifts away
    gsap.to(el.querySelectorAll('.ft-pl'), { x: (i) => (i % 2 ? 1 : -1) * 60, y: (i) => (i < 2 ? -1 : 1) * 24, duration: 0.5, ease: 'rmzOut', yoyo: true, repeat: 1 })
    gsap.to(o, { y: 0, duration: 1.4, ease: 'rmzInOut', onUpdate: () => (s ? (s.scrollTop = o.y) : window.scrollTo(0, o.y)) })
  }

  return (
    <section className="ft" ref={ref} data-chapter="footer" aria-label="Footer">
      <div className="ft-strip" aria-hidden>
        <div className="ft-track">
          {[0, 1].map((k) => (
            <div className="ft-set" key={k}>
              {WORDS.map((w, i) => (<span key={w} style={{ ['--c' as string]: COL[i % 4] }}><i />{w}</span>))}
              {WORDS.map((w, i) => (<span key={w + 'b'} style={{ ['--c' as string]: COL[(i + 2) % 4] }}><i />{w}</span>))}
            </div>
          ))}
        </div>
      </div>

      <div className="ft-top">
        <h2 className="ft-ask">
          <span className="ln"><span>Got a brand</span></span>
          <span className="ln"><span>that needs</span></span>
          <span className="ln"><span>to be <em className="accent">loud?</em></span></span>
        </h2>
        <div className="ft-side">
          <p>Tell us what you are making. We reply within two working days.</p>
          <a className="ft-cta" href="#start">
            <span className="ft-fill" aria-hidden />
            <span className="ft-cta-in">Start a project <b aria-hidden>→</b></span>
          </a>
          <a className="ft-mail" href="#mail">[hello@your-domain]</a>
        </div>
      </div>

      <div className="ft-cols">
        {LINKS.map(([h, items]) => (
          <nav className="ft-col" key={h} aria-label={h}>
            <h3 className="kicker">{h}</h3>
            {items.map((t, i) => (
              <a key={t} href="#x" className="ft-link" style={{ ['--c' as string]: COL[i % 4] }}>
                <span className="ft-roll"><span>{t}</span><span aria-hidden>{t}</span></span>
              </a>
            ))}
          </nav>
        ))}
        <div className="ft-col ft-up">
          <h3 className="kicker">Back up</h3>
          <button type="button" className="ft-top-btn" onClick={top} aria-label="Back to top"><span aria-hidden>↑</span></button>
        </div>
      </div>

      <div className="ft-mark" aria-label="RMZ">
        <div className="ft-stack" aria-hidden>
          {COL.map((c, i) => (<span key={c} className="ft-pl" style={{ color: c }}>RMZ</span>))}
          <span className="ft-lock">RMZ</span>
        </div>
      </div>

      <div className="ft-legal">
        <span>© Rebel Mind Zone</span>
        <span>Privacy</span>
        <span>Terms</span>
        <span className="ft-reg"><i style={{ background: COL[0] }} /><i style={{ background: COL[1] }} /><i style={{ background: COL[2] }} /><i style={{ background: COL[3] }} />In register</span>
      </div>
    </section>
  )
}
