'use client'
import { useEffect, useRef } from 'react'
import type { Project } from '@/lib/projects'
import { Plates } from '../art/bloom'
import { gsap, useMotion } from '@/lib/motion'
import '../../styles/hero.css'

const OFF = { a: { x: -54, y: 30, r: -2.4 }, b: { x: 60, y: -34, r: 1.8 }, c: { x: -26, y: -52, r: 0.8 }, d: { x: 38, y: 46, r: 2.8 } } as const

export default function Hero({ p }: { p: Project }) {
  const ref = useRef<HTMLElement>(null)
  const readout = useRef<HTMLSpanElement>(null)

  // Entering from another project: a colour curtain (set by the previous page) peels away.
  useEffect(() => {
    let col: string | null = null
    try { col = sessionStorage.getItem('rmz-curtain'); sessionStorage.removeItem('rmz-curtain') } catch {}
    if (!col || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    const c = document.createElement('div')
    c.className = 'hero-curtain'; c.style.background = col
    document.body.appendChild(c)
    gsap.to(c, { clipPath: 'inset(0 0 100% 0)', duration: 0.9, ease: 'power3.inOut', delay: 0.15, onComplete: () => c.remove() })
    return () => c.remove()
  }, [])

  useMotion(ref, ({ q, el, mobile }) => {
    const plates = q<SVGSVGElement & HTMLElement>('.plate')
    const keys = plates.map((n) => n.dataset.plate as keyof typeof OFF)
    const k = mobile ? 0.6 : 1
    // time-based entrance (opacity + percent-offsets only, so it never fights the scrubbed px offsets)
    gsap.from(plates, { opacity: 0, xPercent: (i) => [-7, 6, -4, 5][i], duration: 1.5, ease: 'rmzOut', stagger: 0.12 })
    gsap.from('.hero-title', { yPercent: 14, opacity: 0, duration: 1.3, ease: 'rmzOut', delay: 0.35 })
    gsap.from('.hero-kick, .hero-cue, .hero-reg, .vlab, .cm', { opacity: 0, duration: 1, stagger: 0.05, delay: 0.9 })

    const tl = gsap.timeline({
      defaults: { ease: 'none' },
      scrollTrigger: { trigger: el, start: 'top top', end: mobile ? '+=95%' : '+=135%', pin: '.hero-pin', scrub: 0.25, anticipatePin: 1,
        onUpdate: (s) => { if (readout.current) readout.current.textContent = `${Math.round(s.progress * 100)}%` } },
    })
    // the displaced frame expands
    tl.from('.hero-frame', { clipPath: mobile ? 'inset(15% 10% 40% 10%)' : 'inset(17% 40% 15% 9%)' }, 0)
    // plates drift into register
    tl.from(plates, { x: (i) => OFF[keys[i]].x * k, y: (i) => OFF[keys[i]].y * k, rotation: (i) => OFF[keys[i]].r, scale: (i) => (keys[i] === 'c' ? 1.05 : 1) }, 0)
    // title ghosts lock too
    tl.from('.g-a', { x: -22 * k, y: 12 * k }, 0).from('.g-d', { x: 20 * k, y: -10 * k }, 0).from('.g-c', { x: -8 * k, y: -22 * k }, 0)
    tl.from('.hero-statement', { opacity: 0, y: 34, duration: 0.35 }, 0.62)
    tl.to('.hero-cue', { opacity: 0, duration: 0.2 }, 0.1)
    tl.from('.hero-shade', { opacity: 0, duration: 0.5 }, 0.3)
  })

  const [a, b, c] = p.statement
  return (
    <section ref={ref} className="hero" data-chapter="Entry" style={{ ['--pdisp' as string]: p.display, ['--ts' as string]: `${p.titleSize}vw`, ['--tsm' as string]: `${Math.min(31, p.titleSize * 1.05)}vw` }}>
      <div className="hero-pin">
        <div className="hero-frame grain"><div className="hero-plates"><Plates m={p.motif} pal={p.pal} /></div><div className="hero-shade" /></div>
        <i className="cm tl" /><i className="cm tr" /><i className="cm bl" /><i className="cm br" />
        <span className="vlab l kicker">{p.fullName}</span>
        <span className="vlab r kicker">{p.category}</span>
        <div className="hero-kick kicker"><b>N°{p.number}</b><span>Case study</span><span>{p.year}</span></div>
        <div className="hero-reg kicker" aria-hidden="true">
          <svg viewBox="0 0 40 40"><circle cx="20" cy="20" r="9" /><path d="M20 2v36M2 20h36" /></svg>
          <span>Register <span ref={readout}>0%</span></span>
        </div>
        <h1 className="hero-title" aria-label={p.name}>
          <span className="pt" aria-hidden="true">{p.name}</span>
          <span className="g g-a" aria-hidden="true">{p.name}</span><span className="g g-d" aria-hidden="true">{p.name}</span><span className="g g-c" aria-hidden="true">{p.name}</span>
        </h1>
        <p className="hero-statement">{a}<i className="accent">{b}</i>{c}</p>
        <div className="hero-cue kicker"><span />Scroll to register</div>
      </div>
    </section>
  )
}
