'use client'
import { useRef } from 'react'
import { useRouter } from 'next/navigation'
import type { Project } from '@/lib/projects'
import { Plates } from '../art/bloom'
import { gsap, useMotion, scrubCfg } from '@/lib/motion'
import '../../styles/end.css'

/* ============ OUTCOME ============ */
export function Outcome({ p }: { p: Project }) {
  const ref = useRef<HTMLElement>(null)
  useMotion(ref, ({ q }) => {
    q('.oc-v').forEach((n) => {
      const txt = n.dataset.v || ''
      const m = txt.match(/^([^\d]*)([\d.]+)(.*)$/)
      if (!m) return
      const dec = (m[2].split('.')[1] || '').length, end = parseFloat(m[2]), o = { v: 0 }
      gsap.to(o, { v: end, duration: 1.6, ease: 'power3.out', scrollTrigger: { trigger: n, start: 'top 85%', once: true }, onUpdate: () => { n.textContent = `${m[1]}${o.v.toFixed(dec)}${m[3]}` } })
    })
    gsap.from(q('.oc-r'), { opacity: 0, y: 40, duration: 0.9, ease: 'rmzOut', stagger: 0.1, scrollTrigger: { trigger: '.oc-m', start: 'top 85%' } })
  })
  if (!p.outcomes.length) return null
  return (
    <section ref={ref} className="oc" data-chapter="Outcome">
      <span className="kicker" style={{ color: 'var(--pa)' }}>The result</span>
      <h2 className="oc-h">Loud, and <i className="accent">measured.</i></h2>
      <div className="oc-m">{p.outcomes.map((o) => <div className="oc-r" key={o.label}><div className="oc-v" data-v={o.value}>{o.value}</div><p className="oc-l">{o.label}</p></div>)}</div>
      <div className="oc-cr">
        <dl>{p.credits.map((c) => <div className="row" key={c.role}><dt className="kicker">{c.role}</dt><dd>{c.who}</dd></div>)}</dl>
        <dl><div className="row"><dt className="kicker">Services</dt><dd style={{ textAlign: 'right' }}>{p.services.join(' · ')}</dd></div><div className="row"><dt className="kicker">Year</dt><dd>{p.year}</dd></div><div className="row"><dt className="kicker">Location</dt><dd>{p.location}</dd></div></dl>
      </div>
      <p className="oc-note kicker">Prototype demo project — brand, artwork and figures are fictional and illustrative.</p>
    </section>
  )
}

/* ============ NEXT PROJECT — the next work invades the closing frame ============ */
export function NextProject({ p, next }: { p: Project; next: Project }) {
  const ref = useRef<HTMLElement>(null)
  const router = useRouter()

  const open = (e: React.MouseEvent | React.KeyboardEvent) => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    try { sessionStorage.setItem('rmz-curtain', next.pal.a) } catch {}
    if (reduce) { router.push(`/work/${next.slug}/`); return }
    const x = 'clientX' in e ? e.clientX : window.innerWidth / 2, y = 'clientY' in e ? e.clientY : window.innerHeight / 2
    const c = document.createElement('div')
    c.className = 'nx-curtain'; c.style.background = next.pal.a; c.style.clipPath = `circle(0% at ${x}px ${y}px)`
    document.body.appendChild(c)
    gsap.to(c, { clipPath: `circle(150% at ${x}px ${y}px)`, duration: 0.8, ease: 'rmzInOut', onComplete: () => { router.push(`/work/${next.slug}/`); setTimeout(() => c.remove(), 400) } })
  }

  useMotion(ref, ({ el, q, mobile }) => {
    el.classList.add('stage')
    const plates = q<SVGSVGElement & HTMLElement>('.plate')
    const OFF: Record<string, [number, number, number]> = { a: [-60, 34, -2.6], b: [64, -38, 2], c: [-28, -58, 1], d: [42, 52, 3] }
    const tl = gsap.timeline({ defaults: { ease: 'none' }, scrollTrigger: scrubCfg(el, { dist: 170, pin: '.nx-pin', mobile, pinMobile: true }) })
    tl.fromTo('.nx-next', { clipPath: 'polygon(100% 0,100% 0,100% 100%,100% 100%)' }, { clipPath: 'polygon(-30% 0,100% 0,100% 100%,-60% 100%)', duration: 0.7, ease: 'power2.inOut' }, 0)
    tl.to('.nx-cur .big', { xPercent: -8, duration: 1 }, 0)
    tl.from(plates, { x: (i) => OFF[plates[i].dataset.plate!][0] * (mobile ? 0.6 : 1), y: (i) => OFF[plates[i].dataset.plate!][1] * (mobile ? 0.6 : 1), rotation: (i) => OFF[plates[i].dataset.plate!][2], duration: 0.7 }, 0.35)
    tl.from('.nx-title', { yPercent: 16, opacity: 0, duration: 0.4, ease: 'power2.out' }, 0.7)
    tl.from('.nx-title .g', { x: 30, y: -14, duration: 0.5 }, 0.7)
    tl.from('.nx-meta', { opacity: 0, duration: 0.3 }, 0.85)
    tl.from('.nx-open', { opacity: 0, scale: 0.8, duration: 0.3, ease: 'back.out(1.4)' }, 0.95)
    tl.to({}, { duration: 0.2 })
    return () => el.classList.remove('stage')
  })

  return (
    <section ref={ref} className="nx" data-chapter="Next project" style={{ ['--np' as string]: next.display, ['--nts' as string]: `${next.titleSize * 0.86}vw`, ['--ntm' as string]: `${next.titleSize * 0.8}vw`, ['--disp' as string]: p.display }}>
      <div className="nx-pin">
        <div className="nx-cur"><span className="kicker" style={{ color: 'var(--pa)' }}>End of N°{p.number}</span><div className="big" aria-hidden="true">{p.name}.</div></div>
        <div className="nx-next" style={{ ['--pa' as string]: next.pal.a, ['--pb' as string]: next.pal.b, ['--pc' as string]: next.pal.c, ['--pd' as string]: next.pal.d }}>
          <div className="nx-plates"><Plates m={next.motif} pal={next.pal} /></div>
          <div className="nx-meta kicker"><span>Next project — N°{next.number}</span><span>{next.category} · {next.year}</span></div>
          <h2 className="nx-title"><span>{next.name}</span><span className="g" aria-hidden="true" style={{ color: next.pal.a }}>{next.name}</span></h2>
          <button className="nx-hit" onClick={open} tabIndex={-1} aria-hidden="true" />
          <button className="nx-open" onClick={open}>Open {next.name.charAt(0) + next.name.slice(1).toLowerCase()}
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 12h17M13 5l7 7-7 7" /></svg></button>
        </div>
      </div>
    </section>
  )
}
