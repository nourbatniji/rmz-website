'use client'
import { useEffect, useRef, useState } from 'react'
import type { Project } from '@/lib/projects'
import { Still } from '../art/stills'
import { Poster, type PosterKind } from '../art/posters'
import { FlatCan, Motif, F, uid } from '../art/bloom'
import { gsap, ScrollTrigger, useMotion } from '@/lib/motion'
import '../../styles/chapters3.css'

/* ============ PHOTOGRAPHY — editorial grid + hotspot details ============ */
const PINS = [
  { x: 43, y: 38, t: 'The bloom is cropped', d: 'It reads as a flower from five metres and as a pattern from fifty centimetres. Every shot keeps one petal cut by the frame.' },
  { x: 62, y: 63, t: 'Cold, never clean', d: 'Ice is half-melted and the can is shot wet. We rejected every frame that looked retouched flat.' },
  { x: 20, y: 20, t: 'One petal out of register', d: 'The only place the print error enters photography: a single petal drifting off its plate, mid-air.' },
]
export function Photo({ p }: { p: Project }) {
  const ref = useRef<HTMLElement>(null)
  const [on, setOn] = useState<number | null>(null)
  useMotion(ref, ({ q }) => {
    q('.fg').forEach((fg) => {
      const box = fg.querySelector('.fg-box'), inner = fg.querySelector('.in')
      if (box) gsap.fromTo(box, { clipPath: 'inset(0 0 100% 0)' }, { clipPath: 'inset(0 0 0% 0)', duration: 1.2, ease: 'rmzOut', scrollTrigger: { trigger: fg, start: 'top 86%', toggleActions: 'play none none reverse' } })
      if (inner) gsap.fromTo(inner, { yPercent: -7 }, { yPercent: 7, ease: 'none', scrollTrigger: { trigger: fg, start: 'top bottom', end: 'bottom top', scrub: true } })
    })
  })
  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === 'Escape' && setOn(null)
    window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k)
  }, [])
  const pin = on !== null ? PINS[on] : null
  return (
    <section ref={ref} className="ph" data-chapter="Photography">
      <div className="ph-grid">
        <figure className="fg fg-1"><div className="fg-box"><div className="in"><Still kind="pour" pal={p.pal} /></div></div><figcaption className="kicker"><span>P—01 · The pour</span><span>Studio, backlit</span></figcaption></figure>
        <figure className="fg fg-2"><div className="fg-box"><div className="in"><Still kind="macro" pal={p.pal} /></div></div><figcaption className="kicker"><span>P—02 · Bloom, macro</span><span>100 mm</span></figcaption></figure>
        <figure className="fg fg-3"><div className="fg-box"><div className="in"><Still kind="flat" pal={p.pal} /></div></div><figcaption className="kicker"><span>P—03 · Overhead</span><span>Table, noon</span></figcaption></figure>
        <div className="fg-n"><span className="kicker" style={{ color: 'var(--yellow)' }}>Photography direction</span><h3>Light with <i className="accent">heat</i></h3><p>Hard sun, wet cans, real condensation. Every frame is lit like a summer afternoon in the city, because that is when it gets drunk.</p></div>
        <figure className="fg fg-4"><div className="fg-box"><div className="in"><Still kind="dusk" pal={p.pal} /></div></div><figcaption className="kicker"><span>P—04 · Dusk, rooftop</span><span>The hour it sells</span></figcaption></figure>
      </div>

      <div className="hs" onClick={() => setOn(null)}>
        <div className={`hs-fig ${on !== null ? 'zoom' : ''}`}>
          <div className="hs-img" style={{ transformOrigin: pin ? `${pin.x}% ${pin.y}%` : '50% 50%', transform: pin ? 'scale(2)' : 'scale(1)' }}><Still kind="sun" pal={p.pal} /></div>
          {PINS.map((q, i) => (
            <button key={q.t} className="hs-pin" style={{ left: `${q.x}%`, top: `${q.y}%` }} aria-pressed={on === i} aria-label={`Detail ${i + 1}: ${q.t}`}
              onClick={(e) => { e.stopPropagation(); setOn(on === i ? null : i) }}>{i + 1}</button>
          ))}
        </div>
        <div className="hs-side" onClick={(e) => e.stopPropagation()}>
          <span className="kicker" style={{ color: 'var(--yellow)' }}>Detail reveal — tap a pin</span>
          <h3>Three <i className="accent">decisions</i></h3>
          <ul className="hs-list">
            {PINS.map((q, i) => (
              <li key={q.t}><button aria-pressed={on === i} onClick={() => setOn(on === i ? null : i)}>
                <span className="n">0{i + 1}</span><span className="t">{q.t}</span><span className="d"><p>{q.d}</p></span>
              </button></li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  )
}

/* ============ SOCIAL — drifting feed with velocity skew ============ */
const COLS: { k: PosterKind; s: 's' | 't' }[][] = [
  [{ k: 'quote', s: 't' }, { k: 'bloomtype', s: 's' }, { k: 'stat', s: 't' }, { k: 'night', s: 's' }],
  [{ k: 'can', s: 's' }, { k: 'promo', s: 't' }, { k: 'type', s: 's' }, { k: 'stripes', s: 't' }],
  [{ k: 'stripes', s: 't' }, { k: 'stat', s: 's' }, { k: 'quote', s: 't' }, { k: 'promo', s: 's' }],
]
export function Social({ p }: { p: Project }) {
  const ref = useRef<HTMLElement>(null)
  useMotion(ref, ({ el, q, mobile }) => {
    const cols = q('.so-col'), win = el.querySelector('.so-win')!
    const ranges: [string, string][] = [['4%', '-34%'], ['-36%', '2%'], ['0%', '-30%']]
    cols.forEach((c, i) => gsap.fromTo(c, { yPercent: parseFloat(ranges[i][0]) * (mobile ? 0.6 : 1) }, { yPercent: parseFloat(ranges[i][1]) * (mobile ? 0.6 : 1), ease: 'none', scrollTrigger: { trigger: win, start: 'top bottom', end: 'bottom top', scrub: 0.2 } }))
    const skew = gsap.quickTo(cols, 'skewY', { duration: 0.5, ease: 'power3.out' })
    ScrollTrigger.create({ trigger: win, start: 'top bottom', end: 'bottom top', onUpdate: (s) => skew(gsap.utils.clamp(-6, 6, s.getVelocity() / -380)) })
  })
  const handle = '@drinkzahr'
  return (
    <section ref={ref} className="so" data-chapter="Social">
      <div className="so-head"><h2>Feed <i className="accent">drift</i></h2><span className="kicker" style={{ textAlign: 'right' }}>Social — stories &amp; tiles<br />{handle} · 10 of 64 shown</span></div>
      <div className="so-win">
        <div className="so-cols">
          {COLS.map((col, ci) => (
            <div className="so-col" key={ci}>
              {col.map((it, i) => (
                <div className={`so-item ${it.s}`} key={i}>
                  <Poster kind={it.k} pal={p.pal} m={p.motif} ratio={it.s === 's' ? 'story' : 'square'} />
                  <div className="so-ui" aria-hidden="true">
                    {it.s === 's' ? <div className="so-bars"><i /><i /><i /></div> : <span />}
                    <div className="so-row"><span>{handle}</span><span>{it.s === 's' ? 'Story' : '♥ 2.4k'}</span></div>
                  </div>
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ============ DIGITAL & MOTION ============ */
function MotionLoop({ p }: { p: Project }) {
  const c = p.pal
  return (
    <svg viewBox="-800 -335 1600 670" preserveAspectRatio="xMidYMid slice" role="img" aria-label="Looping brand film: the bloom opens behind the wordmark">
      <rect x="-800" y="-335" width="1600" height="670" fill={c.a} />
      <circle className="ml-ring" r="520" fill="none" stroke={c.d} strokeWidth="10" />
      <g className="ml-spin"><g transform="scale(1.15)">
        {[0, 1, 2, 3, 4].map((i) => <g key={`l${i}`} transform={`rotate(${36 + i * 72})`}><path className="ml-p" style={{ ['--i' as string]: i + 5 }} fill={c.c} d="M0 -190 C46 -260 44 -350 0 -430 C-44 -350 -46 -260 0 -190Z" /></g>)}
        {[0, 1, 2, 3, 4].map((i) => <g key={i} transform={`rotate(${i * 72})`}><path className="ml-p" style={{ ['--i' as string]: i }} fill={c.b} d="M0 0 C130 -40 175 -190 0 -300 C-175 -190 -130 -40 0 0Z" /></g>)}
      </g></g>
      <circle className="ml-core" r="54" fill={c.d} />
      <g fontFamily={F} fontWeight="900" fontSize="118" letterSpacing="-4" textAnchor="middle" >
        {['DRINK THE', 'BLOOM LOUD.'].map((l, i) => <text key={l} className="ml-w" style={{ ['--i' as string]: i }} y={i ? 250 : -120} x="-420" fill={i ? c.d : c.b} opacity="0" textAnchor="middle">{l}</text>)}
      </g>
    </svg>
  )
}

export function Digital({ p }: { p: Project }) {
  const ref = useRef<HTMLElement>(null)
  const tc = useRef<HTMLSpanElement>(null)
  const [playing, setPlaying] = useState(true)
  const id = uid(); void id
  useMotion(ref, ({ el, mobile }) => {
    const tl = gsap.timeline({ defaults: { ease: 'none' }, scrollTrigger: { trigger: '.wm', start: mobile ? 'top 85%' : 'top 78%', end: mobile ? 'bottom 35%' : 'bottom 28%', scrub: 0.3 } })
    tl.fromTo('.wm', { rotationX: mobile ? 6 : 14, scale: 0.92, y: 40 }, { rotationX: 0, scale: 1, y: 0, duration: 0.35, ease: 'power2.out' }, 0)
    tl.fromTo('.wm-page', { yPercent: 0 }, { yPercent: -66.666, duration: 1 }, 0.1)
    void el
  })
  useEffect(() => {
    if (!playing) return
    let raf = 0; const t0 = performance.now()
    const f = () => {
      const t = ((performance.now() - t0) / 1000) % 6
      const s = Math.floor(t), fr = Math.floor((t % 1) * 24)
      if (tc.current) tc.current.textContent = `00:00:0${s}:${String(fr).padStart(2, '0')}`
      raf = requestAnimationFrame(f)
    }
    raf = requestAnimationFrame(f); return () => cancelAnimationFrame(raf)
  }, [playing])
  const cm = { petal: p.pal.b, leaf: p.pal.c, core: p.pal.d, vein: p.pal.a }
  return (
    <section ref={ref} className="dg" data-chapter="Digital & motion">
      <div className="dg-head"><h2>Scroll <i className="accent">the site</i></h2><span className="kicker" style={{ textAlign: 'right' }}>Digital — zahr.co<br />Launch site &amp; cooler locator</span></div>
      <div className="dg-persp">
        <div className="wm" role="img" aria-label="Browser mock of the Zahr website scrolling through hero, flavours and store locator">
          <div className="wm-bar"><i /><i /><i /><span className="wm-url">zahr.co</span></div>
          <div className="wm-vp"><div className="wm-page">
            <div className="wm-s wm-s1"><div className="wm-nav">ZAHR<span><b>Flavours</b><b>Find a cooler</b><b>Story</b></span></div>
              <div className="wm-big">{p.name}</div><svg className="wm-can" viewBox="-110 -230 220 460"><FlatCan flavor="original" pal={p.pal} w={200} /></svg><a className="wm-btn" href="#top" onClick={(e) => e.preventDefault()}>Find your cooler</a></div>
            <div className="wm-s wm-s2">
              {(['original', 'ginger', 'mint'] as const).map((f, i) => (
                <div key={f} className="wm-card" style={{ background: [p.pal.a, p.pal.d, p.pal.c][i], color: [p.pal.b, p.pal.ink, p.pal.b][i] }}>
                  <svg className="art" viewBox="-130 -250 260 500" preserveAspectRatio="xMidYMid meet"><FlatCan flavor={f} pal={p.pal} w={150} y={-20} /></svg><b>{['Original', 'Ginger Fire', 'Mint Rush'][i]}</b></div>
              ))}</div>
            <div className="wm-s wm-s3"><div><div className="kicker" style={{ color: p.pal.d }}>Cooler locator</div><h4>Cold, within<br />300 metres.</h4></div><div className="wm-map" /></div>
          </div></div>
        </div>
      </div>

      <div className="mr">
        <div className={`mr-screen ${playing ? '' : 'paused'}`}>
          <MotionLoop p={p} />
          <div className="mr-ui"><span className="mr-tc">TC <span ref={tc}>00:00:00:00</span></span>
            <button className="mr-btn" aria-pressed={!playing} onClick={() => setPlaying((v) => !v)}>{playing ? 'Pause' : 'Play'}</button></div>
        </div>
        <div className="mr-meta kicker"><span>Brand film — “Bloom”, 6 s loop, 2.39:1</span><span>Motion · 24 fps</span></div>
      </div>
      <svg width="0" height="0" aria-hidden="true"><g><Motif m={p.motif} colors={cm} /></g></svg>
    </section>
  )
}
