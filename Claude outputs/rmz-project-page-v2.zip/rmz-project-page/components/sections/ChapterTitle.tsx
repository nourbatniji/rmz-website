'use client'
import { useRef } from 'react'
import { gsap, ScrollTrigger, useMotion } from '@/lib/motion'

type V = 'marquee' | 'rise' | 'sweep'
/** Typography-led transition between gallery chapters. Each variant moves differently so the rhythm never repeats. */
export default function ChapterTitle({ n, word, v = 'marquee', light = false, note }: { n: string; word: string; v?: V; light?: boolean; note?: string }) {
  const ref = useRef<HTMLDivElement>(null)
  useMotion(ref, ({ el }) => {
    const rowA = el.querySelector('.r1'), rowB = el.querySelector('.r2')
    if (v === 'marquee') {
      gsap.fromTo(rowA, { xPercent: 4 }, { xPercent: -34, ease: 'none', scrollTrigger: { trigger: el, start: 'top bottom', end: 'bottom top', scrub: true } })
      gsap.fromTo(rowB, { xPercent: -40 }, { xPercent: 0, ease: 'none', scrollTrigger: { trigger: el, start: 'top bottom', end: 'bottom top', scrub: true } })
      const skew = gsap.quickTo(el.querySelectorAll('.ct-word'), 'skewX', { duration: 0.4, ease: 'power3.out' })
      ScrollTrigger.create({ trigger: el, start: 'top bottom', end: 'bottom top', onUpdate: (s) => skew(gsap.utils.clamp(-8, 8, s.getVelocity() / -260)) })
    }
    if (v === 'rise') {
      gsap.from(el.querySelectorAll('.ch'), { yPercent: 115, duration: 1.1, ease: 'rmzOut', stagger: 0.045, scrollTrigger: { trigger: el, start: 'top 80%', toggleActions: 'play none none reverse' } })
    }
    if (v === 'sweep') {
      gsap.fromTo(el.querySelector('.fill'), { clipPath: 'inset(0 100% 0 0)' }, { clipPath: 'inset(0 0% 0 0)', ease: 'none', scrollTrigger: { trigger: el, start: 'top 85%', end: 'bottom 45%', scrub: true } })
    }
  })
  return (
    <div ref={ref} className={`ct ${light ? 'light' : ''}`}>
      <div className="ct-meta kicker"><span>Chapter {n}</span><span>{note}</span></div>
      {v === 'marquee' && (
        <div aria-hidden="true">
          <div className="ct-line"><span className="ct-word r1">{word} — {word} — {word}</span></div>
          <div className="ct-line"><span className="ct-word out r2">{word} — {word} — {word}</span></div>
        </div>
      )}
      {v === 'rise' && <h2 className="ct-word" aria-label={word}>{word.split('').map((c, i) => <span key={i} className="ln" style={{ display: 'inline-block' }} aria-hidden="true"><span className="ch" style={{ display: 'inline-block' }}>{c === ' ' ? ' ' : c}</span></span>)}</h2>}
      {v === 'sweep' && (
        <h2 className="ct-sweep" aria-label={word} style={{ position: 'relative', display: 'inline-block', margin: 0 }}>
          <span className="ct-word out" aria-hidden="true">{word}</span>
          <span className="ct-word fill" aria-hidden="true" style={{ position: 'absolute', left: 0, top: 0, color: light ? 'var(--pa)' : 'var(--yellow)' }}>{word}</span>
        </h2>
      )}
    </div>
  )
}
