'use client'
import { useRef } from 'react'
import type { Project } from '@/lib/projects'
import { Still } from '../art/stills'
import { Poster } from '../art/posters'
import { gsap, useMotion } from '@/lib/motion'
import '../../styles/intro.css'

const L = ({ children }: { children: React.ReactNode }) => <span className="ln"><span>{children}</span></span>

export default function Intro({ p }: { p: Project }) {
  const ref = useRef<HTMLElement>(null)
  useMotion(ref, ({ q, el }) => {
    // headline + body lines rise out of their masks as they arrive
    q('.rv').forEach((node) => {
      gsap.from(node.querySelectorAll('.ln > span'), {
        yPercent: 112, duration: 1.05, ease: 'rmzOut', stagger: 0.09,
        scrollTrigger: { trigger: node, start: 'top 86%', toggleActions: 'play none none reverse' },
      })
    })
    // layered still drifts against the scroll
    gsap.fromTo('.intro-still > div', { yPercent: -9 }, { yPercent: 9, ease: 'none', scrollTrigger: { trigger: '.intro-still', start: 'top bottom', end: 'bottom top', scrub: true } })
    gsap.from('.intro-still', { rotation: -3, y: 70, opacity: 0, duration: 1.2, ease: 'rmzOut', scrollTrigger: { trigger: '.intro-head', start: 'top 70%' } })
    gsap.from(q('.fact'), { opacity: 0, y: 40, duration: 0.9, ease: 'rmzOut', stagger: 0.1, scrollTrigger: { trigger: '.intro-facts', start: 'top 82%' } })
    void el
  })
  const [l1, l2, l3] = p.headline
  return (
    <section ref={ref} className="intro" data-chapter="The thinking">
      <div className="intro-kick kicker">01 — The thinking behind the work</div>
      <h2 className="intro-head rv" aria-label={p.headline.join(' ')}>
        <L>{l1}</L><L>{l2}</L><L>{l3.split(' ').slice(0, -1).join(' ')}{l3.includes(' ') ? ' ' : ''}<i className="accent">{l3.split(' ').slice(-1)}</i></L>
      </h2>
      <figure className="intro-still" aria-hidden="true"><div>{p.motif === 'bloom' ? <Still kind="sun" pal={p.pal} /> : <Poster kind="stripes" pal={p.pal} m={p.motif} />}</div><figcaption>Fig. 01 — {p.name}</figcaption></figure>

      <dl className="intro-facts">
        <div className="fact"><dt className="kicker">Client</dt><dd>{p.client}</dd></div>
        <div className="fact"><dt className="kicker">Industry</dt><dd>{p.industry}</dd></div>
        <div className="fact"><dt className="kicker">Services</dt><dd>{p.services.slice(0, 5).map((s, i) => <span key={s}>{s}{(i < 4 || p.services.length > 5) && <em>/</em>}{' '}</span>)}{p.services.length > 5 && <em>+{p.services.length - 5}</em>}</dd></div>
      </dl>

      <div className="intro-duo">
        <div className="duo rv"><div className="kicker" style={{ color: 'var(--yellow)' }}>The creative challenge</div><h3><L>The</L><L>problem</L></h3><p><span className="ln"><span>{p.challenge}</span></span></p></div>
        <div className="duo s rv"><div className="kicker" style={{ color: 'var(--yellow)' }}>The creative solution</div><h3><L>The</L><L>answer</L></h3><p><span className="ln"><span>{p.solution}</span></span></p></div>
      </div>
      <div className="intro-concept rv"><span className="kicker" style={{ color: 'var(--yellow)' }}>Project concept</span><p><span className="ln"><span>{p.concept}</span></span></p></div>
    </section>
  )
}
