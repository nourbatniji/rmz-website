'use client'
import { useRef, type ReactNode } from 'react'
import type { Project } from '@/lib/projects'
import { Wrap, flavorSpec, type Flavor } from '../art/bloom'
import { Poster, Billboard } from '../art/posters'
import { gsap, useMotion, scrubCfg } from '@/lib/motion'
import '../../styles/chapters2.css'

const FLAVORS: Flavor[] = ['original', 'ginger', 'mint']

/* ============ PACKAGING — "Unwrap" ============ */
export function Pack({ p }: { p: Project }) {
  const ref = useRef<HTMLElement>(null)
  const spec = flavorSpec(p.pal)
  useMotion(ref, ({ el, q, mobile }) => {
    const tracks = q('.pk-track'), info = q('.pk-flavor'), dies = q('.pk-die-box > .d'), wins = q('.pk-win'), cnt = el.querySelector('.pk-count')!, pin = el.querySelector<HTMLElement>('.pk-pin')!
    const N = FLAVORS.length
    gsap.set(tracks.slice(1), { opacity: 0 }); gsap.set(info.slice(1), { opacity: 0, y: 24 })
    const prog = { v: 0 }
    const setWins = () => {
      const f = prog.v % 1
      gsap.set(wins[0], { left: `${f * 100}%` }); gsap.set(wins[1], { left: `${f * 100 - 100}%` })
    }
    const tl = gsap.timeline({ defaults: { ease: 'none' }, scrollTrigger: { ...scrubCfg(el, { dist: 300, pin: '.pk-pin', mobile, pinMobile: true }),
      onUpdate: (s) => { const n = Math.min(N, Math.floor(s.progress * N * 0.999) + 1); cnt.textContent = `0${n} / 0${N}` } } })
    FLAVORS.forEach((fl, i) => {
      const t = i
      tl.fromTo(tracks[i], { xPercent: 0 }, { xPercent: -50, duration: 1 }, t)
      tl.fromTo(prog, { v: 0 }, { v: 1, duration: 1, onUpdate: setWins }, t)
      tl.fromTo(el.querySelector('.pk-can'), { scale: 0.94 }, { scale: 1.02, duration: 1, yoyo: true }, t)
      if (i > 0) {
        tl.to(tracks[i - 1], { opacity: 0, duration: 0.12 }, t - 0.06).to(tracks[i], { opacity: 1, duration: 0.12 }, t - 0.06)
        tl.to(info[i - 1], { opacity: 0, y: -24, duration: 0.2 }, t - 0.1).to(info[i], { opacity: 1, y: 0, duration: 0.25 }, t - 0.02)
        tl.to(dies[i - 1], { opacity: 0, duration: 0.1 }, t - 0.05).to(dies[i], { opacity: 1, duration: 0.1 }, t - 0.05)
        tl.set(pin, { '--fl': spec[fl].bg }, t - 0.05)
      }
    })
    gsap.set(pin, { '--fl': spec.original.bg })
  })
  return (
    <section ref={ref} className="pk" data-chapter="Packaging">
      <div className="pk-pin" style={{ ['--fl' as string]: spec.original.bg }}>
        <div className="pk-head">
          <span className="kicker" style={{ color: 'var(--yellow)' }}>Packaging — 330 ml aluminium</span>
          <h2>Unwrap <i className="accent">the can</i></h2>
          <p>One flat label, one full revolution. Scroll turns the can; the dieline below shows what you’re looking at.</p>
        </div>
        <div className="pk-can" role="img" aria-label="The Zahr can rotating through its three flavours">
          <div className="pk-base" /><div className="pk-body">
            {FLAVORS.map((f) => (
              <div className="pk-track" key={f}><div className="pk-copy"><Wrap flavor={f} pal={p.pal} m={p.motif} /></div><div className="pk-copy"><Wrap flavor={f} pal={p.pal} m={p.motif} /></div></div>
            ))}
          </div>
          <div className="pk-shade" /><div className="pk-lid" />
        </div>
        <div className="pk-info" aria-live="polite">
          {FLAVORS.map((f, i) => (
            <div className="pk-flavor" key={f}>
              <span className="pk-chip kicker"><i style={{ background: spec[f].bg }} />Flavour 0{i + 1}</span>
              <h3>{spec[f].name}</h3><p>{spec[f].note}</p><p style={{ opacity: 0.7 }}>{spec[f].abv}</p>
            </div>
          ))}
        </div>
        <div className="pk-count" aria-hidden="true">01 / 03</div>
        <div className="pk-die" aria-hidden="true">
          <div className="pk-die-lab kicker"><span>Dieline — flat label, 1 revolution</span><span>Frame = what you see</span></div>
          <div className="pk-die-box">
            {FLAVORS.map((f) => <div className="d" key={f}><Wrap flavor={f} pal={p.pal} m={p.motif} /></div>)}
            <div className="pk-win" /><div className="pk-win" />
          </div>
        </div>
      </div>
    </section>
  )
}

/* ============ CAMPAIGN — "Fold-out" ============ */
function Fold({ pal, layout }: { pal: Project['pal']; layout: 'wide' | 'tall' }) {
  const render = (i: number): ReactNode => (
    <div className="fp" data-i={i}>
      <div className="fp-face"><div className="fp-art" style={{ ['--i' as string]: i }}><Billboard pal={pal} layout={layout} /></div><i className="fp-shade" /></div>
      {i < 3 && render(i + 1)}
    </div>
  )
  return <div className={`fold fold--${layout === 'wide' ? 'h' : 'v'}`}>{render(0)}</div>
}

export function Campaign({ p }: { p: Project }) {
  const ref = useRef<HTMLElement>(null)
  useMotion(ref, ({ el, q, mobile }) => {
    const fold = el.querySelector<HTMLElement>(mobile ? '.fold--v' : '.fold--h')!
    const panels = Array.from(fold.querySelectorAll<HTMLElement>('.fp'))
    const T = mobile ? 74 : 72
    const prop = mobile ? 'rotationX' : 'rotationY'
    const dir = [-1, 2, -2, 2].map((m) => m * (mobile ? -1 : 1))
    const shades = panels.map((pn) => pn.querySelector<HTMLElement>(':scope > .fp-face > .fp-shade')!)
    const closedShift = mobile ? fold.offsetHeight * 0.34 : fold.offsetWidth * 0.34
    const tl = gsap.timeline({ defaults: { ease: 'none' }, scrollTrigger: scrubCfg(el.querySelector('.cp-pin')!, { dist: 130, pin: mobile ? false : '.cp-pin', mobile, mStart: 'top 55%', mEnd: 'center 30%' }) })
    panels.forEach((pn, i) => {
      tl.fromTo(pn, { [prop]: dir[i] * T }, { [prop]: 0, ease: 'power2.inOut', duration: 1 }, 0)
      tl.fromTo(shades[i], { opacity: i % 2 ? 0.55 : 0.25 }, { opacity: 0, ease: 'power2.inOut', duration: 1 }, 0)
    })
    tl.fromTo(fold, { [mobile ? 'y' : 'x']: closedShift }, { [mobile ? 'y' : 'x']: 0, ease: 'power2.inOut', duration: 1 }, 0)
    tl.to({}, { duration: 0.2 })
    // posters: each arrives with its own mask + speed
    q('.pst').forEach((pst, i) => {
      gsap.fromTo(pst.querySelector('.pst-box'), { clipPath: 'inset(100% 0 0 0)' }, { clipPath: 'inset(0% 0 0 0)', duration: 1.1, ease: 'rmzOut', scrollTrigger: { trigger: pst, start: 'top 88%', toggleActions: 'play none none reverse' } })
      if (!mobile) gsap.fromTo(pst, { y: [60, -30, 40][i] }, { y: [-40, 40, -60][i], ease: 'none', scrollTrigger: { trigger: pst, start: 'top bottom', end: 'bottom top', scrub: true } })
    })
  })
  return (
    <section ref={ref} className="cp" data-chapter="Campaign">
      <div className="cp-pin">
        <div className="cp-head"><h2>Unfold <i className="accent" style={{ color: 'var(--pa)' }}>the city</i></h2><span className="kicker">Out-of-home — 4-panel fold<br />“Drink the bloom loud.”</span></div>
        <div className="cp-persp">
          <Fold pal={p.pal} layout="wide" /><Fold pal={p.pal} layout="tall" />
        </div>
        <div className="cp-cap kicker"><span>Billboard · Ring Road, Cairo</span><span>12 × 5 m</span></div>
      </div>
      <div className="cp-posters">
        <figure className="pst pst-1"><div className="pst-box"><Poster kind="bloomtype" pal={p.pal} m={p.motif} /></div><figcaption className="kicker"><span>Poster 01 — Bloom</span><span>70 × 100</span></figcaption></figure>
        <figure className="pst pst-2"><div className="pst-box"><Poster kind="type" pal={p.pal} m={p.motif} /></div><figcaption className="kicker"><span>Poster 02 — Loud</span><span>Street</span></figcaption></figure>
        <figure className="pst pst-3"><div className="pst-box"><Poster kind="night" pal={p.pal} m={p.motif} /></div><figcaption className="kicker"><span>Poster 03 — Dusk</span><span>Metro</span></figcaption></figure>
      </div>
    </section>
  )
}
