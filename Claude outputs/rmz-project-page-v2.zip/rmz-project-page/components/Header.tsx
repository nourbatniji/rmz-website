'use client'
import { useEffect, useRef, useState } from 'react'
import { gsap, ScrollTrigger } from '@/lib/motion'

export default function Header({ name }: { name: string }) {
  const [chapters, setChapters] = useState<{ label: string; el: HTMLElement }[]>([])
  const [active, setActive] = useState(0)
  const [open, setOpen] = useState(false)
  const hdr = useRef<HTMLElement>(null)

  useEffect(() => {
    const els = Array.from(document.querySelectorAll<HTMLElement>('[data-chapter]'))
    const seen: { label: string; el: HTMLElement }[] = []
    els.forEach((el) => { const label = el.dataset.chapter!; if (!seen.some((s) => s.label === label)) seen.push({ label, el }) })
    setChapters(seen)
    const sts = seen.map((c, i) => ScrollTrigger.create({ trigger: c.el, start: 'top 55%', end: 'bottom 55%', onToggle: (s) => s.isActive && setActive(i) }))
    const bar = ScrollTrigger.create({ start: 0, end: 'max', onUpdate: (s) => hdr.current?.style.setProperty('--p', String(s.progress)) })
    return () => { sts.forEach((s) => s.kill()); bar.kill() }
  }, [name])

  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false)
    window.addEventListener('keydown', k)
    document.body.style.overflow = open ? 'hidden' : ''
    return () => { window.removeEventListener('keydown', k); document.body.style.overflow = '' }
  }, [open])

  const go = (el: HTMLElement) => {
    setOpen(false)
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    setTimeout(() => {
      const st = ScrollTrigger.getAll().find((s) => s.trigger === el && s.pin)
      const top = st ? st.start : el.getBoundingClientRect().top + window.scrollY
      window.scrollTo({ top, behavior: reduce ? 'auto' : 'smooth' })
    }, 60)
  }
  const cur = chapters[active]

  return (
    <>
      <header ref={hdr} className="hdr">
        <a className="hdr-logo" href="/" aria-label="RMZ — back to work">RMZ<i>.</i></a>
        <div className="hdr-now" aria-live="polite"><b>{String(active + 1).padStart(2, '0')} / {String(chapters.length).padStart(2, '0')}</b><span>{cur?.label ?? ''}</span></div>
        <button className="hdr-btn" aria-expanded={open} aria-controls="idx" onClick={() => setOpen(true)}>Index</button>
        <i className="hdr-bar" aria-hidden="true" />
      </header>
      <nav id="idx" className={`idx ${open ? 'open' : ''}`} aria-label="Chapters" aria-hidden={!open}>
        <button className="idx-close" onClick={() => setOpen(false)} tabIndex={open ? 0 : -1}>Close</button>
        {chapters.map((c, i) => <a key={c.label} href={`#${i}`} tabIndex={open ? 0 : -1} onClick={(e) => { e.preventDefault(); go(c.el) }}><span>{String(i + 1).padStart(2, '0')}</span>{c.label}</a>)}
      </nav>
    </>
  )
}
