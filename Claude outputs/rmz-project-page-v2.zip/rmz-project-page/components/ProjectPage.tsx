'use client'
import { Fragment, useEffect } from 'react'
import { projects, chapterLabels, type Project } from '@/lib/projects'
import { ScrollTrigger } from '@/lib/motion'
import Header from './Header'
import Hero from './sections/Hero'
import Intro from './sections/Intro'
import Concept from './sections/Concept'
import ChapterTitle from './sections/ChapterTitle'
import { Identity, TypeChapter, ColorChapter, Interlude } from './sections/Chapters1'
import { Pack, Campaign } from './sections/Chapters2'
import { Photo, Social, Digital } from './sections/Chapters3'
import { Outcome, NextProject } from './sections/End'

const TITLE: Record<string, { v: 'marquee' | 'rise' | 'sweep'; light?: boolean; note: string }> = {
  identity: { v: 'marquee', note: 'Wordmark · mark · seal' },
  type: { v: 'sweep', light: true, note: 'Two faces, one voice' },
  color: { v: 'rise', note: 'Four inks' },
  pack: { v: 'marquee', note: 'Aluminium, 330 ml' },
  campaign: { v: 'rise', light: false, note: 'Out of home & print' },
  photo: { v: 'sweep', note: 'Light with heat' },
  social: { v: 'rise', note: 'Stories & tiles' },
  digital: { v: 'sweep', note: 'Web & motion' },
}

function Chapter({ k, p }: { k: string; p: Project }) {
  switch (k) {
    case 'identity': return <Identity p={p} />
    case 'type': return <TypeChapter p={p} />
    case 'color': return <ColorChapter p={p} />
    case 'still': return <Interlude p={p} kind="macro" text={['The hour the city exhales,', 'is the hour it drinks.']} caption="Fig. 07 — Bloom, uncropped" />
    case 'pack': return <Pack p={p} />
    case 'campaign': return <Campaign p={p} />
    case 'photo': return <Photo p={p} />
    case 'social': return <Social p={p} />
    case 'digital': return <Digital p={p} />
    default: return null
  }
}

export default function ProjectPage({ slug }: { slug: string }) {
  const p = projects[slug]
  const next = projects[p.next]

  useEffect(() => {
    window.scrollTo(0, 0)
    // fonts change text metrics → re-measure every pin once they are in
    document.fonts?.ready.then(() => ScrollTrigger.refresh())
    const t = setTimeout(() => ScrollTrigger.refresh(), 600)
    return () => clearTimeout(t)
  }, [slug])

  let n = 2
  return (
    <main className="page" key={slug} style={{ ['--pa' as string]: p.pal.a, ['--pb' as string]: p.pal.b, ['--pc' as string]: p.pal.c, ['--pd' as string]: p.pal.d, ['--pink' as string]: p.pal.ink, ['--disp' as string]: p.display }}>
      <Header name={slug} />
      <Hero p={p} />
      <Intro p={p} />
      <Concept p={p} />
      {p.gallery.map((k) => {
        const t = TITLE[k]
        if (t) n += 1
        return (
          <Fragment key={k}>
            {t && <ChapterTitle n={String(n).padStart(2, '0')} word={(chapterLabels[k] || k).toUpperCase()} v={t.v} light={t.light} note={t.note} />}
            <Chapter k={k} p={p} />
          </Fragment>
        )
      })}
      <Outcome p={p} />
      <NextProject p={p} next={next} />
    </main>
  )
}
