'use client'
import { useRef } from 'react'
import type { Story } from '@/lib/stories'
import { gsap, useMotion } from '@/lib/motion'
import { Frame } from './Frame'

/** Optional: rendered only when a story supplies `details`. */
export default function Details({ s, base }: { s: Story; base: number }) {
  const ref = useRef<HTMLElement>(null)
  useMotion(ref, ({ q }) => {
    gsap.from(q('.dt-copy > *'), { y: 30, opacity: 0, duration: 1, stagger: 0.08, ease: 'rmzOut', scrollTrigger: { trigger: ref.current, start: 'top 70%', once: true } })
    gsap.from(q('.dt-specs > div'), { opacity: 0, x: -16, duration: 0.8, stagger: 0.07, ease: 'rmzOut', scrollTrigger: { trigger: '.dt-specs', start: 'top 90%', once: true } })
  })
  if (!s.details?.length) return null
  let n = base
  return (
    <section className="dt" ref={ref} aria-label="Selected details">
      {s.details.map((d, i) => {
        const at = n; n += d.assets.length
        return (
          <div className="dt-row" key={i}>
            <div className="dt-copy">
              <p className="t-meta wk-nm wk-y dt-k">{d.kicker}</p>
              <h2 className="t-display dt-h">{d.title}</h2>
              <p className="t-body dt-p">{d.text}</p>
              <dl className="dt-specs">{d.specs.map(([k, v]) => <div key={k}><dt className="t-meta wk-nm s">{k}</dt><dd>{v}</dd></div>)}</dl>
            </div>
            <div className="dt-vis">{d.assets.map((a, k) => <Frame key={k} a={a} s={s} i={at + k} className={`dt-${k}`} />)}</div>
          </div>
        )
      })}
    </section>
  )
}
