import type { Pal } from '@/lib/projects'
import { F, G, uid } from '../art/bloom'

export type SceneKind = 'dunes' | 'arch' | 'glasses' | 'pool' | 'horizon' | 'palm' | 'poster'

/** Rendered stand-ins for location photography: lit, graded, grained. */
export function Scene({ kind, pal }: { kind: SceneKind; pal: Pal }) {
  const id = uid()
  const wave = (y: number, amp: number, ph: number) => {
    let d = `M-20 ${y}`
    for (let x = 0; x <= 1240; x += 40) d += ` L${x} ${y + Math.sin(x / 90 + ph) * amp}`
    return d
  }
  const frond = (n: number, len: number) =>
    Array.from({ length: n }, (_, i) => {
      const a = -80 + (160 / (n - 1)) * i
      return <path key={i} d={`M0 0 C${len * 0.3} ${-len * 0.12} ${len * 0.7} ${-len * 0.1} ${len} ${len * 0.12} C${len * 0.7} ${len * 0.02} ${len * 0.3} ${len * 0.05} 0 0Z`} transform={`rotate(${a})`} />
    })
  return (
    <svg className="art" viewBox="0 0 1200 1500" preserveAspectRatio="xMidYMid slice" role="img" aria-label={`${kind} photograph`}>
      <defs>
        <filter id={`${id}n`} x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency=".85" numOctaves="2" seed="7" /><feColorMatrix values="0 0 0 0 .5  0 0 0 0 .5  0 0 0 0 .5  0 0 0 .9 0" /></filter>
        <filter id={`${id}b`}><feGaussianBlur stdDeviation="22" /></filter>
        <filter id={`${id}b3`}><feGaussianBlur stdDeviation="3" /></filter>
        <linearGradient id={`${id}sky`} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#3B1F3F" /><stop offset=".35" stopColor="#B8453A" /><stop offset=".7" stopColor="#F59A55" /><stop offset="1" stopColor="#FFD9A0" /></linearGradient>
        <linearGradient id={`${id}sky2`} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#FFB878" /><stop offset=".6" stopColor="#FFE2B8" /><stop offset="1" stopColor="#FFF3DA" /></linearGradient>
        <radialGradient id={`${id}sun`}><stop offset="0" stopColor="#FFF6D6" /><stop offset=".45" stopColor="#FFD27A" stopOpacity=".95" /><stop offset="1" stopColor="#FFC561" stopOpacity="0" /></radialGradient>
        <radialGradient id={`${id}vig`} cx=".5" cy=".45" r=".78"><stop offset=".55" stopColor="#000" stopOpacity="0" /><stop offset="1" stopColor="#000" stopOpacity=".5" /></radialGradient>
        <linearGradient id={`${id}d1`} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#E9A064" /><stop offset="1" stopColor="#8E3B2A" /></linearGradient>
        <linearGradient id={`${id}d2`} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#C4663F" /><stop offset="1" stopColor="#4A1F22" /></linearGradient>
        <linearGradient id={`${id}d3`} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#8A3A2C" /><stop offset="1" stopColor="#2A1018" /></linearGradient>
        <linearGradient id={`${id}sea`} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#E88A52" /><stop offset=".25" stopColor="#7A4A5A" /><stop offset="1" stopColor="#1F3A4A" /></linearGradient>
        <linearGradient id={`${id}pool`} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#2BB3B0" /><stop offset="1" stopColor="#0E5560" /></linearGradient>
        <linearGradient id={`${id}lens`} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#3C2A22" /><stop offset=".5" stopColor="#14090B" /><stop offset="1" stopColor="#6B3F2C" /></linearGradient>
        <linearGradient id={`${id}stone`} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#F1D9B4" /><stop offset="1" stopColor="#C9966B" /></linearGradient>
        <linearGradient id={`${id}shaft`} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#FFE9B8" stopOpacity=".85" /><stop offset="1" stopColor="#FFD08A" stopOpacity=".15" /></linearGradient>
        <clipPath id={`${id}arch`}><path d="M300 1160 V560 A300 300 0 0 1 900 560 V1160Z" /></clipPath>
      </defs>

      {kind === 'dunes' && (
        <>
          <rect width="1200" height="1500" fill={`url(#${id}sky)`} />
          <circle cx="760" cy="640" r="420" fill={`url(#${id}sun)`} />
          <circle cx="760" cy="640" r="74" fill="#FFF3CF" />
          <path d="M-20 820 C200 760 420 800 640 860 C860 920 1040 880 1240 800 V1500 H-20Z" fill={`url(#${id}d3)`} />
          <path d="M-20 980 C260 880 520 940 760 1010 C980 1070 1120 1030 1240 990 V1500 H-20Z" fill={`url(#${id}d2)`} />
          <path d="M-20 1180 C200 1100 420 1120 640 1180 C860 1240 1040 1230 1240 1170 V1500 H-20Z" fill={`url(#${id}d1)`} />
          <path d="M-20 1180 C200 1100 420 1120 640 1180" fill="none" stroke="#FFE2B8" strokeWidth="3" opacity=".6" filter={`url(#${id}b3)`} />
          {Array.from({ length: 9 }, (_, i) => <path key={i} d={wave(1250 + i * 30, 5, i)} fill="none" stroke="#FFE9C8" strokeWidth="1.4" opacity={0.08 + i * 0.01} />)}
        </>
      )}

      {kind === 'arch' && (
        <>
          <rect width="1200" height="1500" fill={pal.a} />
          <rect width="1200" height="1500" fill="#000" opacity=".12" />
          <g clipPath={`url(#${id}arch)`}><rect x="300" y="200" width="600" height="1000" fill={`url(#${id}sky2)`} /><circle cx="640" cy="800" r="260" fill={`url(#${id}sun)`} /><circle cx="640" cy="800" r="46" fill="#FFF6D6" /></g>
          <path d="M300 1160 V560 A300 300 0 0 1 900 560 V1160Z" fill="none" stroke="#00000030" strokeWidth="26" />
          <rect y="1160" width="1200" height="340" fill="#D9A06C" />
          <path d="M300 1160 L900 1160 L1240 1500 L-40 1500Z" fill={`url(#${id}shaft)`} />
          <path d="M-40 1500 L300 1160 L330 1160 L120 1500Z" fill="#00000030" /><path d="M1240 1500 L900 1160 L870 1160 L1080 1500Z" fill="#00000030" />
          <rect y="1160" width="1200" height="14" fill="#00000026" />
        </>
      )}

      {kind === 'glasses' && (
        <>
          <rect width="1200" height="1500" fill={`url(#${id}stone)`} />
          <ellipse cx="600" cy="1020" rx="420" ry="46" fill="#4A1F22" opacity=".35" filter={`url(#${id}b)`} />
          <ellipse cx="240" cy="1180" rx="170" ry="26" fill="#4A1F22" opacity=".28" filter={`url(#${id}b)`} />
          <circle cx="240" cy="1090" r="130" fill={pal.d} /><ellipse cx="240" cy="1090" rx="130" ry="130" fill="#fff" opacity=".12" />
          <g transform="translate(600 800)">
            <path d="M-420 -30 L-290 -40 M420 -30 L290 -40" stroke="#14090B" strokeWidth="18" strokeLinecap="round" />
            <path d="M-420 -30 C-470 20 -480 120 -430 230" fill="none" stroke="#14090B" strokeWidth="16" strokeLinecap="round" />
            <circle cx="-170" cy="40" r="165" fill={`url(#${id}lens)`} stroke="#14090B" strokeWidth="22" /><circle cx="170" cy="40" r="165" fill={`url(#${id}lens)`} stroke="#14090B" strokeWidth="22" />
            <path d="M-26 8 C-8 -26 8 -26 26 8" fill="none" stroke="#14090B" strokeWidth="20" strokeLinecap="round" />
            <ellipse cx="-240" cy="-30" rx="58" ry="26" transform="rotate(-30 -240 -30)" fill="#fff" opacity=".42" /><ellipse cx="100" cy="-30" rx="58" ry="26" transform="rotate(-30 100 -30)" fill="#fff" opacity=".42" />
            <path d="M-300 120 C-220 200 -120 190 -60 120" fill="none" stroke={pal.d} strokeWidth="6" opacity=".55" /><path d="M40 120 C120 200 220 190 280 120" fill="none" stroke={pal.d} strokeWidth="6" opacity=".55" />
          </g>
        </>
      )}

      {kind === 'pool' && (
        <>
          <rect width="1200" height="1500" fill={`url(#${id}pool)`} />
          {Array.from({ length: 16 }, (_, i) => <path key={i} d={wave(40 + i * 92, 18 + (i % 3) * 8, i * 1.3)} fill="none" stroke="#E6FFFB" strokeWidth={2 + (i % 3)} opacity={0.14 + (i % 4) * 0.05} />)}
          {Array.from({ length: 10 }, (_, i) => <ellipse key={i} cx={(i * 197) % 1200} cy={(i * 331) % 1500} rx={70 + (i % 3) * 40} ry={30 + (i % 4) * 14} fill="#CFFFF6" opacity=".16" filter={`url(#${id}b)`} />)}
          <g transform="translate(940 1250) rotate(-24)"><rect x="-300" y="-110" width="600" height="220" fill={pal.b} />{Array.from({ length: 6 }, (_, i) => <rect key={i} x={-300 + i * 100} y="-110" width="50" height="220" fill={pal.a} />)}<rect x="-300" y="-110" width="600" height="220" fill="#000" opacity=".08" /></g>
        </>
      )}

      {kind === 'horizon' && (
        <>
          <rect width="1200" height="1500" fill={`url(#${id}sky)`} />
          <circle cx="600" cy="880" r="480" fill={`url(#${id}sun)`} />
          <path d="M360 880 A240 240 0 0 1 840 880Z" fill="#FFF0C4" />
          <rect y="880" width="1200" height="620" fill={`url(#${id}sea)`} />
          {Array.from({ length: 14 }, (_, i) => <rect key={i} x={600 - (150 - i * 6)} y={900 + i * 40} width={(150 - i * 6) * 2} height={5 + i * 0.6} rx="3" fill="#FFE3A8" opacity={0.85 - i * 0.055} />)}
          <path d="M-20 520 C300 470 600 500 900 450 C1040 430 1140 440 1240 450" fill="none" stroke="#FFD9A0" strokeWidth="10" opacity=".35" filter={`url(#${id}b3)`} />
          <path d="M-20 640 C260 610 520 630 800 596" fill="none" stroke="#FFD9A0" strokeWidth="6" opacity=".3" filter={`url(#${id}b3)`} />
        </>
      )}

      {kind === 'palm' && (
        <>
          <rect width="1200" height="1500" fill={`url(#${id}sky2)`} />
          <rect width="1200" height="1500" fill={pal.d} opacity=".22" />
          <g fill="#2A1018" opacity=".78" filter={`url(#${id}b3)`}>
            <g transform="translate(-40 -20) rotate(26) scale(1.35)">{frond(9, 760)}</g>
            <g transform="translate(1240 160) rotate(160) scale(1.1)">{frond(8, 700)}</g>
            <g transform="translate(300 1560) rotate(-70) scale(.9)">{frond(7, 640)}</g>
          </g>
          <rect y="1180" width="1200" height="320" fill="#C98C5E" opacity=".55" />
        </>
      )}

      {kind === 'poster' && (
        <>
          <rect width="1200" height="1500" fill={pal.a} />
          <circle cx="600" cy="660" r="430" fill={pal.d} />
          <circle cx="600" cy="660" r="300" fill={pal.b} opacity=".9" />
          <g transform="translate(600 640) scale(.62)">
            <path d="M-420 -30 L-290 -40 M420 -30 L290 -40" stroke={pal.ink} strokeWidth="18" strokeLinecap="round" />
            <circle cx="-170" cy="40" r="165" fill={pal.ink} /><circle cx="170" cy="40" r="165" fill={pal.ink} />
            <path d="M-26 8 C-8 -26 8 -26 26 8" fill="none" stroke={pal.ink} strokeWidth="20" strokeLinecap="round" />
            <ellipse cx="-240" cy="-30" rx="58" ry="26" transform="rotate(-30 -240 -30)" fill={pal.b} opacity=".5" /><ellipse cx="100" cy="-30" rx="58" ry="26" transform="rotate(-30 100 -30)" fill={pal.b} opacity=".5" />
          </g>
          <text x="70" y="1260" fontFamily={G} fontWeight={900} fontSize="300" letterSpacing="-14" fill={pal.b}>DUSK</text>
          <text x="76" y="1400" fontFamily={F} fontStyle="italic" fontWeight={700} fontSize="110" fill={pal.d}>Hour.</text>
          <text x="70" y="100" fontFamily={G} fontWeight={700} fontSize="28" letterSpacing="9" fill={pal.b}>HALA EYEWEAR — SUMMER 26</text>
        </>
      )}
      <rect width="1200" height="1500" filter={`url(#${id}n)`} opacity=".42" style={{ mixBlendMode: 'overlay' }} />
      <rect width="1200" height="1500" fill={`url(#${id}vig)`} />
    </svg>
  )
}
