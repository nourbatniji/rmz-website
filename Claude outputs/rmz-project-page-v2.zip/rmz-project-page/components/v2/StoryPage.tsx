'use client'
import { useEffect, useMemo, useState } from 'react'
import { stories } from '@/lib/stories'
import { ScrollTrigger } from '@/lib/motion'
import Header2 from './Header2'
import Hero2 from './Hero2'
import Overview from './Overview'
import Showcase, { assetsOf } from './Showcase'
import Details from './Details'
import NextStory from './NextStory'
import Lightbox from './Lightbox'
import { LB } from './Frame'
import { Footer } from './real/Footer'
import { footerContent } from '@/lib/site'
import '../../styles/v2.css'

export default function StoryPage({ slug }: { slug: string }) {
  const s = stories[slug]
  const next = stories[s.next]
  const [at, setAt] = useState<number | null>(null)
  const list = useMemo(() => [...s.blocks.flatMap(assetsOf), ...(s.details ?? []).flatMap((d) => d.assets)], [s])
  const base = useMemo(() => s.blocks.reduce((n, b) => n + assetsOf(b).length, 0), [s])

  useEffect(() => {
    window.scrollTo(0, 0)
    document.fonts?.ready.then(() => ScrollTrigger.refresh())
    const t = setTimeout(() => ScrollTrigger.refresh(), 700)
    return () => clearTimeout(t)
  }, [slug])

  return (
    <LB.Provider value={{ open: setAt }}>
      <main className="v2" key={slug}>
        <Header2 />
        <Hero2 s={s} />
        <Overview s={s} />
        <Showcase s={s} />
        <Details s={s} base={base} />
        <NextStory s={s} next={next} />
        <Footer content={footerContent} />
        <Lightbox s={s} list={list} at={at} set={setAt} />
      </main>
    </LB.Provider>
  )
}
