'use client'
import { useEffect, useRef, useState } from 'react'
import Link from 'next/link'
import { siteNav } from '@/lib/site'

/** Same header as rmz-website: transparent gradient, solid ink bar once scrolled, yellow-underline links, full-screen mobile menu. */
export default function Header2() {
  const [open, setOpen] = useState(false)
  const [solid, setSolid] = useState(false)
  const ref = useRef<HTMLElement>(null)
  useEffect(() => {
    const f = () => setSolid(window.scrollY > 8)
    f(); addEventListener('scroll', f, { passive: true }); return () => removeEventListener('scroll', f)
  }, [])
  useEffect(() => {
    if (!open) return
    const k = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false)
    addEventListener('keydown', k); return () => removeEventListener('keydown', k)
  }, [open])
  return (
    <header ref={ref} className="sh">
      <div aria-hidden="true" className={`sh-bg${solid ? ' solid' : ''}`} />
      <div className="sh-row">
        <Link href="/" aria-label="Rebel Mind Zone — home" className="sh-logo">RMZ<span>.</span></Link>
        <nav aria-label="Primary" className="sh-nav">
          {siteNav.map((n) => <Link key={n.label} href={n.href} className="sh-a">{n.label}<i /></Link>)}
        </nav>
        <button type="button" className="sh-menu" aria-expanded={open} aria-controls="sh-mob" onClick={() => setOpen((v) => !v)}>{open ? 'Close' : 'Menu'}</button>
      </div>
      {open && (
        <nav id="sh-mob" aria-label="Primary" className="sh-mob">
          {siteNav.map((n) => <Link key={n.label} href={n.href} onClick={() => setOpen(false)}>{n.label}</Link>)}
        </nav>
      )}
    </header>
  )
}
