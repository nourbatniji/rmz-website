'use client'
import { useRef } from 'react'
import Link from 'next/link'
import type { Story } from '@/lib/stories'
import { gsap, useMotion } from '@/lib/motion'
import { Art } from './Art'

export default function Hero2({ s }: { s: Story }) {
  const ref = useRef<HTMLElement>(null)
  useMotion(ref, ({ q, el, mobile }) => {
    const xfer = document.querySelector<HTMLElement>('.v2-xfer') // arriving from the previous story's transition
    const tl = gsap.timeline({ defaults: { ease: 'rmzOut' } })
    if (xfer) {
      tl.to(xfer, { clipPath: 'inset(0 0 100% 0)', duration: 1.1, ease: 'rmzInOut', delay: 0.1, onComplete: () => xfer.remove() }, 0)
      tl.from('.h2-im', { scale: 1.14, duration: 1.6 }, 0.1)
    } else {
      tl.from('.h2-frame', { clipPath: 'inset(0 0 100% 0)', duration: 1.5 }, 0.05)
      tl.from('.h2-im', { scale: 1.3, duration: 2 }, 0.05)
    }
    const d = xfer ? 0.7 : 0.35
    tl.from('.h2-title .ln > span', { yPercent: 108, duration: 1.3, stagger: 0.08 }, d)
    tl.from('.h2-top > *, .h2-foot > *', { opacity: 0, y: 14, duration: 1, stagger: 0.07 }, d + 0.35)

    // the hero eases away as the overview slides over it: no pin, no trap
    gsap.to('.h2-im', { yPercent: mobile ? 6 : 12, ease: 'none', scrollTrigger: { trigger: el, start: 'top top', end: 'bottom top', scrub: 0.3 } })
    gsap.to('.h2-title', { xPercent: mobile ? 0 : -4, yPercent: mobile ? 0 : 10, ease: 'none', scrollTrigger: { trigger: el, start: 'top top', end: 'bottom top', scrub: 0.3 } })
    gsap.to('.h2-foot, .h2-top', { opacity: 0, ease: 'none', scrollTrigger: { trigger: el, start: '35% top', end: '85% top', scrub: true } })
  })
  return (
    <section className="h2" ref={ref}>
      <div className="h2-top"><Link href="/" className="t-meta wk-back">← All work</Link><span className="t-meta h2-lab">{s.number} · {s.category} · {s.year}</span></div>
      <div className="h2-cover"><div className="h2-frame"><div className="h2-im"><Art a={s.cover} s={s} /></div><div className="h2-shade" /></div></div>
      <h1 className="h2-title"><span className="ln"><span>{s.name}</span></span></h1>
      <div className="h2-foot">
        <p className="h2-st">{s.statement}</p>
        <p className="h2-full t-meta">{s.fullName}</p>
        
      </div>
    </section>
  )
}
