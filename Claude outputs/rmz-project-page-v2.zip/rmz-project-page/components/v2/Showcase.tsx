'use client'
import { useRef } from 'react'
import type { Block, Story } from '@/lib/stories'
import { gsap, useMotion } from '@/lib/motion'
import { Frame } from './Frame'
import Reel from './Reel'

function Head({ n, total, title }: { n: number; total: number; title?: string }) {
  return <div className="bk-head t-meta"><span className="wk-y">{String(n).padStart(2, '0')} — {title ?? 'Selected work'}</span><span>{String(n).padStart(2, '0')} / {String(total).padStart(2, '0')}</span></div>
}

function Blk({ b, i, total, base, s }: { b: Block; i: number; total: number; base: number; s: Story }) {
    return (
    <div className={`blk blk-${b.t}`} data-i={i}>
      <div className="blk-in">
        <Head n={i + 1} total={total} title={b.title} />
        {b.t === 'feature' && <div className={`feat${b.bleed ? ' bleed' : ''}`}><Frame a={b.asset} s={s} i={base} px /></div>}
        {b.t === 'pair' && (
          <div className={`pair${b.flip ? ' flip' : ''}`}>
            <div className="pair-a"><Frame a={b.a} s={s} i={base} px /></div>
            <div className="pair-b"><Frame a={b.b} s={s} i={base + 1} /></div>
          </div>
        )}
        {b.t === 'detail' && (
          <div className="det">
            <div className="det-main"><Frame a={b.main} s={s} i={base} px /></div>
            <div className="det-side">
              {b.note && <p className="det-note">{b.note}</p>}
              {b.side.map((a, k) => <Frame key={k} a={a} s={s} i={base + 1 + k} />)}
            </div>
          </div>
        )}
        {b.t === 'sequence' && (
          <div className="seq" style={{ ['--n' as string]: b.items.length }}>
            {b.items.map((a, k) => <Frame key={k} a={a} s={s} i={base + k} className={`seq-${k % 2}`} />)}
          </div>
        )}
        {b.t === 'video' && <Reel b={b} s={s} />}
      </div>
    </div>
  )
}

export const assetsOf = (b: Block) => (b.t === 'feature' ? [b.asset] : b.t === 'pair' ? [b.a, b.b] : b.t === 'detail' ? [b.main, ...b.side] : b.t === 'sequence' ? b.items : [])

export default function Showcase({ s }: { s: Story }) {
  const ref = useRef<HTMLElement>(null)
  let base = 0
  const bases = s.blocks.map((b) => { const x = base; base += assetsOf(b).length; return x })

  useMotion(ref, ({ q, mobile }) => {
    // 1 — every frame reveals the same way: a clean wipe with the picture settling inside
    q('.fr, .rl-stage').forEach((fr) => {
      const rv = fr.querySelector('.rv')
      const st = { trigger: fr, start: 'top 90%', once: true }
      gsap.from(fr, { clipPath: 'inset(0 0 100% 0)', duration: 1.3, ease: 'rmzOut', scrollTrigger: st })
      if (rv) gsap.from(rv, { scale: 1.22, duration: 1.7, ease: 'rmzOut', scrollTrigger: st })
    })
    // 2 — subtle parallax on the dominant image of each composition (desktop)
    if (!mobile) q('.fr.px .im').forEach((im) => {
      gsap.fromTo(im, { yPercent: -4, scale: 1.08 }, { yPercent: 4, scale: 1.08, ease: 'none', scrollTrigger: { trigger: im.parentElement!.parentElement, start: 'top bottom', end: 'bottom top', scrub: 0.4 } })
    })
    // 3 — the transition between compositions: the leaving block recedes while the next one wipes in
    const blks = q('.blk-in')
    blks.slice(0, -1).forEach((bi) => {
      gsap.to(bi, { scale: mobile ? 0.985 : 0.94, opacity: mobile ? 0.6 : 0.28, ease: 'none', transformOrigin: '50% 100%',
        scrollTrigger: { trigger: bi, start: 'bottom 62%', end: 'bottom 6%', scrub: true } })
    })
    // 4 — captions & notes
    gsap.from(q('.fg figcaption, .det-note, .bk-head'), { opacity: 0, y: 14, duration: 0.9, ease: 'rmzOut', stagger: 0.04, scrollTrigger: { trigger: ref.current, start: 'top 80%', once: true } })
  })

  return (
    <section className="sc" ref={ref} aria-label="Project showcase">
      {s.blocks.map((b, i) => <Blk key={i} b={b} i={i} total={s.blocks.length} base={bases[i]} s={s} />)}
    </section>
  )
}
