'use client'
import { useEffect, useRef } from 'react'
import type { Asset, Story } from '@/lib/stories'
import { Art } from './Art'

export default function Lightbox({ s, list, at, set }: { s: Story; list: Asset[]; at: number | null; set: (i: number | null) => void }) {
  const btn = useRef<HTMLButtonElement>(null)
  useEffect(() => {
    if (at === null) return
    const prev = document.activeElement as HTMLElement | null
    btn.current?.focus()
    document.body.style.overflow = 'hidden'
    const k = (e: KeyboardEvent) => {
      if (e.key === 'Escape') set(null)
      if (e.key === 'ArrowRight') set((at + 1) % list.length)
      if (e.key === 'ArrowLeft') set((at - 1 + list.length) % list.length)
    }
    addEventListener('keydown', k)
    return () => { removeEventListener('keydown', k); document.body.style.overflow = ''; prev?.focus?.() }
  }, [at, list.length, set])
  if (at === null) return null
  const a = list[at]
  return (
    <div className="lb" role="dialog" aria-modal="true" aria-label="Image viewer" onClick={() => set(null)}>
      <button ref={btn} type="button" className="lb-x" onClick={() => set(null)} aria-label="Close">Close</button>
      <div className="lb-stage" key={at} onClick={(e) => e.stopPropagation()}>
        <div className="lb-art" style={{ aspectRatio: a.ratio }}><Art a={a} s={s} /></div>
      </div>
      <div className="lb-bar t-meta" onClick={(e) => e.stopPropagation()}>
        <button type="button" onClick={() => set((at - 1 + list.length) % list.length)} aria-label="Previous">←</button>
        <span>{String(at + 1).padStart(2, '0')} / {String(list.length).padStart(2, '0')}{a.caption ? ` — ${a.caption}` : ''}</span>
        <button type="button" onClick={() => set((at + 1) % list.length)} aria-label="Next">→</button>
      </div>
    </div>
  )
}
