import type { Asset, Story } from '@/lib/stories'
import { Still } from '../art/stills'
import { Poster } from '../art/posters'
import { Billboard } from '../art/posters'
import { Scene } from './scenes'
import { FlatCan } from '../art/bloom'

export function Art({ a, s }: { a: Asset; s: Story }) {
  const pal = s.pal
  switch (a.art) {
    case 'still': return <Still kind={a.v as never} pal={pal} />
    case 'scene': return <Scene kind={a.v as never} pal={pal} />
    case 'poster': return <Poster kind={a.v as never} pal={pal} ratio="tall" m={s.motif} />
    case 'billboard': return <Billboard pal={pal} layout="wide" />
    case 'cans':
      return (
        <svg className="art" viewBox="0 0 900 900" preserveAspectRatio="xMidYMid slice" role="img" aria-label="Three flavour cans">
          <rect width="900" height="900" fill={pal.b} /><circle cx="450" cy="470" r="330" fill={pal.d} opacity=".55" />
          <FlatCan x={190} y={480} w={210} flavor="ginger" pal={pal} /><FlatCan x={450} y={440} w={250} flavor="original" pal={pal} /><FlatCan x={710} y={480} w={210} flavor="mint" pal={pal} />
        </svg>
      )
    case 'web':
      return (
        <div className="wb">
          <div className="wb-bar"><i /><i /><i /><span>{a.site?.url}</span></div>
          <div className="wb-body">
            {a.inner && <Art a={a.inner} s={s} />}
            <div className="wb-ui"><b>{s.name}</b><span>{a.site?.nav.join('   ')}</span></div>
            <div className="wb-h">{a.site?.title}</div>
          </div>
        </div>
      )
    case 'phone':
      return (
        <div className="ph"><div className="ph-in">{a.inner && <Art a={a.inner} s={s} />}</div><i className="ph-n" /></div>
      )
  }
}
export const isBare = (a: Asset) => a.art === 'web' || a.art === 'phone'
