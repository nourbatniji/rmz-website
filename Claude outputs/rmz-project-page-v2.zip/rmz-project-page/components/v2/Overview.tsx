'use client'
import { useRef } from 'react'
import type { Story } from '@/lib/stories'
import { gsap, useMotion } from '@/lib/motion'

const Words = ({ t, cls = '' }: { t: string; cls?: string }) => <>{t.split(' ').filter(Boolean).map((w, i) => <span className="ow" key={i}><span className={cls}>{w}&nbsp;</span></span>)}</>

export default function Overview({ s }: { s: Story }) {
  const ref = useRef<HTMLElement>(null)
  useMotion(ref, ({ q }) => {
    gsap.from(q('.ov-big .ow > span'), { yPercent: 115, duration: 1.1, stagger: 0.016, ease: 'rmzOut', scrollTrigger: { trigger: '.ov-big', start: 'top 85%', once: true } })
    gsap.from(q('.ov-meta > div, .ov-row'), { y: 28, opacity: 0, duration: 1, stagger: 0.09, ease: 'rmzOut', scrollTrigger: { trigger: '.ov-meta', start: 'top 92%', once: true } })
    gsap.from(q('.ov-row-w > *'), { y: 28, opacity: 0, duration: 1, stagger: 0.1, ease: 'rmzOut', scrollTrigger: { trigger: '.ov-row-w', start: 'top 85%', once: true } })
  })
  const [a, b, c] = s.overview.lead
  return (
    <section className="ov" ref={ref} aria-label="Project overview">
      <div className="ov-meta wk-g12">
        <div className="wk-meta m1"><p className="t-meta wk-nm s">Client</p><p className="t-body wk-nl">{s.client}</p></div>
        <div className="wk-meta m2"><p className="t-meta wk-nm s">Services</p><p className="t-body wk-nl">{s.services.join(' · ')}</p></div>
        <div className="wk-meta m3"><p className="t-meta wk-nm s">Year</p><p className="t-body wk-nl">{s.year}</p></div>
        <div className="wk-meta m4"><p className="t-meta wk-nm s">Location</p><p className="t-body wk-nl">{s.location}</p></div>
      </div>
      <div className="ov-lead wk-g12">
        <p className="t-meta wk-nm wk-y ov-lab">01 — Overview</p>
        <h2 className="ov-big"><Words t={a} /><Words t={b} cls="t-italic ov-acc" /><Words t={c} /></h2>
      </div>
      <div className="ov-row-w wk-g12">
        <div className="ov-row"><p className="t-meta wk-nm wk-y">02 — The challenge</p><p className="t-body ov-p">{s.overview.challenge}</p></div>
        <div className="ov-row"><p className="t-meta wk-nm wk-y">03 — Our approach</p><p className="t-body ov-p">{s.overview.approach}</p></div>
      </div>
    </section>
  )
}
