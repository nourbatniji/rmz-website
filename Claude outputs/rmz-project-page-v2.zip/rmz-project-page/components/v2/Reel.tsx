'use client'
import { useEffect, useRef, useState } from 'react'
import type { Block, Story } from '@/lib/stories'
import { Art } from './Art'

type V = Extract<Block, { t: 'video' }>
const tc = (t: number) => { const s = Math.floor(t); return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}:${String(Math.floor((t % 1) * 24)).padStart(2, '0')}` }

/** Video feature. Plays `src` when a real file exists; otherwise a looping reel of the supplied frames. */
export default function Reel({ b, s }: { b: V; s: Story }) {
  const [playing, setPlaying] = useState(true)
  const root = useRef<HTMLDivElement>(null)
  const bar = useRef<HTMLSpanElement>(null)
  const time = useRef<HTMLSpanElement>(null)
  const vid = useRef<HTMLVideoElement>(null)
  const t = useRef(0)
  const vis = useRef(false)
  const play = useRef(true)
  play.current = playing

  useEffect(() => {
    const el = root.current!
    const io = new IntersectionObserver(([e]) => { vis.current = e.isIntersecting; if (b.src && vid.current) { e.isIntersecting && play.current ? vid.current.play().catch(() => {}) : vid.current.pause() } }, { threshold: 0.25 })
    io.observe(el)
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches
    if (reduce) setPlaying(false)
    let last = performance.now(), raf = 0
    const slides = Array.from(el.querySelectorAll<HTMLElement>('.rl-s'))
    const paint = () => {
      const n = slides.length, d = b.duration, k = Math.min(n - 1, Math.floor((t.current / d) * n)), lp = ((t.current / d) * n) % 1
      slides.forEach((x, i) => { x.style.opacity = i === k ? '1' : '0'; x.style.transform = `scale(${1.02 + (i === k ? lp : 1) * 0.09})` })
      if (bar.current) bar.current.style.transform = `scaleX(${t.current / d})`
      if (time.current) time.current.textContent = tc(t.current)
    }
    const tick = (now: number) => {
      const dt = (now - last) / 1000; last = now
      if (b.src && vid.current) { t.current = vid.current.currentTime; b.duration = vid.current.duration || b.duration; if (bar.current) bar.current.style.transform = `scaleX(${t.current / b.duration})`; if (time.current) time.current.textContent = tc(t.current) }
      else { if (play.current && vis.current) t.current = (t.current + dt) % b.duration; paint() }
      raf = requestAnimationFrame(tick)
    }
    paint(); raf = requestAnimationFrame(tick)
    return () => { cancelAnimationFrame(raf); io.disconnect() }
  }, [b])

  const toggle = () => {
    setPlaying((v) => { const nv = !v; if (vid.current) nv ? vid.current.play().catch(() => {}) : vid.current.pause(); return nv })
  }
  const seek = (e: React.MouseEvent<HTMLButtonElement>) => {
    const r = e.currentTarget.getBoundingClientRect(), f = (e.clientX - r.left) / r.width
    t.current = f * b.duration
    if (vid.current) vid.current.currentTime = t.current
  }
  return (
    <div className="rl" ref={root}>
      <div className="rl-stage fr-reveal">
        {b.src ? <video ref={vid} src={b.src} muted loop playsInline preload="metadata" /> : b.frames.map((f, i) => <div className="rl-s" key={i}><Art a={f} s={s} /></div>)}
        <button type="button" className={`rl-big${playing ? ' hide' : ''}`} onClick={toggle} aria-label="Play film" tabIndex={playing ? -1 : 0}><svg width="26" height="26" viewBox="0 0 14 14" aria-hidden="true"><path d="M2 1 L13 7 L2 13 Z" fill="#0F0F0E" /></svg></button>
        <div className="rl-shade" />
        <div className="rl-ui">
          <button type="button" className="rl-btn" onClick={toggle} aria-pressed={!playing} aria-label={playing ? 'Pause film' : 'Play film'}>
            {playing ? <svg viewBox="0 0 24 24"><path d="M8 5v14M16 5v14" /></svg> : <svg viewBox="0 0 24 24"><path d="M7 4.5v15l12-7.5z" fill="currentColor" /></svg>}
          </button>
          <button type="button" className="rl-seek" onClick={seek} aria-label="Seek"><span className="rl-track"><span ref={bar} className="rl-bar" /></span></button>
          <span className="rl-tc">TC <span ref={time}>00:00:00</span></span>
        </div>
      </div>
      <div className="rl-meta t-meta"><span>{b.label}</span><span>{b.src ? 'Video' : 'Reel preview · stand-in for final film'}</span></div>
    </div>
  )
}
