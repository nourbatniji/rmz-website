'use client'
import { createContext, useContext } from 'react'
import type { Asset, Story } from '@/lib/stories'
import { Art, isBare } from './Art'

export const LB = createContext<{ open: (i: number) => void }>({ open: () => {} })

export function Frame({ a, s, i, px = false, className = '' }: { a: Asset; s: Story; i: number; px?: boolean; className?: string }) {
  const { open } = useContext(LB)
  const bare = isBare(a)
  return (
    <figure className={`fg ${className}`}>
      <button type="button" className={`fr${bare ? ' bare' : ''}${px ? ' px' : ''}`} style={{ aspectRatio: a.ratio }} onClick={() => open(i)} aria-label={`View larger${a.caption ? `: ${a.caption}` : ''}`}>
        <span className="rv"><span className="im"><Art a={a} s={s} /></span></span>
        <span className="vw" aria-hidden="true">View ↗</span>
      </button>
      {a.caption && <figcaption className="t-meta">Fig. {String(i + 1).padStart(2, '0')} — {a.caption}</figcaption>}
    </figure>
  )
}
