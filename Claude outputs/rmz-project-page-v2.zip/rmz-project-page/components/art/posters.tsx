import type { Pal } from '@/lib/projects'
import { F, G, B, FlatCan, Motif, Rays, uid } from './bloom'

export type PosterKind = 'bloomtype' | 'can' | 'type' | 'night' | 'stripes' | 'quote' | 'promo' | 'stat'
const mc = (pal: Pal, k: 'a' | 'd' | 'c' | 'b') =>
  k === 'a' ? { petal: pal.b, leaf: pal.c, core: pal.d, vein: pal.a }
  : k === 'd' ? { petal: pal.a, leaf: pal.c, core: pal.b, vein: pal.d }
  : k === 'c' ? { petal: pal.b, leaf: pal.d, core: pal.a, vein: pal.c }
  : { petal: pal.a, leaf: pal.c, core: pal.d, vein: pal.b }

export function Poster({ kind, pal, ratio = 'tall', m = 'bloom' }: { kind: PosterKind; pal: Pal; ratio?: 'tall' | 'square' | 'story'; m?: 'bloom' | 'arch' }) {
  const id = uid()
  const vb = ratio === 'square' ? '0 150 1000 1000' : ratio === 'story' ? '-120 0 1240 1400' : '0 0 1000 1400'
  const head = m === 'bloom' ? ['DRINK THE', 'BLOOM', 'LOUD.'] : ['ROOMS', 'MADE OF', 'ARCHES.']
  return (
    <svg className="art" viewBox={vb} preserveAspectRatio="xMidYMid slice" role="img" aria-label={`${kind} poster`}>
      {kind === 'bloomtype' && (
        <>
          <rect x="-300" width="1600" height="1400" fill={pal.a} />
          <g transform="translate(640 500) scale(1.85)"><Motif m={m} colors={mc(pal, 'a')} /></g>
          <g fontFamily={F} fontWeight={900} fontSize="196" letterSpacing="-6">
            <text x="60" y="1010" fill={pal.b}>{head[0]}</text>
            <text x="60" y="1190" fill={pal.d}>{head[1]}</text>
            <text x="60" y="1370" fill={pal.b}>{head[2]}</text>
          </g>
          <text x="60" y="90" fontFamily={G} fontWeight={700} fontSize="26" letterSpacing="8" fill={pal.b}>ZAHR — SPARKLING HIBISCUS</text>
        </>
      )}
      {kind === 'can' && (
        <>
          <rect x="-300" width="1600" height="1400" fill={pal.b} />
          <g transform="translate(500 760)"><Rays fill={pal.d} opacity={0.4} /></g>
          <circle cx="500" cy="760" r="330" fill={pal.a} />
          <FlatCan x={500} y={760} w={330} flavor="original" pal={pal} m={m} />
          <text x="500" y="150" textAnchor="middle" fontFamily={G} fontWeight={800} fontSize="34" letterSpacing="14" fill={pal.ink}>SERVED COLD.</text>
          <text x="500" y="1290" textAnchor="middle" fontFamily={F} fontWeight={900} fontSize="130" letterSpacing="-4" fill={pal.a}>HEARD LOUD.</text>
        </>
      )}
      {kind === 'type' && (
        <>
          <rect x="-300" width="1600" height="1400" fill={pal.d} />
          {[0, 1, 2, 3].map((i) => <text key={i} x="40" y={300 + i * 290} fontFamily={F} fontWeight={900} fontSize="380" letterSpacing="-14" fill={pal.ink} opacity={[1, 0.62, 0.34, 0.16][i]}>{m === 'bloom' ? 'LOUD' : 'ARCH'}</text>)}
          <g transform="translate(830 1180) scale(.3)"><Motif m={m} colors={mc(pal, 'd')} /></g>
        </>
      )}
      {kind === 'night' && (
        <>
          <defs><radialGradient id={`${id}g`} cx=".5" cy=".46" r=".62"><stop offset="0" stopColor={pal.a} stopOpacity=".95" /><stop offset=".55" stopColor={pal.a} stopOpacity=".25" /><stop offset="1" stopColor={pal.a} stopOpacity="0" /></radialGradient></defs>
          <rect x="-300" width="1600" height="1400" fill={m === 'bloom' ? '#0B1F18' : pal.ink} />
          <rect x="-300" width="1600" height="1400" fill={`url(#${id}g)`} />
          <g transform="translate(500 600) scale(1.25)"><Motif m={m} colors={{ petal: pal.a, leaf: pal.c, core: pal.d, vein: pal.b }} /></g>
          <text x="500" y="1250" textAnchor="middle" fontFamily={F} fontWeight={300} fontSize="120" letterSpacing="-2" fill={pal.b}>Open at dusk.</text>
          <text x="500" y="1320" textAnchor="middle" fontFamily={G} fontWeight={700} fontSize="26" letterSpacing="12" fill={pal.d}>ZAHR AFTER DARK</text>
        </>
      )}
      {kind === 'stripes' && (
        <>
          <rect x="-300" width="1600" height="1400" fill={pal.a} />
          <g transform="rotate(-32 500 700)">{Array.from({ length: 22 }, (_, i) => <rect key={i} x={-600 + i * 110} y="-700" width="55" height="3000" fill={i % 2 ? pal.b : pal.d} opacity={i % 2 ? 0.92 : 1} />)}</g>
          <circle cx="500" cy="700" r="330" fill={pal.c} />
          <text x="500" y="770" textAnchor="middle" fontFamily={F} fontWeight={900} fontSize="210" letterSpacing="-6" fill={pal.b}>{m === 'bloom' ? 'ZAHR' : 'MQM'}</text>
        </>
      )}
      {kind === 'quote' && (
        <>
          <rect x="-300" width="1600" height="1400" fill={pal.b} />
          {['We don’t', 'do subtle.'].map((l, i) => <text key={l} x="70" y={540 + i * 220} fontFamily={F} fontWeight={900} fontSize="230" letterSpacing="-9" fill={i ? pal.a : pal.ink}>{l}</text>)}
          <g transform="translate(800 1100) scale(.42)"><Motif m={m} colors={mc(pal, 'b')} /></g>
          <text x="70" y="1280" fontFamily={G} fontWeight={700} fontSize="30" letterSpacing="10" fill={pal.ink}>@DRINKZAHR</text>
        </>
      )}
      {kind === 'promo' && (
        <>
          <rect x="-300" width="1600" height="1400" fill={pal.c} />
          <g transform="translate(500 700)"><Rays fill={pal.d} opacity={0.18} n={18} /></g>
          <FlatCan x={350} y={760} w={270} flavor="mint" pal={pal} m={m} />
          <FlatCan x={650} y={820} w={270} flavor="ginger" pal={pal} m={m} />
          <text x="60" y="250" fontFamily={F} fontWeight={900} fontSize="250" letterSpacing="-9" fill={pal.b}>BUY 2.</text>
          <text x="60" y="450" fontFamily={F} fontWeight={900} fontSize="170" letterSpacing="-6" fill={pal.d}>BLOOM TWICE.</text>
        </>
      )}
      {kind === 'stat' && (
        <>
          <rect x="-300" width="1600" height="1400" fill={pal.ink} />
          <text x="40" y="800" fontFamily={F} fontWeight={900} fontSize="720" letterSpacing="-30" fill={pal.a}>0</text>
          <text x="580" y="450" fontFamily={F} fontWeight={900} fontSize="130" letterSpacing="-4" fill={pal.b}>whispers.</text>
          <text x="580" y="580" fontFamily={F} fontWeight={300} fontSize="64" fill={pal.d}>100% loud, since 2026.</text>
          <rect x="60" y="1000" width="880" height="6" fill={pal.b} />
          <text x="60" y="1100" fontFamily={G} fontWeight={700} fontSize="30" letterSpacing="12" fill={pal.b}>ZAHR · SPARKLING HIBISCUS</text>
        </>
      )}
    </svg>
  )
}

/** Four-panel campaign billboard. wide = 2400x1000, tall = 1000x1600 */
export function Billboard({ pal, layout }: { pal: Pal; layout: 'wide' | 'tall' }) {
  if (layout === 'wide')
    return (
      <svg viewBox="0 0 2400 1000" preserveAspectRatio="xMidYMid slice" className="art" aria-label="Campaign billboard">
        <rect width="1000" height="1000" fill={pal.a} /><rect x="1000" width="800" height="1000" fill={pal.d} /><rect x="1800" width="600" height="1000" fill={pal.c} />
        <g transform="translate(1400 500)"><Rays fill="#fff" opacity={0.18} n={20} r={1200} /></g>
        <g transform="translate(560 470) scale(1.75)"><Motif m="bloom" colors={mc(pal, 'a')} /></g>
        <text x="60" y="935" fontFamily={F} fontWeight={900} fontSize="150" letterSpacing="-5" fill={pal.b}>DRINK THE</text>
        <text x="1040" y="190" fontFamily={F} fontWeight={900} fontSize="104" letterSpacing="-4" fill={pal.ink}>BLOOM LOUD.</text>
        <FlatCan x={1180} y={420} w={230} flavor="ginger" pal={pal} /><FlatCan x={1420} y={380} w={260} flavor="original" pal={pal} /><FlatCan x={1660} y={430} w={230} flavor="mint" pal={pal} />
        <text x="1860" y="300" fontFamily={F} fontWeight={900} fontSize="120" letterSpacing="-3" fill={pal.b}>NOW IN</text>
        <text x="1860" y="420" fontFamily={F} fontWeight={900} fontSize="120" letterSpacing="-3" fill={pal.d}>EVERY</text>
        <text x="1860" y="540" fontFamily={F} fontWeight={900} fontSize="120" letterSpacing="-3" fill={pal.b}>COOLER.</text>
        <text x="1860" y="900" fontFamily={G} fontWeight={800} fontSize="34" letterSpacing="14" fill={pal.b}>ZAHR.CO</text>
      </svg>
    )
  return (
    <svg viewBox="0 0 1000 1600" preserveAspectRatio="xMidYMid slice" className="art" aria-label="Campaign billboard">
      <rect width="1000" height="560" fill={pal.a} /><rect y="560" width="1000" height="560" fill={pal.d} /><rect y="1120" width="1000" height="480" fill={pal.c} />
      <g transform="translate(500 330) scale(1.15)"><Motif m="bloom" colors={mc(pal, 'a')} /></g>
      <text x="50" y="500" fontFamily={F} fontWeight={900} fontSize="170" letterSpacing="-6" fill={pal.b}>DRINK THE</text>
      <text x="50" y="740" fontFamily={F} fontWeight={900} fontSize="170" letterSpacing="-6" fill={pal.a}>BLOOM LOUD.</text>
      <g transform="translate(500 850)"><Rays fill="#fff" opacity={0.2} n={20} r={900} /></g>
      <FlatCan x={270} y={900} w={200} flavor="ginger" pal={pal} /><FlatCan x={500} y={880} w={230} flavor="original" pal={pal} /><FlatCan x={730} y={900} w={200} flavor="mint" pal={pal} />
      <text x="50" y="1320" fontFamily={F} fontWeight={900} fontSize="140" letterSpacing="-4" fill={pal.b}>NOW IN EVERY</text>
      <text x="50" y="1460" fontFamily={F} fontWeight={900} fontSize="140" letterSpacing="-4" fill={pal.d}>COOLER.</text>
      <text x="50" y="1548" fontFamily={G} fontWeight={800} fontSize="30" letterSpacing="14" fill={pal.b}>ZAHR.CO</text>
    </svg>
  )
}
