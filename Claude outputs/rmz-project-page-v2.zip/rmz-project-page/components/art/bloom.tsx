import { useId, type ReactNode } from 'react'
import type { Pal } from '@/lib/projects'

export const F = "'Fraunces Variable', Georgia, serif"
export const G = "'Figtree Variable', system-ui, sans-serif"
export const B = "'Bricolage Grotesque Variable', system-ui, sans-serif"

export const uid = () => useId().replace(/[^a-zA-Z0-9]/g, '_')
const rot = (n: number, step: number, off = 0) => Array.from({ length: n }, (_, i) => off + i * step)

const PETAL = 'M0 0 C130 -40 175 -190 0 -300 C-175 -190 -130 -40 0 0Z'
const LEAF = 'M0 -190 C46 -260 44 -350 0 -430 C-44 -350 -46 -260 0 -190Z'
const ARCH = (w: number, h: number) => `M${-w} 0 V${-h + w} A${w} ${w} 0 0 1 ${w} ${-h + w} V0Z`

export type Part = 'petal' | 'leaf' | 'core' | 'vein'

/** One ink plate of the motif. Everything is drawn around (0,0). */
export function MotifPart({ m, part, fill }: { m: 'bloom' | 'arch'; part: Part; fill: string }) {
  if (m === 'arch') {
    if (part === 'petal') return <path d={`${ARCH(250, 560)} M-92 -420 a92 92 0 1 0 184 0 a92 92 0 1 0 -184 0Z`} fillRule="evenodd" transform="translate(-120 300)" fill={fill} />
    if (part === 'leaf') return <path d={ARCH(160, 360)} transform="translate(300 300)" fill={fill} />
    if (part === 'core') return <circle cx="-120" cy="-120" r="92" fill={fill} />
    return (
      <g fill="none" stroke={fill} strokeWidth="3">
        {[1, 1.12, 1.24].map((s) => <path key={s} d={ARCH(250 * s, 560 * s)} transform={`translate(-120 300)`} />)}
        <line x1="-520" x2="520" y1="300" y2="300" strokeWidth="5" />
        {rot(23, 1).map((i) => <line key={i} x1={-520 + i * 46} x2={-520 + i * 46} y1="300" y2={i % 5 === 0 ? 340 : 322} />)}
      </g>
    )
  }
  if (part === 'petal') return <g fill={fill}>{rot(5, 72).map((r) => <path key={r} d={PETAL} transform={`rotate(${r})`} />)}</g>
  if (part === 'leaf') return <g fill={fill}>{rot(5, 72, 36).map((r) => <path key={r} d={LEAF} transform={`rotate(${r})`} />)}</g>
  if (part === 'core')
    return (
      <g fill={fill} stroke={fill}>
        <circle r="46" />
        {rot(10, 36).map((r) => <circle key={r} r="7" cy="-86" transform={`rotate(${r})`} />)}
        {rot(5, 72, 18).map((r) => (
          <g key={r} transform={`rotate(${r})`}><line y2="-150" strokeWidth="9" /><circle cy="-160" r="15" /></g>
        ))}
      </g>
    )
  return (
    <g fill="none" stroke={fill} strokeWidth="3" strokeLinecap="round">
      {rot(5, 72).map((r) => (
        <g key={r} transform={`rotate(${r})`}>
          <path d="M0 -40 C6 -120 4 -200 0 -265" />
          <path d="M0 -40 C60 -110 90 -190 72 -240" />
          <path d="M0 -40 C-60 -110 -90 -190 -72 -240" />
        </g>
      ))}
      <circle r="345" strokeDasharray="2 14" />
      <circle r="372" strokeWidth="1.5" />
    </g>
  )
}

export function Motif({ m, colors }: { m: 'bloom' | 'arch'; colors: { petal: string; leaf: string; core: string; vein: string } }) {
  return (
    <>
      <MotifPart m={m} part="leaf" fill={colors.leaf} />
      <MotifPart m={m} part="petal" fill={colors.petal} />
      <MotifPart m={m} part="core" fill={colors.core} />
      <MotifPart m={m} part="vein" fill={colors.vein} />
    </>
  )
}

export type PlateKey = 'a' | 'b' | 'c' | 'd'
const PART_OF: Record<PlateKey, Part> = { a: 'petal', b: 'vein', c: 'leaf', d: 'core' }
export const PLATE_ORDER: PlateKey[] = ['c', 'a', 'd', 'b']

/** A single full-frame ink plate (own <svg>, so it can be moved with GPU transforms). */
export function Plate({ k, m, pal, scale = 1.55, className = '' }: { k: PlateKey; m: 'bloom' | 'arch'; pal: Pal; scale?: number; className?: string }) {
  return (
    <svg className={`plate plate-${k} ${className}`} data-plate={k} viewBox="-800 -500 1600 1000" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
      <g transform={`scale(${scale})`}><MotifPart m={m} part={PART_OF[k]} fill={pal[k]} /></g>
      {k === 'd' && <circle r={m === 'bloom' ? 505 : 470} fill="none" stroke={pal.d} strokeWidth="14" />}
      {k === 'c' && (
        <g fill={pal.c}>
          <path d="M-800 -500 H-520 A280 280 0 0 1 -800 -220Z" />
          <path d="M800 500 H520 A280 280 0 0 1 800 220Z" />
        </g>
      )}
    </svg>
  )
}

export function Plates({ m, pal }: { m: 'bloom' | 'arch'; pal: Pal }) {
  return <>{PLATE_ORDER.map((k) => <Plate key={k} k={k} m={m} pal={pal} />)}</>
}

/* ---------- Flavours, wraps and cans ---------- */
export type Flavor = 'original' | 'ginger' | 'mint'
export const flavorSpec = (c: Pal) => ({
  original: { name: 'Original', bg: c.a, fg: c.b, petal: c.b, leaf: c.c, core: c.d, vein: c.a, lines: ['HIBISCUS.', 'LIME.', 'LOUD.'], note: 'Hibiscus, lime peel, a squeeze of sunlight.', abv: 'Sharp, floral, cold. The one that started it.' },
  ginger: { name: 'Ginger Fire', bg: c.d, fg: c.ink, petal: c.a, leaf: c.c, core: c.b, vein: c.d, lines: ['HIBISCUS.', 'GINGER.', 'FIRE.'], note: 'Fresh ginger root, black pepper, nectar.', abv: 'Warm at the back of the throat. Built for winter evenings.' },
  mint: { name: 'Mint Rush', bg: c.c, fg: c.b, petal: c.b, leaf: c.d, core: c.a, vein: c.c, lines: ['HIBISCUS.', 'MINT.', 'COOL.'], note: 'Nana mint, cucumber water, crushed ice.', abv: 'The quiet one. Still louder than anything else in the fridge.' },
})

/** Flat label artwork. 1500 x 920 = one full revolution of the can. */
export function Wrap({ flavor, pal, m = 'bloom' }: { flavor: Flavor; pal: Pal; m?: 'bloom' | 'arch' }) {
  const f = flavorSpec(pal)[flavor]
  const small = [[-1, -1], [1, -1], [-1, 1], [1, 1], [0, 0]]
  return (
    <svg viewBox="0 0 1500 920" preserveAspectRatio="none" className="wrap-art" aria-hidden="true">
      <rect width="1500" height="920" fill={f.bg} />
      {/* panel 1 — the mark */}
      <g transform="translate(250 360) scale(.78)"><Motif m={m} colors={f} /></g>
      <text x="250" y="800" textAnchor="middle" fontFamily={F} fontWeight={900} fontSize="190" fill={f.fg} letterSpacing="-4">ZAHR</text>
      {/* panel 2 — the voice */}
      <g fontFamily={F} fontWeight={900} fill={f.fg}>
        {f.lines.map((l, i) => <text key={l} x="560" y={250 + i * 190} fontSize={i === 1 ? 170 : 150} letterSpacing="-3" opacity={i === 2 ? 1 : 0.92}>{l}</text>)}
      </g>
      <text x="560" y="830" fontFamily={G} fontWeight={700} fontSize="34" letterSpacing="9" fill={f.fg}>SPARKLING HIBISCUS · 330 ML</text>
      <rect x="560" y="800" width="380" height="5" fill={f.fg} />
      {/* panel 3 — pattern + legal */}
      {[0, 1, 2].map((r) => [0, 1].map((cc) => (
        <g key={`${r}${cc}`} transform={`translate(${1090 + cc * 190} ${150 + r * 220}) scale(.2)`}><Motif m={m} colors={f} /></g>
      )))}
      <g transform="translate(1040 640)">
        <rect width="380" height="200" fill={f.fg} />
        <rect x="8" y="8" width="364" height="184" fill={f.bg} />
        {Array.from({ length: 30 }, (_, i) => <rect key={i} x={30 + i * 10.5} y="40" width={i % 3 === 0 ? 7 : 3.5} height="82" fill={f.fg} />)}
        <text x="30" y="160" fontFamily={G} fontWeight={600} fontSize="22" fill={f.fg}>6 223000 140{small.length}7</text>
      </g>
    </svg>
  )
}

export function FlatCan({ x = 0, y = 0, w = 200, flavor, pal, m = 'bloom' }: { x?: number; y?: number; w?: number; flavor: Flavor; pal: Pal; m?: 'bloom' | 'arch' }) {
  const id = uid()
  const f = flavorSpec(pal)[flavor]
  const h = w * 2.05
  return (
    <g transform={`translate(${x} ${y})`}>
      <defs>
        <linearGradient id={`${id}s`} x1="0" x2="1" y1="0" y2="0">
          <stop offset="0" stopColor="#000" stopOpacity=".5" /><stop offset=".12" stopColor="#000" stopOpacity="0" />
          <stop offset=".24" stopColor="#fff" stopOpacity=".34" /><stop offset=".34" stopColor="#fff" stopOpacity="0" />
          <stop offset=".72" stopColor="#000" stopOpacity="0" /><stop offset="1" stopColor="#000" stopOpacity=".55" />
        </linearGradient>
        <clipPath id={`${id}c`}><rect x={-w / 2} y={-h / 2} width={w} height={h} rx={w * 0.1} /></clipPath>
      </defs>
      <g clipPath={`url(#${id}c)`}>
        <rect x={-w / 2} y={-h / 2} width={w} height={h} fill={f.bg} />
        <g transform={`translate(0 ${-h * 0.06}) scale(${w / 1150})`}><Motif m={m} colors={f} /></g>
        <text y={h * 0.3} textAnchor="middle" fontFamily={F} fontWeight={900} fontSize={w * 0.27} fill={f.fg} letterSpacing={-w * 0.008}>ZAHR</text>
        <text y={h * 0.38} textAnchor="middle" fontFamily={G} fontWeight={700} fontSize={w * 0.06} letterSpacing={w * 0.02} fill={f.fg}>{f.name.toUpperCase()}</text>
        <rect x={-w / 2} y={-h / 2} width={w} height={h * 0.055} fill="#D7D7D1" />
        <rect x={-w / 2} y={h / 2 - h * 0.045} width={w} height={h * 0.045} fill="#C0C0BA" />
        <rect x={-w / 2} y={-h / 2} width={w} height={h} fill={`url(#${id}s)`} />
      </g>
    </g>
  )
}

export function Rays({ n = 24, r = 1400, fill, opacity = 0.3 }: { n?: number; r?: number; fill: string; opacity?: number }) {
  const a = 360 / n / 2
  return <g fill={fill} opacity={opacity}>{rot(n, 360 / n).map((d) => <path key={d} d={`M0 0 L${r * Math.sin((a * Math.PI) / 180)} ${-r * Math.cos((a * Math.PI) / 180)} L${-r * Math.sin((a * Math.PI) / 180)} ${-r * Math.cos((a * Math.PI) / 180)}Z`} transform={`rotate(${d})`} />)}</g>
}

export const Group = ({ children, t }: { children: ReactNode; t: string }) => <g transform={t}>{children}</g>
