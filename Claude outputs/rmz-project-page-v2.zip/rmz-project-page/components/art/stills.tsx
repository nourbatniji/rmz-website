import type { Pal } from '@/lib/projects'
import { F, G, FlatCan, MotifPart, uid } from './bloom'

export type StillKind = 'sun' | 'pour' | 'macro' | 'flat' | 'dusk'
const petal = 'M0 0 C60 -20 80 -110 0 -170 C-80 -110 -60 -20 0 0Z'

function Grain({ id, amt = 0.4 }: { id: string; amt?: number }) {
  return (
    <>
      <filter id={`${id}n`} x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency=".85" numOctaves="2" seed="4" /><feColorMatrix values="0 0 0 0 .5  0 0 0 0 .5  0 0 0 0 .5  0 0 0 .9 0" /></filter>
      <rect width="1200" height="1500" filter={`url(#${id}n)`} opacity={amt} style={{ mixBlendMode: 'overlay' }} />
    </>
  )
}

/** Rendered stand-ins for photography. Each is a lit, graded composition (grain, falloff, shadows). */
export function Still({ kind, pal }: { kind: StillKind; pal: Pal }) {
  const id = uid()
  const petals = (n: number, seedX: number, blur = 0, col = pal.a) =>
    Array.from({ length: n }, (_, i) => {
      const x = (Math.sin(i * 12.9898 + seedX) * 43758.5453) % 1
      const y = (Math.sin(i * 78.233 + seedX) * 12345.6789) % 1
      return <path key={i} d={petal} fill={col} opacity={0.75 + (Math.abs(x) % 0.25)} filter={blur ? `url(#${id}b${blur})` : undefined}
        transform={`translate(${200 + Math.abs(x) * 800} ${150 + Math.abs(y) * 1100}) rotate(${i * 67}) scale(${0.35 + Math.abs(y) * 0.6})`} />
    })
  return (
    <svg className="art" viewBox="0 0 1200 1500" preserveAspectRatio="xMidYMid slice" role="img" aria-label={`${kind} still`}>
      <defs>
        <filter id={`${id}b4`}><feGaussianBlur stdDeviation="4" /></filter>
        <filter id={`${id}b14`}><feGaussianBlur stdDeviation="14" /></filter>
        <filter id={`${id}b40`}><feGaussianBlur stdDeviation="40" /></filter>
        <linearGradient id={`${id}wall`} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#F8D2A8" /><stop offset=".62" stopColor="#E8664A" /><stop offset="1" stopColor={pal.a} /></linearGradient>
        <linearGradient id={`${id}floor`} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#E9B98A" /><stop offset="1" stopColor="#B25B3D" /></linearGradient>
        <linearGradient id={`${id}cyl`} x1="0" x2="1"><stop offset="0" stopColor="#000" stopOpacity=".28" /><stop offset=".3" stopColor="#fff" stopOpacity=".5" /><stop offset=".6" stopColor="#000" stopOpacity="0" /><stop offset="1" stopColor="#000" stopOpacity=".4" /></linearGradient>
        <radialGradient id={`${id}vig`} cx=".5" cy=".45" r=".75"><stop offset=".55" stopColor="#000" stopOpacity="0" /><stop offset="1" stopColor="#000" stopOpacity=".55" /></radialGradient>
        <linearGradient id={`${id}liq`} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#FF4E6E" /><stop offset="1" stopColor="#8E0A26" /></linearGradient>
        <linearGradient id={`${id}sky`} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#2B1138" /><stop offset=".4" stopColor="#8F1D44" /><stop offset=".72" stopColor="#F2683A" /><stop offset="1" stopColor="#FFC561" /></linearGradient>
        <radialGradient id={`${id}sunG`}><stop offset="0" stopColor="#FFF2C2" /><stop offset=".5" stopColor="#FFC561" stopOpacity=".9" /><stop offset="1" stopColor="#FFC561" stopOpacity="0" /></radialGradient>
      </defs>

      {kind === 'sun' && (
        <>
          <rect width="1200" height="1500" fill={`url(#${id}wall)`} />
          <polygon points="0,980 1200,860 1200,1500 0,1500" fill={`url(#${id}floor)`} />
          <polygon points="470,1100 1180,1000 1200,1180 640,1230" fill="#5A1B1B" opacity=".4" filter={`url(#${id}b14)`} />
          <polygon points="0,0 520,0 0,900" fill="#fff" opacity=".1" />
          {/* pedestal */}
          <ellipse cx="520" cy="1170" rx="270" ry="52" fill="#8A3B2A" />
          <rect x="250" y="980" width="540" height="190" fill={pal.b} /><rect x="250" y="980" width="540" height="190" fill={`url(#${id}cyl)`} />
          <ellipse cx="520" cy="980" rx="270" ry="52" fill="#FFF3DE" />
          <FlatCan x={520} y={650} w={290} flavor="original" pal={pal} />
          <ellipse cx="520" cy="985" rx="150" ry="28" fill="#5A1B1B" opacity=".25" />
          {/* ice + petals */}
          {[[690, 940, 8], [350, 950, -12], [770, 975, 20]].map(([x, y, r], i) => (
            <g key={i} transform={`translate(${x} ${y}) rotate(${r})`}><rect width="74" height="74" rx="14" fill="#fff" opacity=".5" /><rect x="8" y="8" width="26" height="26" rx="8" fill="#fff" opacity=".6" /></g>
          ))}
          {petals(9, 3)}
          {petals(5, 9, 14, pal.d)}
        </>
      )}

      {kind === 'pour' && (
        <>
          <rect width="1200" height="1500" fill="#08130F" />
          <circle cx="600" cy="640" r="520" fill={pal.c} opacity=".5" filter={`url(#${id}b40)`} />
          <circle cx="760" cy="420" r="300" fill={pal.a} opacity=".35" filter={`url(#${id}b40)`} />
          <path d="M360 480 L840 480 L770 1250 Q765 1290 725 1290 L475 1290 Q435 1290 430 1250 Z" fill="#fff" opacity=".1" />
          <path d="M378 640 L822 640 L765 1240 Q760 1272 725 1272 L475 1272 Q440 1272 435 1240 Z" fill={`url(#${id}liq)`} />
          <ellipse cx="600" cy="640" rx="222" ry="26" fill="#FF7A92" />
          <path d="M360 480 L840 480 L770 1250 Q765 1290 725 1290 L475 1290 Q435 1290 430 1250 Z" fill="none" stroke="#fff" strokeOpacity=".7" strokeWidth="5" />
          <path d="M410 520 L440 1200" stroke="#fff" strokeOpacity=".55" strokeWidth="14" strokeLinecap="round" />
          {Array.from({ length: 34 }, (_, i) => <circle key={i} cx={470 + ((i * 97) % 260)} cy={700 + ((i * 181) % 520)} r={3 + (i % 5) * 2.2} fill="#fff" opacity={0.25 + (i % 4) * 0.12} />)}
          {Array.from({ length: 14 }, (_, i) => <circle key={`d${i}`} cx={300 + ((i * 131) % 600)} cy={260 + ((i * 89) % 220)} r={6 + (i % 4) * 5} fill="#FF4E6E" opacity=".85" />)}
          <g transform="translate(790 470) rotate(24) scale(1.2)"><path d={petal} fill={pal.a} /><path d="M0 -10 C 10 -60 6 -100 0 -150" stroke={pal.b} strokeWidth="3" fill="none" opacity=".6" /></g>
          <ellipse cx="600" cy="1300" rx="270" ry="22" fill="#000" opacity=".5" filter={`url(#${id}b14)`} />
        </>
      )}

      {kind === 'macro' && (
        <>
          <rect width="1200" height="1500" fill="#2A0610" />
          <g opacity=".9">{petals(7, 5, 40, pal.a)}</g>
          {Array.from({ length: 16 }, (_, i) => <circle key={i} cx={(i * 211) % 1200} cy={(i * 347) % 1500} r={30 + (i % 5) * 26} fill={i % 3 ? pal.d : '#FF7A92'} opacity=".28" filter={`url(#${id}b4)`} />)}
          <g transform="translate(600 800) scale(3.6)">
            <path d={petal} fill={pal.a} transform="rotate(-18)" /><path d={petal} fill="#B0102F" transform="rotate(40)" />
            <g transform="rotate(-18)" fill="none" stroke={pal.b} strokeOpacity=".5" strokeWidth=".7"><path d="M0 -6 C3 -50 2 -100 0 -150" /><path d="M0 -6 C28 -45 40 -100 28 -130" /><path d="M0 -6 C-28 -45 -40 -100 -28 -130" /></g>
          </g>
          <g transform="translate(600 860)"><circle r="26" fill={pal.d} /><line x1="0" y1="0" x2="60" y2="-120" stroke={pal.d} strokeWidth="8" /><circle cx="60" cy="-120" r="18" fill={pal.d} /></g>
        </>
      )}

      {kind === 'flat' && (
        <>
          <rect width="1200" height="1500" fill={pal.b} />
          <rect width="1200" height="1500" fill="#fff" opacity=".12" />
          {[[330, 430], [830, 560], [560, 1010]].map(([x, y], i) => (
            <g key={i}>
              <ellipse cx={x + 30} cy={y + 34} rx="170" ry="168" fill="#5A3A28" opacity=".28" filter={`url(#${id}b14)`} />
              <circle cx={x} cy={y} r="165" fill={['#E9E4D8', '#E9E4D8', '#E9E4D8'][i]} />
              <circle cx={x} cy={y} r="150" fill={[pal.a, pal.d, pal.c][i]} />
              <circle cx={x} cy={y} r="118" fill="none" stroke="#fff" strokeOpacity=".5" strokeWidth="4" />
              <path d={`M${x - 36} ${y - 14} h72 v36 h-72z`} fill="#D7D7D1" /><circle cx={x} cy={y + 4} r="9" fill="#9A9A94" />
            </g>
          ))}
          {[[1000, 960], [240, 1190]].map(([x, y], i) => (
            <g key={i}><ellipse cx={x + 24} cy={y + 30} rx="128" ry="126" fill="#5A3A28" opacity=".26" filter={`url(#${id}b14)`} />
              <circle cx={x} cy={y} r="120" fill="#fff" opacity=".7" /><circle cx={x} cy={y} r="104" fill={`url(#${id}liq)`} /><circle cx={x} cy={y} r="78" fill="none" stroke="#fff" strokeOpacity=".55" strokeWidth="4" />
              <circle cx={x + 18} cy={y - 10} r="52" fill={pal.c} opacity=".92" /><circle cx={x + 18} cy={y - 10} r="40" fill="#C8E27A" /></g>
          ))}
          <g transform="translate(940 250) rotate(18)"><MotifPart m="bloom" part="petal" fill={pal.a} /></g>
          {petals(7, 11)}
        </>
      )}

      {kind === 'dusk' && (
        <>
          <rect width="1200" height="1500" fill={`url(#${id}sky)`} />
          <circle cx="760" cy="880" r="420" fill={`url(#${id}sunG)`} />
          <circle cx="760" cy="880" r="130" fill="#FFF2C2" />
          <g fill="#1A0C20">
            <rect x="0" y="930" width="1200" height="570" />
            {[[40, 820, 110], [160, 870, 90], [260, 780, 130], [410, 850, 100], [520, 700, 70], [900, 830, 120], [1030, 760, 110], [1130, 860, 90]].map(([x, y, w], i) => <rect key={i} x={x} y={y} width={w} height={400} />)}
            <path d="M610 930 V690 h18 V930Z M619 640 l12 50 h-24Z" /><ellipse cx="700" cy="935" rx="90" ry="70" /><rect x="610" y="610" width="6" height="40" />
            <path d="M560 940 A 120 120 0 0 1 800 940Z" />
          </g>
          <g fill="#FFC561" opacity=".8">{Array.from({ length: 26 }, (_, i) => <rect key={i} x={50 + ((i * 53) % 1100)} y={880 + ((i * 37) % 160)} width="8" height="12" />)}</g>
          <rect y="1120" width="1200" height="380" fill="#0E060F" />
          <rect y="1112" width="1200" height="14" fill="#FF8A55" opacity=".6" />
          <g transform="translate(520 1020)"><ellipse cx="0" cy="105" rx="150" ry="18" fill="#000" opacity=".5" filter={`url(#${id}b14)`} />
            <FlatCan x={0} y={0} w={200} flavor="original" pal={pal} /><rect x="-102" y="-205" width="8" height="410" fill="#FFC561" opacity=".5" /></g>
        </>
      )}
      <rect width="1200" height="1500" fill={`url(#${id}vig)`} />
      <Grain id={id} amt={kind === 'dusk' ? 0.5 : 0.38} />
      <text x="-9999" y="-9999" fontFamily={F}>{G}</text>
    </svg>
  )
}
