import { notFound } from 'next/navigation'
import { stories, storySlugs } from '@/lib/stories'
import StoryPage from '@/components/v2/StoryPage'

export function generateStaticParams() { return storySlugs.map((slug) => ({ slug })) }
export const metadata = { title: 'RMZ — Project Stories (V2)' }
export default async function Page({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  if (!stories[slug]) notFound()
  return <StoryPage slug={slug} />
}
