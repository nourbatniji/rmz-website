import { notFound } from 'next/navigation'
import { projects, slugs } from '@/lib/projects'
import ProjectPage from '@/components/ProjectPage'

export function generateStaticParams() { return slugs.map((slug) => ({ slug })) }
export default async function Page({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const p = projects[slug]
  if (!p) notFound()
  return <ProjectPage slug={slug} />
}
