import type { Metadata, Viewport } from 'next'
import '@fontsource-variable/figtree'
import '@fontsource-variable/fraunces/opsz.css'
import '@fontsource-variable/bricolage-grotesque'
import '@fontsource/playfair-display/700-italic.css'
import '../styles/base.css'

export const metadata: Metadata = { title: 'RMZ — Project details prototype', description: 'Out of Register: a project case-study experience for RMZ.' }
export const viewport: Viewport = { themeColor: '#0F0F0E', colorScheme: 'dark' }

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
